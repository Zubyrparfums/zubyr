import mysql from 'mysql2/promise';
import * as dotenv from 'dotenv';
import { readFileSync } from 'fs';

// Load env from .env file if present
dotenv.config();

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('DATABASE_URL not set');
  process.exit(1);
}

const articles = [
  {
    title: 'Oud: The Liquid Gold of Perfumery',
    slug: 'oud-liquid-gold-perfumery',
    category: 'ingredient_academy',
    authorName: 'ZUBYR Ingredient Lab',
    readTime: 7,
    tags: JSON.stringify(['oud', 'agarwood', 'ingredients', 'luxury', 'Singapore']),
    excerpt: 'Oud is one of perfumery\'s most prized ingredients — a dark, resinous heartwood formed when Aquilaria trees respond to infection, creating a scent that has captivated civilisations for centuries.',
    content: `## How Oud Is Formed

Oud is not simply harvested from a tree — it is created through a remarkable natural process. When an Aquilaria tree is infected by a specific mould, it produces a dark, aromatic resin as a defence mechanism. This resin slowly saturates the heartwood over decades, creating the dense, complex material we call agarwood. Trees can take 20 to 100 years to produce significant quantities of oud, which explains its extraordinary rarity and value.

## Where Oud Comes From

The finest oud originates from several key regions:

- **Cambodia:** Light, sweet, and slightly fruity. Often considered the most approachable for Western palates.
- **India (Hindi Oud):** Deep, animalic, and barnyard-like. Intense and polarising, beloved by connoisseurs.
- **Brunei & Malaysia:** Smooth, creamy, and woody.
- **Papua New Guinea:** Earthy and green, with a raw, forest-like quality.

## The Scent Profile

Oud is famously difficult to describe. At its core, it is woody and resinous, with layers that can include leather, smoke, sweetness, earthiness, and a subtle animalic depth. The best ouds evolve dramatically on skin — opening bright and sharp, then settling into a warm, enveloping base that can last 12 hours or more.

## Oud in Modern Perfumery

Contemporary perfumers use both natural oud oil and synthetic oud molecules. Natural oud is used in luxury concentrations — a single kilogram of high-grade oud oil can cost SGD 30,000 or more. Synthetic alternatives allow perfumers to capture the essence of oud at accessible price points.

Famous oud-centric fragrances include Tom Ford Oud Wood, Maison Francis Kurkdjian Oud, and Amouage Interlude.

## Wearing Oud

Oud performs best on warm skin. Apply to pulse points — wrists, neck, inner elbows — and allow it to breathe. Avoid rubbing the wrists together, as this breaks down the molecular structure. Oud-heavy fragrances are ideal for evenings and formal occasions.`
  },
  {
    title: 'The Science of Sillage: How Fragrance Travels Through Air',
    slug: 'science-of-sillage-how-fragrance-travels',
    category: 'perfume_science',
    authorName: 'ZUBYR Science Desk',
    readTime: 6,
    tags: JSON.stringify(['sillage', 'fragrance science', 'chemistry', 'projection', 'Singapore']),
    excerpt: 'Sillage — the invisible trail a fragrance leaves in the air — is determined by molecular weight, volatility, concentration, and the environment around you.',
    content: `## What Is Sillage?

Sillage is a French word meaning "wake" or "trail" — the same term used for the path a boat leaves in water. In perfumery, it describes the projection of a fragrance: how far it radiates from the wearer and how long it lingers in the air after they have left.

## The Chemistry of Scent Projection

Fragrance molecules have different molecular weights and volatility levels, which determine how quickly they evaporate and how far they travel:

- **High volatility (low molecular weight):** Molecules like citrus aldehydes and light musks evaporate quickly, projecting strongly but briefly. These form the top notes you smell immediately.
- **Medium volatility:** Floral and spice molecules travel well and persist for hours — these are the heart notes that define a fragrance's character.
- **Low volatility (high molecular weight):** Woody, resinous, and animalic molecules cling to skin and fabric. These base notes project less but last the longest.

## Concentration and Projection

| Concentration | Fragrance % | Sillage |
|---|---|---|
| Eau de Cologne (EDC) | 2–4% | Light, close to skin |
| Eau de Toilette (EDT) | 5–15% | Moderate projection |
| Eau de Parfum (EDP) | 15–20% | Strong, lasting trail |
| Parfum/Extrait | 20–30%+ | Intimate but very long-lasting |

## Environmental Factors

**Humidity:** Singapore's tropical humidity actually enhances sillage. Moisture in the air helps carry scent molecules further and keeps them suspended longer.

**Temperature:** Heat accelerates evaporation, boosting initial projection. Wearing fragrance in air-conditioned spaces can significantly reduce sillage.

**Skin chemistry:** Oily skin retains and projects fragrance better than dry skin. Moisturising before applying fragrance creates a base that amplifies sillage.

## Maximising Your Sillage

1. Apply to pulse points (wrists, neck, chest) where body heat radiates fragrance outward.
2. Layer with matching body lotion or shower gel to extend projection.
3. Apply to hair — hair fibres hold fragrance molecules exceptionally well.
4. Spray clothing for longer-lasting projection in air-conditioned environments.
5. Choose EDP concentrations for Singapore's indoor lifestyle.`
  },
  {
    title: 'The Fragrance Pyramid: Understanding Top, Middle, and Base Notes',
    slug: 'fragrance-pyramid-top-middle-base-notes',
    category: 'perfumery_school',
    authorName: 'ZUBYR Perfumery School',
    readTime: 5,
    tags: JSON.stringify(['fragrance pyramid', 'top notes', 'base notes', 'beginner guide', 'perfumery school']),
    excerpt: 'The fragrance pyramid divides a perfume into three layers — top, heart, and base notes — each evaporating at different rates to create a scent that evolves over hours.',
    content: `## What Is the Fragrance Pyramid?

The fragrance pyramid describes how a perfume unfolds over time. It is divided into three layers, each composed of ingredients with different evaporation rates.

### Top Notes (0–30 minutes)

The first impression. Top notes are the lightest, most volatile molecules — they evaporate quickly and are what you smell the moment you spray. Common top notes include citrus (bergamot, lemon, grapefruit), herbs (basil, mint, lavender), and light florals (neroli, petitgrain).

Top notes are designed to attract attention, but they are not the true character of the fragrance. Never buy a perfume based on the first 5 minutes alone.

### Heart Notes / Middle Notes (30 minutes – 4 hours)

The soul of the fragrance. As top notes fade, the heart emerges — these are the dominant notes that define what the perfume is "about." Common heart notes include florals (rose, jasmine, ylang-ylang), spices (cardamom, cinnamon, pepper), and fruits (peach, plum, raspberry).

The heart is what you will smell on yourself throughout the day. This is the layer to evaluate when testing a fragrance.

### Base Notes (4 hours onwards)

The foundation and memory. Base notes are the heaviest, least volatile molecules — they anchor the fragrance and are what lingers on your skin long after the heart has faded. Common base notes include woods (sandalwood, cedarwood, vetiver, oud), resins (amber, benzoin), and musks.

## How to Test a Fragrance Properly

1. Spray on skin (not paper) — paper cannot replicate how your skin chemistry interacts with the fragrance.
2. Wait 15 minutes for the top notes to settle.
3. Evaluate the heart — this is the true character of the fragrance.
4. Return after 2–3 hours to assess the base.
5. Only then decide if you love it.`
  },
  {
    title: 'Deconstructing a Classic Fougère: The Architecture of a Timeless Accord',
    slug: 'deconstructing-classic-fougere-accord',
    category: 'formula_breakdowns',
    authorName: 'ZUBYR Formula Lab',
    readTime: 7,
    tags: JSON.stringify(['fougere', 'accord', 'formula', 'classic perfumery', 'fragrance history']),
    excerpt: 'The fougère accord — built on lavender, oakmoss, and coumarin — has been the backbone of men\'s perfumery since 1882.',
    content: `## The Birth of Fougère

The fougère family was invented by perfumer Paul Parquet for Houbigant's Fougère Royale in 1882. The name means "fern" in French — not because it smells like ferns, but because it evokes the romantic idea of a mossy, green forest floor.

Fougère Royale was revolutionary for one reason: it was the first commercial perfume to use coumarin, a synthetic molecule that smells of freshly cut hay, sweet tonka bean, and warm vanilla. Combined with lavender and oakmoss, Parquet created a structure that was simultaneously fresh, earthy, and warm.

## The Classic Fougère Triad

Every traditional fougère is built on three pillars:

**1. Lavender (top/heart)**
Provides the fresh, aromatic, slightly herbal opening. Lavender bridges the gap between the sharp top notes and the warmer base.

**2. Oakmoss (base)**
A natural ingredient derived from lichen, oakmoss smells earthy, green, and slightly marine — like a forest after rain. Note: oakmoss is now heavily restricted by IFRA regulations due to allergen concerns.

**3. Coumarin (base)**
The synthetic heart of the accord. Coumarin smells of warm hay, sweet almonds, and vanilla — it softens the sharpness of lavender and the earthiness of oakmoss.

## Famous Fougères

- **Brut (1964):** The archetype of the barbershop fougère.
- **Drakkar Noir (1982):** A darker, more aromatic interpretation.
- **Cool Water (1988):** The aquatic fougère that launched a thousand clones.
- **Bleu de Chanel (2010):** A modern, refined fougère for the contemporary man.
- **Terre d'Hermès (2006):** A deconstructed fougère with mineral and citrus elements.

## The Modern Fougère

Today's fougères replace restricted oakmoss with synthetic alternatives and often incorporate aquatic notes, woods, and fresh citrus to create a cleaner, more contemporary profile.`
  },
  {
    title: 'The 4th Generation Perfumer: Carrying a Family Legacy Into the Future',
    slug: 'zubyr-founder-4th-generation-perfumer-story',
    category: 'perfumer_stories',
    authorName: 'ZUBYR Founder',
    readTime: 6,
    tags: JSON.stringify(['perfumer story', 'heritage', 'Singapore', 'bespoke', 'ZUBYR', 'founder']),
    excerpt: 'Being the fourth generation of a perfumery family means inheriting not just knowledge, but a language — the language of scent that connects cultures, memories, and people across time.',
    content: `There is a particular weight that comes with being the fourth generation of anything. Not the burden of expectation alone, but something more nuanced — the responsibility of carrying forward something that has survived long enough to matter.

I grew up surrounded by scent. My great-grandmother kept bottles of rose water and oud chips in a carved wooden box that sat on her dresser. My grandmother blended her own attars — small, concentrated perfume oils she would press into the wrists of guests as a gesture of welcome. My father studied the formal chemistry of fragrance, bridging the traditional and the technical. By the time it was my turn, I had inherited not just knowledge, but a language.

## The Language of Scent

Fragrance is a language that most people speak without realising it. The way a particular combination of sandalwood and rose can transport you to a specific memory. The way oud signals formality and reverence in one culture, and exotic luxury in another.

Singapore is a remarkable place to be a perfumer. In one city, you have access to the oud traditions of the Arab world, the floral attars of South Asia, the clean, fresh aesthetic of Japanese perfumery, and the bold, experimental spirit of Western niche fragrance.

## Why ZUBYR

ZUBYR was born from a simple frustration: the fragrance industry, for all its beauty, has always been a one-way conversation. Perfumers create. Consumers buy. The relationship ends at the point of sale.

I wanted to change that. ZUBYR is built on the belief that fragrance is a conversation — between maker and wearer, between tradition and innovation, between the perfumer's intention and the wearer's skin chemistry.

## Vision 2035

By 2035, I want ZUBYR to be the fragrance ecosystem that Singapore deserves — a place where anyone can learn to understand scent, create their own fragrance, trade with fellow enthusiasts, and connect with the global perfumery community.

The fourth generation carries the past. But it also gets to write the future.`
  },
  {
    title: 'Singapore Fragrance Market 2025: The Rise of Niche and Indie Perfumery',
    slug: 'singapore-fragrance-market-2025-niche-report',
    category: 'singapore_fragrance_reports',
    authorName: 'ZUBYR Research Desk',
    readTime: 7,
    tags: JSON.stringify(['Singapore', 'market report', 'niche perfumery', '2025 trends', 'fragrance industry']),
    excerpt: 'Singapore\'s fragrance market is growing at 23% annually in the niche and indie segment, driven by social media discovery and rising consumer sophistication.',
    content: `## Market Overview

The Singapore fragrance market is estimated at SGD 280–320 million in 2025, with niche and artisanal segments growing at approximately 23% year-on-year — significantly outpacing the overall market growth of 8%. This mirrors global trends but is amplified by Singapore's unique characteristics: high disposable income, a cosmopolitan population, and a culture that prizes quality and distinction.

## The Shift from Designer to Niche

Five years ago, the Singapore fragrance market was dominated by the usual suspects — Chanel, Dior, Yves Saint Laurent. Today, niche houses like Maison Francis Kurkdjian, Creed, Amouage, and Byredo are now mainstream in Singapore's premium retail landscape, while truly indie perfumers — including local Singapore brands — are finding audiences that would have been impossible to reach before social media.

## The Social Media Effect

TikTok and Instagram have been transformative. Fragrance content — reviews, hauls, "what I'm wearing today" posts — has exploded in Singapore. Local fragrance influencers now command audiences of 50,000 to 500,000 followers, and their recommendations drive measurable sales.

## What Singaporeans Are Wearing

1. **Woody/Oud** — 34%
2. **Fresh/Aquatic** — 28%
3. **Floral** — 22%
4. **Gourmand/Sweet** — 11%
5. **Chypre/Green** — 5%

## Looking Ahead

The next five years will see continued growth in bespoke and experiential fragrance — workshops, custom blending, and fragrance education. Singapore is becoming a fragrance city. The only question is who will shape it.`
  },
  {
    title: 'How ScentMate AI Finds Your Signature Scent in Under 3 Minutes',
    slug: 'scentmate-ai-finds-signature-scent',
    category: 'scentmate_insights',
    authorName: 'ZUBYR Tech Team',
    readTime: 5,
    tags: JSON.stringify(['ScentMate', 'AI', 'fragrance recommendation', 'technology', 'personalisation']),
    excerpt: 'ScentMate AI approaches fragrance recommendation differently — starting with memory, lifestyle, and skin chemistry rather than generic category questions.',
    content: `## The Problem: Fragrance Choice Paralysis

There are over 40,000 fragrances currently in production. Without a framework for understanding what you actually want — and why — the search is overwhelming.

Most fragrance recommendation tools make this worse. They ask vague questions ("Do you prefer fresh or warm?") and return generic suggestions that could apply to anyone. ScentMate takes a different approach.

## How ScentMate Works

ScentMate begins not with fragrance categories, but with you. The AI asks a series of questions designed to build a multidimensional profile of your scent preferences:

**Memory anchors:** What scents do you associate with your happiest memories? Memory-linked scents are the most emotionally resonant — and the most likely to feel like "you."

**Lifestyle context:** Where will you wear this fragrance? A corporate office in Raffles Place, a weekend brunch in Tiong Bahru, a late-night dinner in the CBD? Context determines projection, longevity, and appropriateness.

**Skin chemistry:** Some people run warm; some run cool. Some have oily skin that amplifies fragrance; others have dry skin that eats it. ScentMate factors in these variables.

**Existing preferences:** If you already love something, ScentMate can reverse-engineer why — identifying the specific accords or structures that make it work for you.

## The Recommendation Engine

ScentMate maps your answers to a proprietary fragrance graph that connects notes, accords, houses, and individual fragrances. Rather than returning a single recommendation, it provides a curated shortlist of 3–5 options with explanations.

## Refining Your Results

ScentMate improves with feedback. After you try a recommendation, you can rate it — and the AI adjusts its model accordingly.`
  },
  {
    title: 'Inside a ZUBYR Workshop: Eight Strangers and One Perfume',
    slug: 'inside-zubyr-workshop-group-perfume-making',
    category: 'workshop_journal',
    authorName: 'ZUBYR Workshop Journal',
    readTime: 6,
    tags: JSON.stringify(['workshop', 'experience', 'group session', 'perfume making', 'Singapore']),
    excerpt: 'A ZUBYR group workshop is not a class — it is an experience. Eight strangers arrive, learn to smell with intention, and leave three hours later with a perfume they created themselves.',
    content: `It begins with a smell.

Not a perfume — not yet — but a single raw material. A small brown bottle is passed around the table, and eight strangers take turns holding it to their nose. Some recoil. Some close their eyes. One person laughs. Another says, quietly, "That's exactly like my grandfather's house."

The material is vetiver — a smoky, earthy, deeply rooted grass oil from Haiti. And in that moment, something shifts in the room.

## The First Hour: Learning to Smell

Most of us have never been taught to smell. We experience scent constantly, but rarely with intention. The first part of every ZUBYR workshop is dedicated to developing that intention — learning to slow down, isolate, and articulate what you are actually smelling.

Participants work through a curated set of raw materials: citrus, florals, woods, resins, musks. By the end of this section, the room has developed a shared vocabulary.

## The Blending Session

Each participant receives a blending kit: a selection of pre-measured materials, a set of pipettes, a blank formula card, and an empty bottle. The brief is simple: create something that feels like you.

What happens next is always surprising. Some people work methodically, following ratios and building logically from top to base. Others work intuitively, following their nose without a plan.

The conversations that happen during the blending session are unlike any other. People talk about their childhoods, their travels, the people they love. Fragrance has a way of unlocking things.

## The Reveal

At the end of the session, each participant presents their creation to the group. The room smells of eight completely different things — eight different people, eight different stories.

You leave with your bottle, your formula card, and a new relationship with your own sense of smell.`
  },
  {
    title: 'From Collector to Creator: How Singapore\'s Fragrance Community Is Evolving',
    slug: 'singapore-fragrance-community-collector-to-creator',
    category: 'community_spotlight',
    authorName: 'ZUBYR Community Team',
    readTime: 6,
    tags: JSON.stringify(['community', 'Singapore', 'fragrance culture', 'marketplace', 'collector']),
    excerpt: 'Singapore\'s fragrance community has evolved from a small group of collectors into a vibrant ecosystem of traders, swappers, and creators.',
    content: `Five years ago, Singapore's fragrance community was small, scattered, and largely invisible. A few thousand enthusiasts traded tips in Telegram groups, swapped decants through informal networks, and met occasionally at pop-ups. Today, that community has grown into something genuinely remarkable.

## The Collector Era

The first wave of Singapore fragrance enthusiasts were collectors. They hunted discontinued bottles, built elaborate shelves of niche houses, and competed (gently) to own the most obscure or expensive pieces. Fragrance was a hobby of acquisition — the pleasure was in the having.

This era produced a deep well of knowledge. Collectors learned to read fragrance notes, understand house signatures, and identify quality. They built the vocabulary that the community still uses today.

## The Swapper and Trader

As collections grew, so did the problem of excess. Full bottles of fragrances you no longer wear. Blind buys that did not work out. The natural response was trading — and Singapore's fragrance swap culture was born.

The community developed its own norms around authenticity verification, fair pricing, and trust. This peer-to-peer economy gave enthusiasts access to a much wider range of fragrances than any single retailer could offer.

## The Creator

The newest and most exciting evolution is the creator. Inspired by workshops, online tutorials, and the growing accessibility of raw materials, a growing number of Singaporeans are moving beyond buying and into making.

## The ZUBYR Community Marketplace

ZUBYR's Community Marketplace was built for all three archetypes — the collector, the trader, and the creator. The community is the ecosystem. Everything else we build at ZUBYR is in service of it.`
  },
  {
    title: 'Musk: The Most Misunderstood Ingredient in Modern Perfumery',
    slug: 'musk-misunderstood-ingredient-modern-perfumery',
    category: 'fragrance_encyclopedia',
    authorName: 'ZUBYR Editorial',
    readTime: 7,
    tags: JSON.stringify(['musk', 'encyclopedia', 'ingredients', 'synthetic', 'fragrance chemistry']),
    excerpt: 'Musk is not a single ingredient but an entire family of molecules — from the banned natural deer musk of antiquity to the sophisticated synthetic macrocyclics used in modern niche perfumery.',
    content: `Ask someone what musk smells like and they will probably say "clean" or "warm" or "like laundry." Ask a perfumer and they will tell you that musk is not one thing — it is an entire universe of molecules, each with its own character, history, and role in a fragrance.

## The Origins: Natural Musk

Natural musk comes from the musk deer (Moschus moschiferus), a small deer native to the Himalayas and Central Asia. The musk is secreted by a gland in the male deer's abdomen — a single deer produces only 25–30 grams of musk pod per year. The scent is intensely animalic, warm, and slightly fecal in isolation, but at extreme dilution it becomes one of the most beautiful and sensual materials in perfumery.

Natural musk was used in perfumery for centuries. However, the hunting of musk deer drove the species to near-extinction, and natural musk is now banned or heavily restricted in most countries.

## Synthetic Musks: A New Universe

**White Musks (Polycyclic Musks)**
The "clean laundry" musks. Molecules like Galaxolide and Habanolide create the fresh, powdery, fabric-softener quality associated with modern clean fragrances.

**Macrocyclic Musks**
The most sophisticated and expensive synthetic musks. Habanolide, Exaltolide, and Ethylene Brassylate have a warm, skin-like, slightly sweet quality that closely approximates natural musk. These are the musks used in high-end niche perfumery.

**Animalic Musks**
Molecules like Civetone and Castoreum (both now synthetic) recreate the raw, animalic quality of natural animal musks. Used sparingly, they add depth and sensuality.

## How to Identify Musk

Musk is rarely the star of a fragrance — it is the supporting structure that holds everything together. Signs that a fragrance has significant musk content: it smells "clean" or "skin-like" in the drydown, it has exceptional longevity and sillage, and it smells different on different people.`
  }
];

async function seed() {
  // Strip SSL param from URL and pass ssl option separately
  const urlStr = DATABASE_URL.replace(/[?&]ssl=[^&]*/g, '').replace(/[?&]sslmode=[^&]*/g, '');
  const conn = await mysql.createConnection({ uri: urlStr, ssl: { rejectUnauthorized: false } });
  console.log('Connected to database');

  for (const article of articles) {
    try {
      await conn.execute(
        `INSERT INTO blog_posts (title, slug, content, excerpt, category, status, published, authorName, readTime, tags, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, ?, 'published', 1, ?, ?, ?, NOW(), NOW())
         ON DUPLICATE KEY UPDATE title=title`,
        [article.title, article.slug, article.content, article.excerpt, article.category, article.authorName, article.readTime, article.tags]
      );
      console.log(`✓ Seeded: ${article.title}`);
    } catch (err) {
      console.error(`✗ Failed: ${article.title}`, err.message);
    }
  }

  await conn.end();
  console.log('Done!');
}

seed().catch(console.error);
