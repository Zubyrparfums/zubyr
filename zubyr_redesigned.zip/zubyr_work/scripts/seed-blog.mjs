import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const ARTICLES = [
  {
    category: "ingredient_academy",
    title: "Oud: The Liquid Gold of Perfumery",
    slug: "oud-liquid-gold-perfumery",
    prompt: "Write a 600-word educational article for ZUBYR's Ingredient Academy about oud (agarwood). Cover: what oud is, how it's formed (the resin process), major producing regions (Cambodia, India, Brunei), why it's so expensive, how it smells, how it's used in modern perfumery, and tips for wearing oud-based fragrances. Write in an engaging, educational tone for fragrance enthusiasts in Singapore. Include a short excerpt (2 sentences) at the start.",
    readTime: 5,
    tags: '["oud","agarwood","ingredients","luxury"]',
    authorName: "ZUBYR Ingredient Lab",
  },
  {
    category: "perfume_science",
    title: "The Science of Sillage: How Fragrance Travels Through Air",
    slug: "science-of-sillage-how-fragrance-travels",
    prompt: "Write a 600-word article for ZUBYR's Perfume Science section about sillage — the trail a fragrance leaves in the air. Cover: what sillage means, the chemistry behind how scent molecules travel (volatility, molecular weight), why some fragrances project more than others, the role of concentration (EDP vs EDT), humidity and temperature effects, and practical tips for maximising sillage. Write for a curious, educated audience in Singapore. Include a 2-sentence excerpt.",
    readTime: 6,
    tags: '["sillage","fragrance science","chemistry","projection"]',
    authorName: "ZUBYR Science Desk",
  },
  {
    category: "perfumery_school",
    title: "The Fragrance Pyramid: Understanding Top, Middle, and Base Notes",
    slug: "fragrance-pyramid-top-middle-base-notes",
    prompt: "Write a 600-word beginner's guide for ZUBYR's Perfumery School about the fragrance pyramid. Explain: what the pyramid is, how top notes (citrus, herbs) evaporate quickly, how heart/middle notes (florals, spices) define the character, how base notes (woods, musks, resins) anchor the scent and last longest. Include real examples of each layer, how to smell a fragrance properly, and why this matters when buying perfume. Tone: warm, educational, accessible. Include a 2-sentence excerpt.",
    readTime: 5,
    tags: '["fragrance pyramid","top notes","base notes","beginner guide"]',
    authorName: "ZUBYR Perfumery School",
  },
  {
    category: "formula_breakdowns",
    title: "Deconstructing a Classic Fougère: The Architecture of a Timeless Accord",
    slug: "deconstructing-classic-fougere-accord",
    prompt: "Write a 600-word article for ZUBYR's Formula Breakdowns series about the fougère accord — one of perfumery's most iconic structures. Cover: the history of fougère (Fougère Royale 1882), the classic triad of lavender, oakmoss, and coumarin, how modern fougères evolved, key ingredients and their ratios, famous examples (Brut, Drakkar Noir, Terre d'Hermès), and what makes this structure so enduring. Write for intermediate fragrance enthusiasts. Include a 2-sentence excerpt.",
    readTime: 7,
    tags: '["fougere","accord","formula","classic perfumery"]',
    authorName: "ZUBYR Formula Lab",
  },
  {
    category: "perfumer_stories",
    title: "The 4th Generation Perfumer: How ZUBYR's Founder Carries a Family Legacy",
    slug: "zubyr-founder-4th-generation-perfumer-story",
    prompt: "Write a 600-word first-person style narrative article for ZUBYR's Perfumer Stories section about being a 4th generation perfumer in Singapore. Tell the story of inheriting fragrance knowledge through generations, the challenge of preserving traditional techniques while innovating for modern audiences, what it means to create bespoke fragrances in Singapore's multicultural context, and the vision behind ZUBYR. Write in a warm, personal, storytelling tone. Include a 2-sentence excerpt.",
    readTime: 6,
    tags: '["perfumer story","heritage","Singapore","bespoke"]',
    authorName: "ZUBYR Founder",
  },
  {
    category: "singapore_fragrance_reports",
    title: "Singapore's Fragrance Market 2025: A Report on the Rise of Niche Perfumery",
    slug: "singapore-fragrance-market-2025-niche-report",
    prompt: "Write a 600-word industry report for ZUBYR's Singapore Fragrance Reports section about the growth of niche and indie perfumery in Singapore in 2025. Cover: market size and growth trends, shift from designer to niche, the role of social media (TikTok, Instagram) in fragrance discovery, popular fragrance families among Singaporeans, key local and regional brands emerging, and what this means for the future. Write in a professional but accessible tone. Include a 2-sentence excerpt.",
    readTime: 7,
    tags: '["Singapore","market report","niche perfumery","2025 trends"]',
    authorName: "ZUBYR Research Desk",
  },
  {
    category: "scentmate_insights",
    title: "How ScentMate AI Finds Your Signature Scent in 3 Minutes",
    slug: "scentmate-ai-finds-signature-scent",
    prompt: "Write a 600-word article for ZUBYR's ScentMate Insights section explaining how the ScentMate AI fragrance recommendation engine works. Cover: the problem of fragrance choice paralysis, how ScentMate asks questions about personality, lifestyle, and scent memories, how it maps answers to fragrance families and accords, what makes it different from generic quiz tools, real examples of recommendations it makes, and how users can refine their results. Write in an engaging, slightly technical but accessible tone. Include a 2-sentence excerpt.",
    readTime: 5,
    tags: '["ScentMate","AI","fragrance recommendation","technology"]',
    authorName: "ZUBYR Tech Team",
  },
  {
    category: "workshop_journal",
    title: "Inside a ZUBYR Workshop: What Happens When 8 Strangers Build a Perfume Together",
    slug: "inside-zubyr-workshop-group-perfume-making",
    prompt: "Write a 600-word immersive journal entry for ZUBYR's Workshop Journal about a group perfume-making workshop session. Describe the experience from arrival to the final blend: the welcome, the introduction to raw materials, the blending process, the moments of discovery and surprise, the social connections formed, and the feeling of leaving with a perfume you created yourself. Write in a vivid, experiential, first-person narrative style. Include a 2-sentence excerpt.",
    readTime: 6,
    tags: '["workshop","experience","group session","perfume making"]',
    authorName: "ZUBYR Workshop Journal",
  },
  {
    category: "community_spotlight",
    title: "From Collector to Creator: How Singapore's Fragrance Community Is Evolving",
    slug: "singapore-fragrance-community-collector-to-creator",
    prompt: "Write a 600-word article for ZUBYR's Community Spotlight section about the evolution of Singapore's fragrance community — from passive collectors to active creators and traders. Cover: the rise of fragrance swapping and reselling, online communities (Telegram groups, Reddit, Instagram), the growing culture of decanting and sampling, how ZUBYR's Community Marketplace fits into this ecosystem, and profiles of the types of community members (the collector, the flipper, the creator). Write in an enthusiastic, community-focused tone. Include a 2-sentence excerpt.",
    readTime: 6,
    tags: '["community","Singapore","fragrance culture","marketplace"]',
    authorName: "ZUBYR Community Team",
  },
  {
    category: "fragrance_encyclopedia",
    title: "Musk: The Most Misunderstood Ingredient in Modern Perfumery",
    slug: "musk-misunderstood-ingredient-modern-perfumery",
    prompt: "Write a 600-word encyclopedia entry for ZUBYR's Fragrance Encyclopedia about musk. Cover: the history of natural musk (from deer musk glands), why natural musk is now banned/restricted, the development of synthetic musks (white musks, nitro musks, polycyclic musks), how different musks smell (clean, animalic, powdery, skin-like), famous musk-heavy fragrances, and how to identify musk in a fragrance. Write in an authoritative, encyclopedic but engaging tone. Include a 2-sentence excerpt.",
    readTime: 7,
    tags: '["musk","encyclopedia","ingredients","synthetic"]',
    authorName: "ZUBYR Editorial",
  },
];

async function generateArticle(article) {
  const response = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: "You are a professional fragrance writer for ZUBYR, Singapore's premier fragrance ecosystem. Write engaging, accurate, and SEO-friendly content. Always start with the 2-sentence excerpt clearly labeled 'EXCERPT:' on its own line, then 'CONTENT:' followed by the full article body.",
      },
      { role: "user", content: article.prompt },
    ],
    max_tokens: 1200,
    temperature: 0.7,
  });

  const text = response.choices?.[0]?.message?.content ?? "";
  const excerptMatch = text.match(/EXCERPT:\s*([\s\S]*?)(?=CONTENT:|$)/i);
  const contentMatch = text.match(/CONTENT:\s*([\s\S]*?)$/i);

  const excerpt = excerptMatch ? excerptMatch[1].trim() : text.substring(0, 200);
  const content = contentMatch ? contentMatch[1].trim() : text;

  return { excerpt, content };
}

function escapeSql(str) {
  return str.replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/\n/g, "\\n").replace(/\r/g, "");
}

console.log("Generating 10 AI-drafted articles...\n");

const sqls = [];
for (const article of ARTICLES) {
  process.stdout.write(`  Drafting: ${article.title}...`);
  try {
    const { excerpt, content } = await generateArticle(article);
    const now = new Date().toISOString().slice(0, 19).replace("T", " ");
    sqls.push(
      `INSERT INTO blog_posts (title, slug, content, excerpt, category, status, published, authorName, readTime, tags, createdAt, updatedAt) VALUES ('${escapeSql(article.title)}', '${escapeSql(article.slug)}', '${escapeSql(content)}', '${escapeSql(excerpt)}', '${article.category}', 'published', 1, '${escapeSql(article.authorName)}', ${article.readTime}, '${escapeSql(article.tags)}', '${now}', '${now}');`
    );
    console.log(" ✓");
  } catch (err) {
    console.log(` ✗ ${err.message}`);
  }
}

console.log("\n--- SQL OUTPUT ---");
console.log(sqls.join("\n"));
console.log("--- END SQL ---");
