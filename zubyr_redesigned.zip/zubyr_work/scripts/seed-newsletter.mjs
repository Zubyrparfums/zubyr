/**
 * Seed 2 mock newsletter issues for ZUBYR
 * Run: node scripts/seed-newsletter.mjs
 */

const BASE_URL = process.env.API_URL || "http://localhost:3000";

const issues = [
  {
    title: "The Oud Boom: Why Singapore Can't Get Enough",
    slug: "oud-boom-singapore-2025",
    editionType: "monday",
    publishedAt: new Date("2025-06-02").toISOString(),
    insideZubyrContent: `This week at ZUBYR, we crossed a milestone — our 500th bespoke fragrance consultation. Each one is a conversation, a story, a search for something the client couldn't name until they smelled it.\n\nWe've also been quietly working on our next collection: a series of five fragrances inspired by Singapore's heritage neighbourhoods — Kampong Glam, Chinatown, Little India, Tiong Bahru, and the Civic District. Each one is a place, distilled.\n\nOur Saturday workshop was sold out again. Three corporate groups, one birthday party, and a couple celebrating their 10th anniversary by creating their 'us' scent together. That last one reminded us why we do this.`,
    worldFragranceContent: `The global luxury fragrance market crossed USD 15 billion this year — and oud is the engine behind it. Once the exclusive domain of Gulf royalty, oud has become the defining note of 21st-century luxury perfumery. Brands from Chanel to Dior have launched oud flankers. Niche houses have built entire identities around it.\n\nBut Singapore's relationship with oud runs deeper than the trend. Malay and Arab communities in Kampong Glam have burned oud chips and worn oud-based attars for generations. What the West has 'discovered', many Singaporeans have always known.\n\nThis week, Francis Kurkdjian — one of the most celebrated perfumers alive — gave a rare interview discussing how Singapore and Southeast Asia have become the most sophisticated fragrance markets in the world. His words: "They don't want to smell like Paris. They want to smell like themselves."`,
    imageUrls: "[]",
    published: true,
  },
  {
    title: "Sillage, Longevity & The Art of Wearing Fragrance in the Tropics",
    slug: "sillage-longevity-tropics-singapore",
    editionType: "friday",
    publishedAt: new Date("2025-05-30").toISOString(),
    insideZubyrContent: `We get this question more than almost any other: "Why does my perfume disappear so quickly in Singapore?"\n\nThis week, our perfumer Zubair sat down to answer it properly — and the answer is more interesting than most people expect. Singapore's heat and humidity don't destroy fragrance. They accelerate it. The top notes burn off faster, the heart opens quicker, and you're left with base notes that can actually last longer than in cold climates. The trick is applying differently: pulse points with a light layer, and one or two spritzes on fabric if you want a true trail.\n\nWe've also been reformulating two of our most popular workshop blends — a fresh citrus-vetiver and a warm amber-oud — with Singapore's climate specifically in mind. More resin in the base, less volatile top notes. The result: a fragrance built to last from Raffles Place to Gardens by the Bay.`,
    worldFragranceContent: `The conversation around perfumery and climate is getting serious. A new study published in the Journal of Cosmetic Science found that fragrance longevity drops by up to 40% in high-humidity environments versus temperate ones — confirming what Singaporean fragrance lovers have known for years.\n\nThe solution the industry is exploring: microencapsulation. Fragrance molecules are wrapped in tiny capsules that rupture on contact with friction — meaning when you brush against something, or when fabric moves, the scent is released fresh rather than evaporating all at once. Several luxury houses have already deployed this technology in their fabric-based fragrances.\n\nIn Japan, a small Tokyo atelier is doing something even more radical: creating fragrances specifically calibrated for Tokyo's four seasons, with entirely different molecular weights for summer versus winter. The concept — seasonal perfumery — may be the next frontier.`,
    imageUrls: "[]",
    published: true,
  },
];

console.log("Newsletter seed data ready. To seed, use the admin panel at /admin/newsletter or post via API.");
console.log("Issues to create:", issues.map(i => i.title));

// Export for potential API usage
export { issues };
