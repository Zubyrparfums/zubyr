import { eq, desc, and, or, like, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import {
  InsertUser, users,
  products, InsertProduct,
  workshops, InsertWorkshop,
  blogPosts, InsertBlogPost,
  communityListings, InsertCommunityListing,
  newsletterSubscribers, InsertNewsletterSubscriber,
  contactEnquiries, InsertContactEnquiry,
  jobListings, InsertJobListing,
  jobApplications, InsertJobApplication,
  wholesaleInquiries, InsertWholesaleInquiry,
  collabInquiries, InsertCollabInquiry,
  ideaSubmissions, InsertIdeaSubmission,
  newsletterIssues, InsertNewsletterIssue,
  userTermsAcceptance, InsertUserTermsAcceptance,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
let _dbUnavailable = false; // sticky flag: once a connection attempt fails/times out, stop retrying for this process lifetime

const CONNECT_TIMEOUT_MS = 5000;

/**
 * Lazily creates the drizzle instance. Crucially, this verifies the
 * connection actually works (with a hard timeout) the first time it's
 * called, instead of just constructing the client object — `drizzle()`
 * itself never throws even with a bad/missing URL, the failure only
 * surfaces on the first real query, which without a timeout can hang a
 * request (and the dev server) indefinitely.
 */
export async function getDb() {
  if (_db) return _db;
  if (_dbUnavailable) return null;
  if (!process.env.DATABASE_URL) {
    _dbUnavailable = true;
    return null;
  }

  try {
    const testConnectionPromise = mysql.createConnection(process.env.DATABASE_URL).then(async conn => {
      await conn.ping();
      await conn.end();
    });
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error("DB connection timed out")), CONNECT_TIMEOUT_MS)
    );
    await Promise.race([testConnectionPromise, timeoutPromise]);

    _db = drizzle(process.env.DATABASE_URL);
    return _db;
  } catch (error) {
    console.warn("[Database] Failed to connect:", error instanceof Error ? error.message : error);
    _dbUnavailable = true;
    _db = null;
    return null;
  }
}

// ── Users ──────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ── Products ───────────────────────────────────────────────────────────────

export async function getProducts(activeOnly = false) {
  const db = await getDb();
  if (!db) return [];
  if (activeOnly) return db.select().from(products).where(eq(products.active, true)).orderBy(desc(products.createdAt));
  return db.select().from(products).orderBy(desc(products.createdAt));
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result[0];
}

export async function createProduct(data: InsertProduct) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(products).values(data);
}

export async function updateProduct(id: number, data: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(products).set(data).where(eq(products.id, id));
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(products).where(eq(products.id, id));
}

// ── Workshops ──────────────────────────────────────────────────────────────

export async function getWorkshops(activeOnly = false) {
  const db = await getDb();
  if (!db) return [];
  if (activeOnly) return db.select().from(workshops).where(eq(workshops.active, true)).orderBy(desc(workshops.createdAt));
  return db.select().from(workshops).orderBy(desc(workshops.createdAt));
}

export async function getWorkshopById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(workshops).where(eq(workshops.id, id)).limit(1);
  return result[0];
}

export async function createWorkshop(data: InsertWorkshop) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(workshops).values(data);
}

export async function updateWorkshop(id: number, data: Partial<InsertWorkshop>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(workshops).set(data).where(eq(workshops.id, id));
}

export async function deleteWorkshop(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(workshops).where(eq(workshops.id, id));
}

// ── Blog Posts ─────────────────────────────────────────────────────────────

export async function getBlogPosts(opts?: {
  publishedOnly?: boolean;
  category?: string;
  adminAll?: boolean;
}) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(blogPosts).orderBy(desc(blogPosts.createdAt));
  let filtered = rows;
  if (opts?.publishedOnly) filtered = filtered.filter(r => r.published && r.status === 'published');
  if (opts?.category) filtered = filtered.filter(r => r.category === opts.category);
  return filtered;
}

export async function getBlogPostById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(blogPosts).where(eq(blogPosts.id, id)).limit(1);
  return result[0];
}

export async function getBlogPostBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1);
  return result[0];
}

export async function createBlogPost(data: InsertBlogPost) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(blogPosts).values(data);
}

export async function updateBlogPost(id: number, data: Partial<InsertBlogPost>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(blogPosts).set({ ...data, updatedAt: new Date() }).where(eq(blogPosts.id, id));
}

export async function publishBlogPost(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(blogPosts).set({ status: 'published', published: true, updatedAt: new Date() }).where(eq(blogPosts.id, id));
}

export async function unpublishBlogPost(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(blogPosts).set({ status: 'draft', published: false, updatedAt: new Date() }).where(eq(blogPosts.id, id));
}

export async function deleteBlogPost(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(blogPosts).where(eq(blogPosts.id, id));
}

// ── Community Listings ─────────────────────────────────────────────────────

export async function getCommunityListings(opts?: {
  status?: "pending" | "approved" | "rejected" | "sold";
  search?: string;
  listingType?: "sell" | "exchange" | "giveaway" | "wanted";
}) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(communityListings).$dynamic();
  const conditions = [];
  if (opts?.status) conditions.push(eq(communityListings.status, opts.status));
  if (opts?.listingType) conditions.push(eq(communityListings.listingType, opts.listingType));
  if (opts?.search) conditions.push(
    or(
      like(communityListings.perfumeName, `%${opts.search}%`),
      like(communityListings.brand, `%${opts.search}%`)
    )
  );
  if (conditions.length > 0) query = query.where(and(...conditions));
  return query.orderBy(desc(communityListings.createdAt));
}

export async function getCommunityListingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(communityListings).where(eq(communityListings.id, id)).limit(1);
  return result[0];
}

export async function getCommunityListingBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(communityListings).where(eq(communityListings.slug, slug)).limit(1);
  if (result[0]) {
    // increment view count
    await db.update(communityListings).set({ viewCount: sql`${communityListings.viewCount} + 1` }).where(eq(communityListings.slug, slug));
  }
  return result[0];
}

export async function createCommunityListing(data: InsertCommunityListing) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(communityListings).values(data);
}

export async function updateCommunityListing(id: number, data: Partial<InsertCommunityListing>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(communityListings).set(data).where(eq(communityListings.id, id));
}

export async function updateCommunityListingStatus(id: number, status: "pending" | "approved" | "rejected" | "sold") {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(communityListings).set({ status }).where(eq(communityListings.id, id));
}

export async function deleteCommunityListing(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(communityListings).where(eq(communityListings.id, id));
}

// ── User Terms Acceptance ──────────────────────────────────────────────────

export async function hasUserAcceptedTerms(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const result = await db.select().from(userTermsAcceptance).where(eq(userTermsAcceptance.userId, userId)).limit(1);
  return result.length > 0;
}

export async function acceptTerms(data: InsertUserTermsAcceptance) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(userTermsAcceptance).values(data);
}

// ── Newsletter ─────────────────────────────────────────────────────────────

export async function getNewsletterSubscribers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(newsletterSubscribers).orderBy(desc(newsletterSubscribers.createdAt));
}

export async function subscribeNewsletter(data: InsertNewsletterSubscriber) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(newsletterSubscribers).values(data).onDuplicateKeyUpdate({ set: { active: true } });
}

// ── Contact Enquiries ──────────────────────────────────────────────────────

export async function getContactEnquiries() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(contactEnquiries).orderBy(desc(contactEnquiries.createdAt));
}

export async function createContactEnquiry(data: InsertContactEnquiry) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(contactEnquiries).values(data);
}

export async function markEnquiryRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(contactEnquiries).set({ read: true }).where(eq(contactEnquiries.id, id));
}

// ── Job Listings ───────────────────────────────────────────────────────────

export async function getJobListings(activeOnly = false) {
  const db = await getDb();
  if (!db) return [];
  if (activeOnly) return db.select().from(jobListings).where(eq(jobListings.active, true)).orderBy(desc(jobListings.createdAt));
  return db.select().from(jobListings).orderBy(desc(jobListings.createdAt));
}

export async function getJobListingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(jobListings).where(eq(jobListings.id, id)).limit(1);
  return result[0];
}

export async function createJobListing(data: InsertJobListing) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(jobListings).values(data);
}

export async function updateJobListing(id: number, data: Partial<InsertJobListing>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(jobListings).set(data).where(eq(jobListings.id, id));
}

export async function deleteJobListing(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(jobListings).where(eq(jobListings.id, id));
}

export async function getJobApplications(jobId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (jobId !== undefined) return db.select().from(jobApplications).where(eq(jobApplications.jobId, jobId)).orderBy(desc(jobApplications.createdAt));
  return db.select().from(jobApplications).orderBy(desc(jobApplications.createdAt));
}

export async function countJobApplications(jobId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(jobApplications).where(eq(jobApplications.jobId, jobId));
  return result.length;
}

export async function createJobApplication(data: InsertJobApplication) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(jobApplications).values(data);
}

// ── Wholesale Inquiries ────────────────────────────────────────────────────

export async function getWholesaleInquiries() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(wholesaleInquiries).orderBy(desc(wholesaleInquiries.createdAt));
}

export async function createWholesaleInquiry(data: InsertWholesaleInquiry) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(wholesaleInquiries).values(data);
}

// ── Collab Inquiries ───────────────────────────────────────────────────────

export async function getCollabInquiries() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(collabInquiries).orderBy(desc(collabInquiries.createdAt));
}

export async function createCollabInquiry(data: InsertCollabInquiry) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(collabInquiries).values(data);
}

// ── Idea Submissions ───────────────────────────────────────────────────────

export async function getIdeaSubmissions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(ideaSubmissions).orderBy(desc(ideaSubmissions.createdAt));
}

export async function createIdeaSubmission(data: InsertIdeaSubmission) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(ideaSubmissions).values(data);
}

// ── Newsletter Issues ──────────────────────────────────────────────────────
export async function getNewsletterIssues() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(newsletterIssues).where(eq(newsletterIssues.published, true)).orderBy(desc(newsletterIssues.publishedAt));
}
export async function getNewsletterIssueBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(newsletterIssues).where(eq(newsletterIssues.slug, slug)).limit(1);
  return result[0];
}
export async function createNewsletterIssue(data: InsertNewsletterIssue) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(newsletterIssues).values(data);
}
export async function updateNewsletterIssue(id: number, data: Partial<InsertNewsletterIssue>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(newsletterIssues).set(data).where(eq(newsletterIssues.id, id));
}
export async function deleteNewsletterIssue(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(newsletterIssues).where(eq(newsletterIssues.id, id));
}
