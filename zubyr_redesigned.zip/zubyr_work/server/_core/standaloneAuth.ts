/**
 * Standalone auth — replaces the Manus OAuth flow (server/_core/sdk.ts /
 * oauth.ts) so this app can run on any host without Manus's platform.
 *
 * Simple email + password login using bcrypt for hashing and a signed JWT
 * cookie for sessions. The first account created with the email matching
 * ADMIN_EMAIL (env var) is automatically granted the admin role; otherwise
 * the first registered user overall becomes admin if no admin exists yet.
 */
import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { parse as parseCookieHeader } from "cookie";
import type { Request } from "express";
import { nanoid } from "nanoid";
import { eq } from "drizzle-orm";
import { users, type User } from "../../drizzle/schema";
import { getDb } from "../db";
import { ENV } from "./env";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

const BCRYPT_ROUNDS = 10;

function getSecret() {
  const secret = ENV.cookieSecret || "dev-insecure-secret-change-me";
  return new TextEncoder().encode(secret);
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function createSessionToken(user: User): Promise<string> {
  const issuedAt = Date.now();
  const expirationSeconds = Math.floor((issuedAt + ONE_YEAR_MS) / 1000);
  return new SignJWT({
    openId: user.openId,
    name: user.name ?? "",
  })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(expirationSeconds)
    .sign(getSecret());
}

export async function verifySessionToken(
  token: string | undefined
): Promise<{ openId: string } | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret(), {
      algorithms: ["HS256"],
    });
    const openId = payload.openId;
    if (typeof openId !== "string" || !openId) return null;
    return { openId };
  } catch {
    return null;
  }
}

function parseCookies(cookieHeader: string | undefined) {
  if (!cookieHeader) return new Map<string, string>();
  return new Map(Object.entries(parseCookieHeader(cookieHeader)));
}

/** Reads + verifies the session cookie on an incoming request, returning the DB user or null. */
export async function authenticateRequest(req: Request): Promise<User | null> {
  const cookies = parseCookies(req.headers.cookie);
  let token = cookies.get(COOKIE_NAME);

  if (!token) {
    const authHeader = req.headers.authorization;
    if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
      token = authHeader.slice(7);
    }
  }

  const session = await verifySessionToken(token);
  if (!session) return null;

  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, session.openId))
    .limit(1);

  return result[0] ?? null;
}

export async function getUserByEmail(email: string): Promise<User | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);
  return result[0] ?? null;
}

export async function countUsers(): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(users);
  return result.length;
}

/** Registers a new user with email + password. Throws if the email is already taken. */
export async function registerUser(params: {
  email: string;
  password: string;
  name?: string;
}): Promise<User> {
  const db = await getDb();
  if (!db) throw new Error("Database not configured");

  const existing = await getUserByEmail(params.email);
  if (existing) throw new Error("An account with this email already exists");

  const passwordHash = await hashPassword(params.password);
  const existingCount = await countUsers();

  // First-ever user becomes admin automatically. After that, only emails
  // matching ADMIN_EMAIL (if set) get admin on registration.
  const adminEmail = process.env.ADMIN_EMAIL?.toLowerCase().trim();
  const shouldBeAdmin =
    existingCount === 0 ||
    (adminEmail && params.email.toLowerCase().trim() === adminEmail);

  const openId = `local_${nanoid(20)}`;

  await db.insert(users).values({
    openId,
    name: params.name || params.email.split("@")[0],
    email: params.email,
    loginMethod: "password",
    passwordHash,
    role: shouldBeAdmin ? "admin" : "user",
    lastSignedIn: new Date(),
  });

  const created = await getUserByEmail(params.email);
  if (!created) throw new Error("Failed to create user");
  return created;
}

/** Verifies email + password and returns the user, or throws. */
export async function loginUser(params: {
  email: string;
  password: string;
}): Promise<User> {
  const user = await getUserByEmail(params.email);
  if (!user || !user.passwordHash) {
    throw new Error("Invalid email or password");
  }

  const valid = await verifyPassword(params.password, user.passwordHash);
  if (!valid) throw new Error("Invalid email or password");

  const db = await getDb();
  if (db) {
    await db
      .update(users)
      .set({ lastSignedIn: new Date() })
      .where(eq(users.id, user.id));
  }

  return user;
}
