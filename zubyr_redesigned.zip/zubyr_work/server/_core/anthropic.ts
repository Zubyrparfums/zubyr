/**
 * Direct Anthropic API client — replaces server/_core/llm.ts (Manus's Forge
 * proxy). Set ANTHROPIC_API_KEY in your environment to use this.
 *
 * Usage:
 *   const text = await invokeClaude({ prompt: "Write a haiku about oud." });
 */
const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
const DEFAULT_MODEL = "claude-sonnet-4-6";

export type ClaudeMessage = { role: "user" | "assistant"; content: string };

export async function invokeClaude(params: {
  prompt?: string;
  messages?: ClaudeMessage[];
  system?: string;
  maxTokens?: number;
  model?: string;
}): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error(
      "ANTHROPIC_API_KEY is not configured. Get a key from console.anthropic.com and set it in your environment."
    );
  }

  const messages: ClaudeMessage[] =
    params.messages ?? [{ role: "user", content: params.prompt ?? "" }];

  const body: Record<string, unknown> = {
    model: params.model ?? DEFAULT_MODEL,
    max_tokens: params.maxTokens ?? 1000,
    messages,
  };
  if (params.system) body.system = params.system;

  const response = await fetch(ANTHROPIC_API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Anthropic API request failed: ${response.status} – ${errorText}`);
  }

  const data = await response.json();
  const textBlock = (data.content ?? []).find((b: any) => b.type === "text");
  return textBlock?.text ?? "";
}
