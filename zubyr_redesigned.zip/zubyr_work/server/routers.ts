import { z } from "zod";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { registerUser, loginUser, createSessionToken } from "./_core/standaloneAuth";
import { invokeClaude } from "./_core/anthropic";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getProducts, getProductById, createProduct, updateProduct, deleteProduct,
  getWorkshops, getWorkshopById, createWorkshop, updateWorkshop, deleteWorkshop,
  getBlogPosts, getBlogPostById, getBlogPostBySlug, createBlogPost, updateBlogPost, updateBlogPost as updateBlogPostAdmin, deleteBlogPost, publishBlogPost, unpublishBlogPost,
  getCommunityListings, getCommunityListingById, getCommunityListingBySlug,
  createCommunityListing, updateCommunityListing, updateCommunityListingStatus, deleteCommunityListing,
  hasUserAcceptedTerms, acceptTerms,
  getNewsletterSubscribers, subscribeNewsletter,
  getContactEnquiries, createContactEnquiry, markEnquiryRead,
  getJobListings, getJobListingById, createJobListing, updateJobListing, deleteJobListing,
  getJobApplications, countJobApplications, createJobApplication,
  getWholesaleInquiries, createWholesaleInquiry,
  getCollabInquiries, createCollabInquiry,
  getIdeaSubmissions, createIdeaSubmission,
  getNewsletterIssues, getNewsletterIssueBySlug, createNewsletterIssue, updateNewsletterIssue, deleteNewsletterIssue,
} from "./db";
import { sendAdminEmail } from "./email";

// Admin-only guard
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    register: publicProcedure
      .input(
        z.object({
          email: z.string().email(),
          password: z.string().min(8),
          name: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const user = await registerUser(input);
        const token = await createSessionToken(user);
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
        return { success: true, user } as const;
      }),
    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const user = await loginUser(input);
        const token = await createSessionToken(user);
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
        return { success: true, user } as const;
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ── ScentMate AI ─────────────────────────────────────────────────────────
  scentmate: router({
    recommend: publicProcedure
      .input(
        z.object({
          mood: z.string(),
          vibe: z.string(),
          nature: z.string(),
          intensity: z.string(),
          ingredient: z.string(),
          season: z.string(),
          budget: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        const prompt = `You are ZUBYR's master perfumer AI. Based on these quiz answers, recommend a specific fragrance profile for this customer.

Quiz answers:
- Fragrance occasion: ${input.mood}
- Desired impression: ${input.vibe}
- Nature environment: ${input.nature}
- Projection preference: ${input.intensity}
- Ingredient preference: ${input.ingredient}
- Season preference: ${input.season}
- Budget level: ${input.budget}

Respond with a short, beautifully written recommendation (3–4 paragraphs max) that:
1. Names a specific fragrance archetype (e.g. "The Dark Resinous Oud" or "The Luminous Floral Musk")
2. Describes the key notes you'd use (top, middle, base)
3. Tells them when and how to wear it
4. Ends with an invitation to visit ZUBYR's showroom or WhatsApp +6581877202 to create a bespoke version

Write in a warm, expert, luxurious tone that befits Singapore's 4th generation master perfumery house. Keep it under 200 words.`;

        const text = await invokeClaude({ prompt, maxTokens: 600 });
        return { text };
      }),
  }),


  products: router({
    list: publicProcedure.input(z.object({ activeOnly: z.boolean().optional() }).optional()).query(({ input }) =>
      getProducts(input?.activeOnly ?? false)
    ),
    byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      getProductById(input.id)
    ),
    create: adminProcedure.input(z.object({
      name: z.string().min(1),
      collection: z.enum(["premium", "signature", "niche", "oud", "collabs"]).optional(),
      description: z.string().optional(),
      scentStory: z.string().optional(),
      topNotes: z.string().optional(),
      middleNotes: z.string().optional(),
      baseNotes: z.string().optional(),
      fragranceFamily: z.string().optional(),
      price: z.string().optional(),
      imageUrl: z.string().optional(),
      active: z.boolean().optional(),
    })).mutation(({ input }) => createProduct(input as any)),
    update: adminProcedure.input(z.object({
      id: z.number(),
      name: z.string().min(1).optional(),
      collection: z.enum(["premium", "signature", "niche", "oud", "collabs"]).optional(),
      description: z.string().optional(),
      scentStory: z.string().optional(),
      topNotes: z.string().optional(),
      middleNotes: z.string().optional(),
      baseNotes: z.string().optional(),
      fragranceFamily: z.string().optional(),
      price: z.string().optional(),
      imageUrl: z.string().optional(),
      active: z.boolean().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return updateProduct(id, data as any);
    }),
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(({ input }) =>
      deleteProduct(input.id)
    ),
  }),

  // ── Workshops ─────────────────────────────────────────────────────────────
  workshops: router({
    list: publicProcedure.input(z.object({ activeOnly: z.boolean().optional() }).optional()).query(({ input }) =>
      getWorkshops(input?.activeOnly ?? false)
    ),
    byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      getWorkshopById(input.id)
    ),
    create: adminProcedure.input(z.object({
      title: z.string().min(1),
      description: z.string().optional(),
      imageUrl: z.string().optional(),
      klookUrl: z.string().optional(),
      whatsappNumber: z.string().optional(),
      price: z.string().optional(),
      duration: z.string().optional(),
      type: z.enum(["group", "private", "corporate", "school"]).optional(),
      active: z.boolean().optional(),
    })).mutation(({ input }) => createWorkshop(input as any)),
    update: adminProcedure.input(z.object({
      id: z.number(),
      title: z.string().optional(),
      description: z.string().optional(),
      imageUrl: z.string().optional(),
      klookUrl: z.string().optional(),
      whatsappNumber: z.string().optional(),
      price: z.string().optional(),
      duration: z.string().optional(),
      type: z.enum(["group", "private", "corporate", "school"]).optional(),
      active: z.boolean().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return updateWorkshop(id, data as any);
    }),
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(({ input }) =>
      deleteWorkshop(input.id)
    ),
  }),

  // ── Blog Posts ────────────────────────────────────────────────────────────
  blog: router({
    list: publicProcedure.input(z.object({
      publishedOnly: z.boolean().optional(),
      category: z.string().optional(),
      adminAll: z.boolean().optional(),
    }).optional()).query(({ input }) =>
      getBlogPosts({ publishedOnly: input?.publishedOnly, category: input?.category, adminAll: input?.adminAll })
    ),
    byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      getBlogPostById(input.id)
    ),
    bySlug: publicProcedure.input(z.object({ slug: z.string() })).query(({ input }) =>
      getBlogPostBySlug(input.slug)
    ),
    create: adminProcedure.input(z.object({
      title: z.string().min(1),
      slug: z.string().min(1),
      content: z.string().optional(),
      excerpt: z.string().optional(),
      category: z.enum(["ingredient_academy","perfume_science","perfumery_school","formula_breakdowns","perfumer_stories","singapore_fragrance_reports","scentmate_insights","workshop_journal","community_spotlight","fragrance_encyclopedia"]).optional(),
      imageUrl: z.string().optional(),
      authorName: z.string().optional(),
      readTime: z.number().optional(),
      tags: z.string().optional(),
      status: z.enum(["draft","pending_review","published","archived"]).optional(),
      published: z.boolean().optional(),
    })).mutation(({ input, ctx }) => createBlogPost({ ...input, authorId: ctx.user.id } as any)),
    update: adminProcedure.input(z.object({
      id: z.number(),
      title: z.string().optional(),
      slug: z.string().optional(),
      content: z.string().optional(),
      excerpt: z.string().optional(),
      category: z.enum(["ingredient_academy","perfume_science","perfumery_school","formula_breakdowns","perfumer_stories","singapore_fragrance_reports","scentmate_insights","workshop_journal","community_spotlight","fragrance_encyclopedia"]).optional(),
      imageUrl: z.string().optional(),
      authorName: z.string().optional(),
      readTime: z.number().optional(),
      tags: z.string().optional(),
      status: z.enum(["draft","pending_review","published","archived"]).optional(),
      published: z.boolean().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return updateBlogPost(id, data as any);
    }),
    publish: adminProcedure.input(z.object({ id: z.number() })).mutation(({ input }) =>
      publishBlogPost(input.id)
    ),
    unpublish: adminProcedure.input(z.object({ id: z.number() })).mutation(({ input }) =>
      unpublishBlogPost(input.id)
    ),
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(({ input }) =>
      deleteBlogPost(input.id)
    ),
  }),

  // ── Community Listings ────────────────────────────────────────────────────
  community: router({
    list: publicProcedure.input(z.object({
      status: z.enum(["pending", "approved", "rejected", "sold"]).optional(),
      search: z.string().optional(),
      listingType: z.enum(["sell", "exchange", "giveaway", "wanted"]).optional(),
    }).optional()).query(({ input }) =>
      getCommunityListings(input ?? undefined)
    ),
    byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      getCommunityListingById(input.id)
    ),
    bySlug: publicProcedure.input(z.object({ slug: z.string() })).query(({ input }) =>
      getCommunityListingBySlug(input.slug)
    ),
    checkTerms: protectedProcedure.query(({ ctx }) =>
      hasUserAcceptedTerms(ctx.user.id)
    ),
    acceptTerms: protectedProcedure.mutation(({ ctx }) =>
      acceptTerms({ userId: ctx.user.id })
    ),
    submit: protectedProcedure.input(z.object({
      perfumeName: z.string().min(1),
      brand: z.string().optional(),
      size: z.string().optional(),
      remainingPercent: z.number().min(0).max(100).optional(),
      condition: z.enum(["new", "like_new", "good", "fair"]).optional(),
      listingType: z.enum(["sell", "exchange", "giveaway", "wanted"]).default("sell"),
      price: z.string().optional(),
      description: z.string().optional(),
      fragranceFamily: z.string().optional(),
      topNotes: z.string().optional(),
      middleNotes: z.string().optional(),
      baseNotes: z.string().optional(),
      concentration: z.enum(["edp", "edt", "edc", "parfum", "oil", "other"]).optional(),
      contactMethod: z.string().optional(),
      imageUrls: z.string().optional(),
    })).mutation(async ({ input, ctx }) => {
      const base = `${input.perfumeName} ${input.brand || ""}`.trim()
        .toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      const slug = `${base}-${Date.now()}`;
      await createCommunityListing({
        ...input,
        slug,
        submitterName: ctx.user.name ?? undefined,
        submitterEmail: ctx.user.email ?? undefined,
        userId: ctx.user.id,
        price: input.price ?? null,
      } as any);
      await sendAdminEmail(
        "New Community Listing Submitted",
        `A new community listing has been submitted for review:\n\nPerfume: ${input.perfumeName}\nBrand: ${input.brand || "N/A"}\nType: ${input.listingType}\nSubmitter: ${ctx.user.name || "Anonymous"}\n\nPlease review it in the admin dashboard.`
      );
      return { success: true, slug };
    }),
    updateStatus: adminProcedure.input(z.object({
      id: z.number(),
      status: z.enum(["pending", "approved", "rejected", "sold"]),
    })).mutation(({ input }) => updateCommunityListingStatus(input.id, input.status)),
    update: adminProcedure.input(z.object({
      id: z.number(),
      perfumeName: z.string().optional(),
      brand: z.string().optional(),
      price: z.string().optional(),
      description: z.string().optional(),
      status: z.enum(["pending", "approved", "rejected", "sold"]).optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return updateCommunityListing(id, data as any);
    }),
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(({ input }) =>
      deleteCommunityListing(input.id)
    ),
  }),

  // ── Newsletter ────────────────────────────────────────────────────────────
  newsletter: router({
    subscribe: publicProcedure.input(z.object({
      email: z.string().email(),
      name: z.string().optional(),
    })).mutation(async ({ input }) => {
      await subscribeNewsletter(input);
      await sendAdminEmail(
        "New Newsletter Subscriber",
        `A new subscriber has joined the ZUBYR newsletter:\n\nEmail: ${input.email}\nName: ${input.name || "Not provided"}`
      );
      return { success: true };
    }),
    list: adminProcedure.query(() => getNewsletterSubscribers()),
  }),

  // ── Contact Enquiries ─────────────────────────────────────────────────────
  contact: router({
    submit: publicProcedure.input(z.object({
      name: z.string().min(1),
      email: z.string().email().optional(),
      phone: z.string().optional(),
      type: z.enum(["general", "careers", "wholesale", "collaboration", "school", "workshop"]).optional(),
      message: z.string().optional(),
    })).mutation(async ({ input }) => {
      await createContactEnquiry(input as any);
      await sendAdminEmail(
        `New Contact Enquiry — ${input.type || "general"}`,
        `New enquiry received:\n\nName: ${input.name}\nEmail: ${input.email || "N/A"}\nPhone: ${input.phone || "N/A"}\nType: ${input.type || "general"}\n\nMessage:\n${input.message || "No message provided"}`
      );
      return { success: true };
    }),
    list: adminProcedure.query(() => getContactEnquiries()),
    markRead: adminProcedure.input(z.object({ id: z.number() })).mutation(({ input }) =>
      markEnquiryRead(input.id)
    ),
  }),

  // ── Jobs ──────────────────────────────────────────────────────────────────
  jobs: router({
    list: publicProcedure.input(z.object({ activeOnly: z.boolean().optional() }).optional()).query(({ input }) =>
      getJobListings(input?.activeOnly ?? true)
    ),
    byId: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      getJobListingById(input.id)
    ),
    applicationCount: publicProcedure.input(z.object({ jobId: z.number() })).query(({ input }) =>
      countJobApplications(input.jobId)
    ),
    create: adminProcedure.input(z.object({
      title: z.string().min(1),
      department: z.string().optional(),
      location: z.string().optional(),
      type: z.enum(["full_time", "part_time", "contract", "internship"]).optional(),
      description: z.string().optional(),
      requirements: z.string().optional(),
      videoTopic: z.string().optional(),
      active: z.boolean().optional(),
    })).mutation(({ input }) => createJobListing(input as any)),
    update: adminProcedure.input(z.object({
      id: z.number(),
      title: z.string().optional(),
      department: z.string().optional(),
      location: z.string().optional(),
      type: z.enum(["full_time", "part_time", "contract", "internship"]).optional(),
      description: z.string().optional(),
      requirements: z.string().optional(),
      videoTopic: z.string().optional(),
      active: z.boolean().optional(),
    })).mutation(({ input }) => {
      const { id, ...data } = input;
      return updateJobListing(id, data as any);
    }),
    delete: adminProcedure.input(z.object({ id: z.number() })).mutation(({ input }) =>
      deleteJobListing(input.id)
    ),
    submitApplication: publicProcedure.input(z.object({
      jobId: z.number(),
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      position: z.string().min(1),
      resumeUrl: z.string().optional(),
      videoUrl: z.string().optional(),
      coverNote: z.string().optional(),
    })).mutation(async ({ input }) => {
      await createJobApplication(input as any);
      await sendAdminEmail(
        `New Job Application — ${input.position}`,
        `A new job application has been received:\n\nPosition: ${input.position}\nName: ${input.name}\nEmail: ${input.email}\nPhone: ${input.phone || "N/A"}\n\nResume: ${input.resumeUrl || "Not uploaded"}\nVideo: ${input.videoUrl || "Not uploaded"}\n\nCover Note:\n${input.coverNote || "None provided"}`
      );
      return { success: true };
    }),
    applications: adminProcedure.input(z.object({ jobId: z.number().optional() }).optional()).query(({ input }) =>
      getJobApplications(input?.jobId)
    ),
  }),

  // ── Wholesale ─────────────────────────────────────────────────────────────
  wholesale: router({
    submit: publicProcedure.input(z.object({
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      productInterest: z.string().optional(),
      message: z.string().optional(),
    })).mutation(async ({ input }) => {
      await createWholesaleInquiry(input);
      await sendAdminEmail(
        "New Wholesale Inquiry",
        `A new wholesale inquiry has been received:\n\nName: ${input.name}\nEmail: ${input.email}\nPhone: ${input.phone || "N/A"}\nProducts of Interest: ${input.productInterest || "N/A"}\n\nMessage:\n${input.message || "None provided"}`
      );
      return { success: true };
    }),
    list: adminProcedure.query(() => getWholesaleInquiries()),
  }),

  // ── Collabs ───────────────────────────────────────────────────────────────
  collabs: router({
    submit: publicProcedure.input(z.object({
      name: z.string().min(1),
      email: z.string().email(),
      phone: z.string().optional(),
      instagram: z.string().optional(),
      tiktok: z.string().optional(),
      youtube: z.string().optional(),
      otherSocials: z.string().optional(),
      message: z.string().optional(),
    })).mutation(async ({ input }) => {
      await createCollabInquiry(input);
      await sendAdminEmail(
        "New Collaboration Inquiry",
        `A new collaboration inquiry has been received:\n\nName: ${input.name}\nEmail: ${input.email}\nPhone: ${input.phone || "N/A"}\n\nSocial Handles:\n  Instagram: ${input.instagram || "N/A"}\n  TikTok: ${input.tiktok || "N/A"}\n  YouTube: ${input.youtube || "N/A"}\n  Other: ${input.otherSocials || "N/A"}\n\nHow we can work together:\n${input.message || "None provided"}`
      );
      return { success: true };
    }),
    list: adminProcedure.query(() => getCollabInquiries()),
  }),

  // ── Ideas ─────────────────────────────────────────────────────────────────
  ideas: router({
    submit: publicProcedure.input(z.object({
      name: z.string().optional(),
      email: z.string().email().optional(),
      idea: z.string().min(10),
    })).mutation(async ({ input }) => {
      await createIdeaSubmission(input);
      await sendAdminEmail(
        "New Idea Submitted",
        `Someone has submitted an idea for ZUBYR:\n\nFrom: ${input.name || "Anonymous"} (${input.email || "no email"})\n\nIdea:\n${input.idea}`
      );
      return { success: true };
    }),
    list: adminProcedure.query(() => getIdeaSubmissions()),
  }),

  // ── Newsletter Issues ─────────────────────────────────────────────────────
  newsletterIssues: router({
    list: publicProcedure.query(() => getNewsletterIssues()),
    bySlug: publicProcedure.input(z.object({ slug: z.string() })).query(({ input }) =>
      getNewsletterIssueBySlug(input.slug)
    ),
    create: adminProcedure.input(z.object({
      title: z.string().min(1),
      slug: z.string().min(1),
      editionType: z.enum(["monday", "friday"]),
      publishedAt: z.string(),
      insideZubyrContent: z.string().optional(),
      worldFragranceContent: z.string().optional(),
      imageUrls: z.string().optional(),
      published: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      await createNewsletterIssue({ ...input, publishedAt: new Date(input.publishedAt) });
      return { success: true };
    }),
    update: adminProcedure.input(z.object({
      id: z.number(),
      title: z.string().optional(),
      insideZubyrContent: z.string().optional(),
      worldFragranceContent: z.string().optional(),
      imageUrls: z.string().optional(),
      published: z.boolean().optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      await updateNewsletterIssue(id, data);
      return { success: true };
    }),
    remove: adminProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await deleteNewsletterIssue(input.id);
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
