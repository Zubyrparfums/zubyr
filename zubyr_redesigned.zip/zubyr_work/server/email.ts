/**
 * Email notification helper for ZUBYR admin.
 * Uses Resend (free tier: 3,000 emails/month) to send notifications to admin@zubyr.co.
 * Set RESEND_API_KEY in environment variables to enable.
 */

const ADMIN_EMAIL = "admin@zubyr.co";
const FROM_EMAIL = "noreply@zubyr.co";
const RESEND_API_URL = "https://api.resend.com/emails";

export async function sendAdminEmail(subject: string, body: string): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;

  if (!apiKey) {
    // Log to console when no API key — email will be sent once key is configured
    console.log(`[Email] Would send to ${ADMIN_EMAIL}: ${subject}\n${body}`);
    return;
  }

  try {
    const response = await fetch(RESEND_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: `ZUBYR Platform <${FROM_EMAIL}>`,
        to: [ADMIN_EMAIL],
        subject: `[ZUBYR] ${subject}`,
        text: body,
        html: `<div style="font-family: Georgia, serif; max-width: 600px; margin: 0 auto; padding: 24px; background: #faf8f4; border-radius: 8px;">
          <div style="text-align: center; margin-bottom: 24px;">
            <h1 style="color: #1a3a2a; font-size: 28px; letter-spacing: 4px; margin: 0;">ZUBYR</h1>
            <p style="color: #8a6a2a; font-size: 12px; letter-spacing: 2px; margin: 4px 0 0;">FRAGRANCE PLATFORM</p>
          </div>
          <div style="background: white; border-radius: 6px; padding: 24px; border-left: 4px solid #1a3a2a;">
            <h2 style="color: #1a3a2a; margin-top: 0;">${subject}</h2>
            <pre style="white-space: pre-wrap; font-family: Georgia, serif; color: #333; line-height: 1.6;">${body}</pre>
          </div>
          <p style="color: #999; font-size: 11px; text-align: center; margin-top: 16px;">ZUBYR Platform — Singapore's Fragrance Ecosystem</p>
        </div>`,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[Email] Failed to send:", error);
    }
  } catch (err) {
    console.error("[Email] Error sending notification:", err);
  }
}
