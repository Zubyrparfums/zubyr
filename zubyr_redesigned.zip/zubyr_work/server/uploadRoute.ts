/**
 * File upload route for career applications (resume + video).
 * Accepts multipart/form-data with a single "file" field.
 * Stores the file in S3 via storagePut and returns the URL.
 */
import { Router } from "express";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

export function registerUploadRoute(app: ReturnType<typeof Router>) {
  // Parse multipart manually using raw body
  (app as any).post("/api/upload", async (req: any, res: any) => {
    try {
      // We receive the file as base64 in JSON body (sent from frontend)
      const { filename, contentType, data } = req.body as {
        filename: string;
        contentType: string;
        data: string; // base64
      };

      if (!data || !filename) {
        return res.status(400).json({ error: "Missing file data or filename" });
      }

      const buffer = Buffer.from(data, "base64");
      const ext = filename.split(".").pop() || "bin";
      const key = `career-uploads/${nanoid(12)}.${ext}`;

      const { url } = await storagePut(key, buffer, contentType || "application/octet-stream");

      return res.json({ url });
    } catch (err: any) {
      console.error("[Upload] Error:", err);
      return res.status(500).json({ error: "Upload failed" });
    }
  });
}
