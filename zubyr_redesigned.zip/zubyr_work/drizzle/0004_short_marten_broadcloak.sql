CREATE TABLE `user_terms_acceptance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`acceptedAt` timestamp NOT NULL DEFAULT (now()),
	`ipAddress` varchar(100),
	CONSTRAINT `user_terms_acceptance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `community_listings` RENAME COLUMN `imageUrl` TO `imageUrls`;--> statement-breakpoint
ALTER TABLE `community_listings` MODIFY COLUMN `status` enum('pending','approved','rejected','sold') NOT NULL DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE `community_listings` ADD `slug` varchar(500) NOT NULL;--> statement-breakpoint
ALTER TABLE `community_listings` ADD `listingType` enum('sell','exchange','giveaway','wanted') DEFAULT 'sell' NOT NULL;--> statement-breakpoint
ALTER TABLE `community_listings` ADD `fragranceFamily` varchar(100);--> statement-breakpoint
ALTER TABLE `community_listings` ADD `topNotes` varchar(255);--> statement-breakpoint
ALTER TABLE `community_listings` ADD `middleNotes` varchar(255);--> statement-breakpoint
ALTER TABLE `community_listings` ADD `baseNotes` varchar(255);--> statement-breakpoint
ALTER TABLE `community_listings` ADD `concentration` enum('edp','edt','edc','parfum','oil','other') DEFAULT 'edp';--> statement-breakpoint
ALTER TABLE `community_listings` ADD `viewCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `community_listings` ADD CONSTRAINT `community_listings_slug_unique` UNIQUE(`slug`);