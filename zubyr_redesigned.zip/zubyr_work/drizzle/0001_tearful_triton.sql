CREATE TABLE `blog_posts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`slug` varchar(500) NOT NULL,
	`content` text,
	`excerpt` text,
	`category` enum('perfume_education','perfume_ingredients','perfume_care','perfume_workshops','buying_guides','singapore_trends') DEFAULT 'perfume_education',
	`imageUrl` text,
	`published` boolean NOT NULL DEFAULT false,
	`authorId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `blog_posts_id` PRIMARY KEY(`id`),
	CONSTRAINT `blog_posts_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `community_listings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`perfumeName` varchar(255) NOT NULL,
	`brand` varchar(255),
	`size` varchar(50),
	`remainingPercent` int,
	`condition` enum('new','like_new','good','fair') DEFAULT 'good',
	`price` decimal(10,2),
	`description` text,
	`contactMethod` varchar(255),
	`imageUrl` text,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`submitterName` varchar(255),
	`submitterEmail` varchar(320),
	`userId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `community_listings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contact_enquiries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(50),
	`type` enum('general','careers','wholesale','collaboration','school','workshop') DEFAULT 'general',
	`message` text,
	`read` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `contact_enquiries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `newsletter_subscribers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`name` varchar(255),
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `newsletter_subscribers_id` PRIMARY KEY(`id`),
	CONSTRAINT `newsletter_subscribers_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`collection` enum('premium','signature','niche','oud','collabs') NOT NULL DEFAULT 'signature',
	`description` text,
	`scentStory` text,
	`topNotes` text,
	`middleNotes` text,
	`baseNotes` text,
	`fragranceFamily` varchar(100),
	`price` decimal(10,2),
	`imageUrl` text,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `workshops` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`imageUrl` text,
	`klookUrl` text,
	`whatsappNumber` varchar(30),
	`price` decimal(10,2),
	`duration` varchar(100),
	`type` enum('group','private','corporate','school') DEFAULT 'group',
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `workshops_id` PRIMARY KEY(`id`)
);
