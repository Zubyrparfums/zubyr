CREATE TABLE `newsletter_issues` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(500) NOT NULL,
	`slug` varchar(500) NOT NULL,
	`editionType` enum('monday','friday') NOT NULL,
	`publishedAt` timestamp NOT NULL,
	`insideZubyrContent` text,
	`worldFragranceContent` text,
	`imageUrls` text,
	`published` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `newsletter_issues_id` PRIMARY KEY(`id`),
	CONSTRAINT `newsletter_issues_slug_unique` UNIQUE(`slug`)
);
