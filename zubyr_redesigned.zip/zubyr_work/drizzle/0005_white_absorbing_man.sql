ALTER TABLE `blog_posts` MODIFY COLUMN `category` enum('ingredient_academy','perfume_science','perfumery_school','formula_breakdowns','perfumer_stories','singapore_fragrance_reports','scentmate_insights','workshop_journal','community_spotlight','fragrance_encyclopedia') DEFAULT 'perfume_science';--> statement-breakpoint
ALTER TABLE `blog_posts` ADD `status` enum('draft','pending_review','published','archived') DEFAULT 'draft' NOT NULL;--> statement-breakpoint
ALTER TABLE `blog_posts` ADD `authorName` varchar(255) DEFAULT 'ZUBYR Editorial';--> statement-breakpoint
ALTER TABLE `blog_posts` ADD `readTime` int DEFAULT 5;--> statement-breakpoint
ALTER TABLE `blog_posts` ADD `tags` text;