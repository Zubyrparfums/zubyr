import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  decimal,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  /** bcrypt hash, used by the standalone email/password login (see server/_core/standaloneAuth.ts) */
  passwordHash: varchar("passwordHash", { length: 255 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Products
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  collection: mysqlEnum("collection", [
    "premium",
    "signature",
    "niche",
    "oud",
    "collabs",
  ])
    .default("signature")
    .notNull(),
  description: text("description"),
  scentStory: text("scentStory"),
  topNotes: text("topNotes"),
  middleNotes: text("middleNotes"),
  baseNotes: text("baseNotes"),
  fragranceFamily: varchar("fragranceFamily", { length: 100 }),
  price: decimal("price", { precision: 10, scale: 2 }),
  imageUrl: text("imageUrl"),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

// Workshops
export const workshops = mysqlTable("workshops", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: text("imageUrl"),
  klookUrl: text("klookUrl"),
  whatsappNumber: varchar("whatsappNumber", { length: 30 }),
  price: decimal("price", { precision: 10, scale: 2 }),
  duration: varchar("duration", { length: 100 }),
  type: mysqlEnum("type", ["group", "private", "corporate", "school"]).default(
    "group"
  ),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Workshop = typeof workshops.$inferSelect;
export type InsertWorkshop = typeof workshops.$inferInsert;

// Blog Posts
export const blogPosts = mysqlTable("blog_posts", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  slug: varchar("slug", { length: 500 }).notNull().unique(),
  content: text("content"),
  excerpt: text("excerpt"),
  category: mysqlEnum("category", [
    "ingredient_academy",
    "perfume_science",
    "perfumery_school",
    "formula_breakdowns",
    "perfumer_stories",
    "singapore_fragrance_reports",
    "scentmate_insights",
    "workshop_journal",
    "community_spotlight",
    "fragrance_encyclopedia",
  ]).default("perfume_science"),
  imageUrl: text("imageUrl"),
  status: mysqlEnum("status", ["draft", "pending_review", "published", "archived"]).default("draft").notNull(),
  published: boolean("published").default(false).notNull(),
  authorName: varchar("authorName", { length: 255 }).default("ZUBYR Editorial"),
  readTime: int("readTime").default(5),
  tags: text("tags"), // JSON array of tag strings
  authorId: int("authorId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = typeof blogPosts.$inferInsert;

// Community Listings
export const communityListings = mysqlTable("community_listings", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 500 }).notNull().unique(),
  perfumeName: varchar("perfumeName", { length: 255 }).notNull(),
  brand: varchar("brand", { length: 255 }),
  size: varchar("size", { length: 50 }),
  remainingPercent: int("remainingPercent"),
  condition: mysqlEnum("condition", ["new", "like_new", "good", "fair"]).default("good"),
  listingType: mysqlEnum("listingType", ["sell", "exchange", "giveaway", "wanted"]).default("sell").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }),
  description: text("description"),
  fragranceFamily: varchar("fragranceFamily", { length: 100 }),
  topNotes: varchar("topNotes", { length: 255 }),
  middleNotes: varchar("middleNotes", { length: 255 }),
  baseNotes: varchar("baseNotes", { length: 255 }),
  concentration: mysqlEnum("concentration", ["edp", "edt", "edc", "parfum", "oil", "other"]).default("edp"),
  contactMethod: varchar("contactMethod", { length: 255 }),
  imageUrls: text("imageUrls"), // JSON array of image URLs
  status: mysqlEnum("status", ["pending", "approved", "rejected", "sold"]).default("pending").notNull(),
  submitterName: varchar("submitterName", { length: 255 }),
  submitterEmail: varchar("submitterEmail", { length: 320 }),
  userId: int("userId"),
  viewCount: int("viewCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunityListing = typeof communityListings.$inferSelect;
export type InsertCommunityListing = typeof communityListings.$inferInsert;

// User Terms Acceptance
export const userTermsAcceptance = mysqlTable("user_terms_acceptance", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  acceptedAt: timestamp("acceptedAt").defaultNow().notNull(),
  ipAddress: varchar("ipAddress", { length: 100 }),
});

export type UserTermsAcceptance = typeof userTermsAcceptance.$inferSelect;
export type InsertUserTermsAcceptance = typeof userTermsAcceptance.$inferInsert;

// Newsletter Subscribers
export const newsletterSubscribers = mysqlTable("newsletter_subscribers", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;
export type InsertNewsletterSubscriber =
  typeof newsletterSubscribers.$inferInsert;

// Contact Enquiries
export const contactEnquiries = mysqlTable("contact_enquiries", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  type: mysqlEnum("type", [
    "general",
    "careers",
    "wholesale",
    "collaboration",
    "school",
    "workshop",
  ]).default("general"),
  message: text("message"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContactEnquiry = typeof contactEnquiries.$inferSelect;
export type InsertContactEnquiry = typeof contactEnquiries.$inferInsert;

// Job Listings
export const jobListings = mysqlTable("job_listings", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  department: varchar("department", { length: 100 }),
  location: varchar("location", { length: 100 }).default("Singapore"),
  type: mysqlEnum("type", ["full_time", "part_time", "contract", "internship"]).default("full_time"),
  description: text("description"),
  requirements: text("requirements"),
  videoTopic: text("videoTopic"),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type JobListing = typeof jobListings.$inferSelect;
export type InsertJobListing = typeof jobListings.$inferInsert;

// Job Applications
export const jobApplications = mysqlTable("job_applications", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("jobId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  position: varchar("position", { length: 255 }).notNull(),
  resumeUrl: text("resumeUrl"),
  videoUrl: text("videoUrl"),
  coverNote: text("coverNote"),
  status: mysqlEnum("status", ["new", "reviewing", "shortlisted", "rejected"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type JobApplication = typeof jobApplications.$inferSelect;
export type InsertJobApplication = typeof jobApplications.$inferInsert;

// Wholesale Inquiries
export const wholesaleInquiries = mysqlTable("wholesale_inquiries", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  productInterest: varchar("productInterest", { length: 500 }),
  message: text("message"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WholesaleInquiry = typeof wholesaleInquiries.$inferSelect;
export type InsertWholesaleInquiry = typeof wholesaleInquiries.$inferInsert;

// Collab Inquiries
export const collabInquiries = mysqlTable("collab_inquiries", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  instagram: varchar("instagram", { length: 255 }),
  tiktok: varchar("tiktok", { length: 255 }),
  youtube: varchar("youtube", { length: 255 }),
  otherSocials: varchar("otherSocials", { length: 500 }),
  message: text("message"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CollabInquiry = typeof collabInquiries.$inferSelect;
export type InsertCollabInquiry = typeof collabInquiries.$inferInsert;

// Idea Submissions
export const ideaSubmissions = mysqlTable("idea_submissions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  idea: text("idea").notNull(),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type IdeaSubmission = typeof ideaSubmissions.$inferSelect;
export type InsertIdeaSubmission = typeof ideaSubmissions.$inferInsert;

// Newsletter Issues
export const newsletterIssues = mysqlTable("newsletter_issues", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  slug: varchar("slug", { length: 500 }).notNull().unique(),
  editionType: mysqlEnum("editionType", ["monday", "friday"]).notNull(),
  publishedAt: timestamp("publishedAt").notNull(),
  insideZubyrContent: text("insideZubyrContent"),
  worldFragranceContent: text("worldFragranceContent"),
  imageUrls: text("imageUrls"), // JSON array of image URLs
  published: boolean("published").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NewsletterIssue = typeof newsletterIssues.$inferSelect;
export type InsertNewsletterIssue = typeof newsletterIssues.$inferInsert;
