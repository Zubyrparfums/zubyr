# ZUBYR — Deploy & Run Guide

This app no longer depends on Manus's platform for login or AI. It now uses its own
email/password authentication and calls the Anthropic API directly. It's a standard
Node.js + Express + tRPC + MySQL app and can be deployed anywhere that runs Node.

---

## ⚡ Run it locally (~5 min)

You'll need [Node.js 20+](https://nodejs.org).

```bash
cd zubyr_work
npm install -g pnpm        # if you don't have pnpm yet
pnpm install
cp .env.example .env       # then fill in the values below
pnpm dev
```

Open **http://localhost:3000**.

**Works immediately, no setup:** Home, Shop, ScentMate AI quiz (needs `ANTHROPIC_API_KEY` to
actually generate a recommendation), Blog, Newsletter, Contact, Careers, Wholesale, Collabs,
Ideas, Community marketplace browsing.

**Needs a database (`DATABASE_URL`):** saving form submissions, blog/product content, account
registration & login, admin dashboard.

Without a database connected, pages render with empty states ("No products yet" etc.) instead
of crashing, so you can browse every page's design without one.

---

## 🔑 Environment variables

Copy `.env.example` → `.env` and fill in:

| Variable | Required for | Notes |
|---|---|---|
| `DATABASE_URL` | Any saved data, login/admin | MySQL connection string, e.g. `mysql://user:pass@host:3306/zubyr` |
| `JWT_SECRET` | Login sessions | Any long random string |
| `ANTHROPIC_API_KEY` | ScentMate AI quiz | Get one free at console.anthropic.com |
| `ADMIN_EMAIL` | Optional | If set, this email always gets admin on registration. Otherwise the **first account ever created** becomes admin automatically. |

---

## 👤 Creating your admin account

1. Get the site running (locally or deployed) with `DATABASE_URL` set
2. Run the database migrations once: `pnpm db:push`
3. Visit `/login`, switch to "Register", and create an account
4. That first account is automatically made admin — no manual DB editing needed
5. Visit `/admin` to manage products, workshops, blog, newsletter, and all enquiries

If you want a specific email to always become admin (e.g. for a teammate registering later
too), set `ADMIN_EMAIL=you@zubyr.co` before they register.

---

## 🌐 Deploying somewhere public

This needs a running Node.js **server** (not static hosting) plus a **MySQL database**.
**Railway** or **Render** are the simplest — both give you a server + database in one place.

### Railway (recommended)
1. Push this folder to a GitHub repo
2. railway.app → New Project → Deploy from GitHub repo
3. Add a **MySQL** database from Railway's plugin marketplace (one click)
4. Railway auto-detects `pnpm build` / `pnpm start`
5. Set the environment variables above in Railway's dashboard
6. Run `pnpm db:push` once (Railway's shell, or locally pointed at the Railway DB URL)
7. Visit your `*.up.railway.app` URL, register your admin account, you're live

### Render
Same idea: "New Web Service" from your repo, add a MySQL instance (Render's own, or an
external one like PlanetScale), set env vars, deploy, run the migration once.

---

## What changed from the original build

The original codebase (built on Manus) used Manus's own OAuth login service and an internal
AI proxy ("Forge"), which only worked while hosted on Manus's platform. Those have been fully
replaced:

- **Login** → standalone email/password auth (`server/_core/standaloneAuth.ts`), bcrypt-hashed
  passwords, JWT session cookies. New login/register page at `/login`.
- **AI (ScentMate quiz)** → calls the Anthropic API directly server-side
  (`server/_core/anthropic.ts`), using your own `ANTHROPIC_API_KEY`. The API key never touches
  the browser.

Everything else — the database schema, all the page designs, the admin panel, the tRPC
routers — is unchanged and works exactly as before. The app now has zero dependency on Manus
and will run on any standard Node.js host.

---

## Verified in testing

- `pnpm check` (TypeScript) passes with zero errors
- Server boots cleanly with no environment variables set at all
- All public pages (Home, Shop, Blog, Login, Contact, etc.) return 200 with no database
  connected
- `products.list` and similar queries return empty arrays gracefully instead of erroring
- Registering an account without `DATABASE_URL` set returns a clean
  `"Database not configured"` error instead of hanging or crashing the server
- The ScentMate AI endpoint returns a clean error if `ANTHROPIC_API_KEY` is missing, without
  affecting the rest of the site
