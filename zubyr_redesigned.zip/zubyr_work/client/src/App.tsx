import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Contact from "./pages/Contact";
import Careers from "./pages/Careers";
import Wholesale from "./pages/Wholesale";
import Collabs from "./pages/Collabs";
import GiveUsIdeas from "./pages/GiveUsIdeas";
import Newsletter from "./pages/Newsletter";
import NewsletterIssue from "./pages/NewsletterIssue";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminWorkshops from "./pages/admin/AdminWorkshops";
import AdminBlog from "./pages/admin/AdminBlog";
import AdminCommunity from "./pages/admin/AdminCommunity";
import AdminNewsletter from "./pages/admin/AdminNewsletter";
import AdminEnquiries from "./pages/admin/AdminEnquiries";
import Community from "./pages/Community";
import CommunityListing from "./pages/CommunityListing";
import Blog from "./pages/Blog";
import BlogArticle from "./pages/BlogArticle";
import Shop from "./pages/Shop";
import ScentMate from "./pages/ScentMate";
import Login from "./pages/Login";

const PINE="#2d4a3e",FOREST="#1a3028",SPICE="#8B3A1A",CREAM="#F2EDE4",STONE="#9A8A78";

function ComingSoon({ title }: { title: string }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 font-serif" style={{ background: CREAM }}>
      <div className="text-center">
        <p className="font-sans font-bold text-xs tracking-[0.24em] uppercase mb-3" style={{color:SPICE}}>Coming Soon</p>
        <h1 className="text-3xl font-bold tracking-[0.15em] uppercase mb-2" style={{ color: FOREST }}>ZUBYR</h1>
        <p className="font-sans text-sm mb-2" style={{ color: STONE }}>{title}</p>
        <p className="font-sans text-xs mb-8" style={{ color: "rgba(26,48,40,0.40)" }}>This module is launching soon.</p>
        <a href="/" className="inline-block px-6 py-3 rounded-xl font-sans font-semibold text-sm" style={{ background: PINE, color: "#fff" }}>
          ← Back to Home
        </a>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      {/* Public */}
      <Route path="/" component={Home} />
      <Route path="/contact" component={Contact} />
      <Route path="/careers" component={Careers} />
      <Route path="/wholesale" component={Wholesale} />
      <Route path="/collaborations" component={Collabs} />
      <Route path="/ideas" component={GiveUsIdeas} />
      <Route path="/shop" component={Shop} />
      <Route path="/scentmate" component={ScentMate} />
      <Route path="/login" component={Login} />

      {/* Admin */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/products" component={AdminProducts} />
      <Route path="/admin/workshops" component={AdminWorkshops} />
      <Route path="/admin/blog" component={AdminBlog} />
      <Route path="/admin/community" component={AdminCommunity} />
      <Route path="/admin/newsletter" component={AdminNewsletter} />
      <Route path="/admin/enquiries" component={AdminEnquiries} />

      {/* Coming soon */}
      <Route path="/concierge"    component={() => <ComingSoon title="Fragrance Concierge" />} />
      <Route path="/ingredients"  component={() => <ComingSoon title="Ingredient Library" />} />
      <Route path="/formulations" component={() => <ComingSoon title="Formulation Marketplace" />} />
      <Route path="/school"       component={() => <ComingSoon title="Perfumery School" />} />
      <Route path="/workshop"     component={() => <ComingSoon title="Book a Workshop" />} />

      {/* Content */}
      <Route path="/blog"                 component={Blog} />
      <Route path="/blog/:slug"           component={BlogArticle} />
      <Route path="/community"            component={Community} />
      <Route path="/community/:slug"      component={CommunityListing} />
      <Route path="/newsletter"           component={Newsletter} />
      <Route path="/newsletter/:slug"     component={NewsletterIssue} />

      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
