import { useParams, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Calendar, BookOpen, Globe, Clock } from "lucide-react";

function formatDate(d: Date | string) {
  return new Date(d).toLocaleDateString("en-SG", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function renderParagraphs(text: string) {
  return text.split("\n\n").map((para, i) => (
    <p key={i} className="mb-4 leading-relaxed text-[#3a2e22] text-sm">
      {para}
    </p>
  ));
}

export default function NewsletterIssue() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug;

  const { data: issue, isLoading, error } = trpc.newsletterIssues.bySlug.useQuery(
    { slug: slug ?? "" },
    { enabled: !!slug }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#f5f0e8] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-[#0d3320] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error || !issue) {
    return (
      <div className="min-h-screen bg-[#f5f0e8] flex flex-col items-center justify-center px-6 text-center">
        <h1 className="font-serif text-3xl text-[#0d3320] mb-3">Issue Not Found</h1>
        <p className="text-sm text-[#7a6a58] mb-6">This newsletter issue doesn't exist or has been removed.</p>
        <Link href="/newsletter">
          <button className="px-6 py-3 rounded-xl bg-[#0d3320] text-white text-sm font-semibold">
            ← Back to Newsletter
          </button>
        </Link>
      </div>
    );
  }

  const isMonday = issue.editionType === "monday";
  const images: string[] = (() => {
    try { return JSON.parse(issue.imageUrls ?? "[]"); } catch { return []; }
  })();

  return (
    <div className="min-h-screen bg-[#f5f0e8]">
      {/* SEO-friendly meta — title reflects the issue */}
      <title>{`${issue.title} | Weekly Newsletter by ZUBYR`}</title>

      {/* Header */}
      <div className={`${isMonday ? "bg-[#0d3320]" : "bg-[#8b3a0f]"} px-5 pt-12 pb-10`}>
        <Link href="/newsletter">
          <button
            className="flex items-center gap-2 text-sm mb-6 opacity-80 hover:opacity-100 transition-opacity"
            style={{ color: isMonday ? "#c9a84c" : "#f5e6c8" }}
          >
            <ArrowLeft size={16} />
            All issues
          </button>
        </Link>

        <div
          className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase mb-3 opacity-80"
          style={{ color: isMonday ? "#c9a84c" : "#f5e6c8" }}
        >
          <Clock size={12} />
          {isMonday ? "Monday Edition — While You Were Away" : "Friday Edition — While You Were Busy"}
        </div>

        <h1 className="font-serif text-3xl text-white leading-tight mb-3">{issue.title}</h1>

        <div
          className="flex items-center gap-2 text-sm opacity-70"
          style={{ color: isMonday ? "#c9a84c" : "#f5e6c8" }}
        >
          <Calendar size={13} />
          <span>{formatDate(issue.publishedAt)}</span>
        </div>
      </div>

      {/* Content */}
      <div className="px-5 py-8 max-w-2xl mx-auto">

        {/* Section 1 — Inside ZUBYR */}
        {issue.insideZubyrContent && (
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-1 h-6 bg-[#0d3320] rounded-full" />
              <div className="flex items-center gap-2">
                <BookOpen size={15} className="text-[#0d3320]" />
                <h2 className="font-serif text-xl text-[#0d3320]">Inside ZUBYR</h2>
              </div>
            </div>
            {renderParagraphs(issue.insideZubyrContent)}
          </div>
        )}

        {/* Divider */}
        <div className="flex items-center gap-3 my-8">
          <div className="flex-1 h-px bg-[#d4c9b8]" />
          <span className="text-xs tracking-widest uppercase text-[#9a8a78]">Around the World</span>
          <div className="flex-1 h-px bg-[#d4c9b8]" />
        </div>

        {/* Section 2 — Around the World of Fragrance */}
        {issue.worldFragranceContent && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-1 h-6 bg-[#8b3a0f] rounded-full" />
              <div className="flex items-center gap-2">
                <Globe size={15} className="text-[#8b3a0f]" />
                <h2 className="font-serif text-xl text-[#0d3320]">Around the World of Fragrance</h2>
              </div>
            </div>
            {renderParagraphs(issue.worldFragranceContent)}
          </div>
        )}

        {/* Images */}
        {images.length > 0 && (
          <div className={`grid gap-3 mb-8 ${images.length === 1 ? "grid-cols-1" : "grid-cols-2"}`}>
            {images.map((url, i) => (
              <img
                key={i}
                src={url}
                alt={`${issue.title} — image ${i + 1}`}
                className={`w-full rounded-xl object-cover ${images.length === 3 && i === 0 ? "col-span-2 h-52" : "h-40"}`}
                loading="lazy"
              />
            ))}
          </div>
        )}

        {/* Subscribe CTA */}
        <div className="rounded-2xl bg-[#0d3320] text-white p-6 text-center mt-8">
          <p className="font-serif text-xl mb-1">Enjoyed this issue?</p>
          <p className="text-sm opacity-70 mb-4">
            Get the ZUBYR newsletter every Monday and Friday — what happened inside ZUBYR and around the world of fragrance.
          </p>
          <Link href="/newsletter">
            <button className="px-6 py-3 rounded-xl bg-[#c9a84c] text-[#0d3320] font-semibold text-sm hover:bg-[#d4b85c] transition-colors">
              Subscribe — It's Free
            </button>
          </Link>
        </div>

        {/* Back link */}
        <div className="mt-8 text-center">
          <Link href="/newsletter">
            <button className="text-sm text-[#0d3320] font-semibold underline underline-offset-2 opacity-70 hover:opacity-100 transition-opacity">
              ← View all issues
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
