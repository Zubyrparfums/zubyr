import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import {
  Search, Plus, Filter, ChevronRight, ArrowLeft, Tag, Repeat2,
  Gift, ShoppingBag, Eye, Clock, CheckCircle, XCircle, AlertCircle,
  Upload, X, Loader2, Star
} from "lucide-react";
import { getLoginUrl } from "@/const";

// ── Helpers ───────────────────────────────────────────────────────────────────

function slugify(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function formatPrice(price: string | null | undefined) {
  if (!price) return "Free / Offer";
  const n = parseFloat(price);
  return isNaN(n) ? price : `S$${n.toFixed(2)}`;
}

function formatDate(d: Date | string) {
  return new Date(d).toLocaleDateString("en-SG", { day: "numeric", month: "short", year: "numeric" });
}

const LISTING_TYPE_LABELS: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  sell:     { label: "For Sale",  icon: <Tag size={11} />,       color: "bg-emerald-100 text-emerald-700" },
  exchange: { label: "Exchange",  icon: <Repeat2 size={11} />,   color: "bg-blue-100 text-blue-700" },
  giveaway: { label: "Giveaway",  icon: <Gift size={11} />,      color: "bg-amber-100 text-amber-700" },
  wanted:   { label: "Wanted",    icon: <ShoppingBag size={11} />, color: "bg-purple-100 text-purple-700" },
};

const CONDITION_LABELS: Record<string, string> = {
  new: "Brand New", like_new: "Like New", good: "Good", fair: "Fair",
};

// ── T&C Modal ─────────────────────────────────────────────────────────────────

const TERMS_AND_CONDITIONS = `ZUBYR COMMUNITY MARKETPLACE — TERMS & CONDITIONS

Last updated: June 2025

Welcome to the ZUBYR Community Marketplace ("Marketplace"). By accepting these Terms & Conditions, you agree to be bound by the following rules. Please read them carefully before participating.

1. PLATFORM ROLE & DISCLAIMER

1.1 ZUBYR operates solely as a neutral facilitating platform ("Platform") that connects buyers, sellers, and traders of fragrance products. ZUBYR is not a party to any transaction between users.

1.2 ZUBYR does not verify, endorse, or guarantee the accuracy of any listing, the quality of any product, or the identity of any user. All transactions are conducted entirely at your own risk.

1.3 ZUBYR accepts no liability for any loss, damage, dispute, or harm arising from transactions facilitated through the Marketplace.

2. AUTHENTICITY & PROHIBITED LISTINGS

2.1 STRICTLY NO COUNTERFEIT OR FAKE PRODUCTS. You are absolutely prohibited from listing, selling, or trading any fragrance product that:
  (a) Is counterfeit, replica, or imitation of a genuine brand;
  (b) Is falsely described as authentic when it is not;
  (c) Has been tampered with, refilled, or adulterated;
  (d) Infringes any trademark, copyright, or intellectual property right.

2.2 Violation of Section 2.1 will result in immediate and permanent removal of your listing and account, and may be reported to the relevant authorities.

2.3 You must accurately describe the condition, fill level, and authenticity of every product you list.

3. USER RESPONSIBILITIES

3.1 You must be at least 18 years of age to participate in the Marketplace.

3.2 You are solely responsible for the accuracy and completeness of your listings.

3.3 You must honour any agreement you enter into with another user through the Marketplace.

3.4 You must not engage in fraudulent, misleading, or deceptive conduct of any kind.

3.5 You must not use the Marketplace to sell products that are illegal, hazardous, or otherwise prohibited under Singapore law.

4. LISTING APPROVAL

4.1 All listings are subject to review and approval by ZUBYR before they are published on the Marketplace.

4.2 ZUBYR reserves the right to reject, remove, or modify any listing at its sole discretion, without notice or explanation.

4.3 Approval of a listing does not constitute ZUBYR's endorsement of the product or the seller.

5. PRICING & TRANSACTIONS

5.1 All prices must be listed in Singapore Dollars (SGD) unless otherwise specified.

5.2 ZUBYR does not process payments between users. All payment arrangements are made directly between buyer and seller.

5.3 ZUBYR strongly recommends using secure, traceable payment methods and meeting in safe, public locations.

6. INTELLECTUAL PROPERTY

6.1 By submitting images and content to the Marketplace, you grant ZUBYR a non-exclusive, royalty-free licence to display that content on the Platform.

6.2 You confirm that you own or have the right to use all images and content you submit.

7. PRIVACY

7.1 Your personal information is collected and processed in accordance with ZUBYR's Privacy Policy.

7.2 Do not share sensitive personal information (such as your full address or financial details) in public listing descriptions.

8. ENFORCEMENT & TERMINATION

8.1 ZUBYR reserves the right to suspend or permanently ban any user who violates these Terms & Conditions.

8.2 ZUBYR may modify these Terms & Conditions at any time. Continued use of the Marketplace constitutes acceptance of the updated terms.

9. GOVERNING LAW

9.1 These Terms & Conditions are governed by the laws of the Republic of Singapore.

9.2 Any dispute arising from or in connection with these Terms shall be subject to the exclusive jurisdiction of the courts of Singapore.

BY CLICKING "I ACCEPT", YOU CONFIRM THAT YOU HAVE READ, UNDERSTOOD, AND AGREE TO BE BOUND BY THESE TERMS & CONDITIONS IN FULL.`;

function TermsModal({ onAccept, onClose }: { onAccept: () => void; onClose: () => void }) {
  const [scrolledToBottom, setScrolledToBottom] = useState(false);
  const [accepting, setAccepting] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const acceptTermsMutation = trpc.community.acceptTerms.useMutation();

  function handleScroll() {
    const el = scrollRef.current;
    if (!el) return;
    if (el.scrollTop + el.clientHeight >= el.scrollHeight - 20) {
      setScrolledToBottom(true);
    }
  }

  async function handleAccept() {
    setAccepting(true);
    try {
      await acceptTermsMutation.mutateAsync();
      onAccept();
    } catch {
      toast.error("Failed to record acceptance. Please try again.");
    } finally {
      setAccepting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm px-0 sm:px-4">
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-[#0d3320] px-6 py-5 flex-shrink-0">
          <div className="flex items-center gap-3">
            <AlertCircle size={20} className="text-[#c9a84c]" />
            <div>
              <h2 className="font-serif text-lg text-white">Community Marketplace</h2>
              <p className="text-xs text-white/60 mt-0.5">Terms & Conditions — scroll to read fully</p>
            </div>
          </div>
        </div>

        {/* Scroll progress bar */}
        <div className="h-1 bg-[#e8e0d4] flex-shrink-0">
          <div
            className="h-full bg-[#c9a84c] transition-all duration-300"
            style={{ width: scrolledToBottom ? "100%" : "0%" }}
          />
        </div>

        {/* T&C content */}
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-6 py-5 text-xs text-[#3a2e22] leading-relaxed whitespace-pre-wrap font-mono bg-[#faf8f4]"
        >
          {TERMS_AND_CONDITIONS}
        </div>

        {/* Footer */}
        <div className="px-6 py-5 bg-white border-t border-[#e8e0d4] flex-shrink-0">
          {!scrolledToBottom && (
            <p className="text-xs text-[#9a8a78] text-center mb-3 flex items-center justify-center gap-1">
              <span>↓</span> Scroll to the bottom to accept
            </p>
          )}
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-[#d4c9b8] text-sm text-[#7a6a58] font-semibold hover:bg-[#f5f0e8] transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleAccept}
              disabled={!scrolledToBottom || accepting}
              className="flex-1 py-3 rounded-xl bg-[#0d3320] text-white text-sm font-semibold disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#0a2818] transition-colors flex items-center justify-center gap-2"
            >
              {accepting ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle size={14} />}
              I Accept
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Listing Card ──────────────────────────────────────────────────────────────

function ListingCard({ listing }: { listing: any }) {
  const typeInfo = LISTING_TYPE_LABELS[listing.listingType] ?? LISTING_TYPE_LABELS.sell;
  const images: string[] = (() => { try { return JSON.parse(listing.imageUrls ?? "[]"); } catch { return []; } })();

  return (
    <Link href={`/community/${listing.slug}`}>
      <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-[#e8e0d4] hover:shadow-md transition-all duration-200 active:scale-[0.98] cursor-pointer">
        {/* Image */}
        <div className="aspect-square bg-[#f5f0e8] relative overflow-hidden">
          {images[0] ? (
            <img src={images[0]} alt={listing.perfumeName} className="w-full h-full object-cover" loading="lazy" />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center gap-2">
              <div className="w-12 h-12 rounded-full bg-[#e8e0d4] flex items-center justify-center">
                <span className="text-xl">🌿</span>
              </div>
              <span className="text-xs text-[#9a8a78]">No image</span>
            </div>
          )}
          {/* Type badge */}
          <div className={`absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold ${typeInfo.color}`}>
            {typeInfo.icon}
            {typeInfo.label}
          </div>
        </div>

        {/* Info */}
        <div className="p-3">
          <p className="font-semibold text-sm text-[#1a1a1a] truncate">{listing.perfumeName}</p>
          {listing.brand && <p className="text-xs text-[#7a6a58] truncate">{listing.brand}</p>}
          <div className="flex items-center justify-between mt-2">
            <span className="text-sm font-bold text-[#0d3320]">{formatPrice(listing.price)}</span>
            {listing.condition && (
              <span className="text-xs text-[#9a8a78]">{CONDITION_LABELS[listing.condition] ?? listing.condition}</span>
            )}
          </div>
          <div className="flex items-center gap-1 mt-1.5 text-xs text-[#9a8a78]">
            <Eye size={11} />
            <span>{listing.viewCount ?? 0} views</span>
            <span className="mx-1">·</span>
            <Clock size={11} />
            <span>{formatDate(listing.createdAt)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}

// ── Post Listing Form ─────────────────────────────────────────────────────────

function PostListingForm({ onSuccess, onCancel }: { onSuccess: (slug: string) => void; onCancel: () => void }) {
  const [form, setForm] = useState({
    perfumeName: "", brand: "", size: "", remainingPercent: "",
    condition: "good" as "new" | "like_new" | "good" | "fair",
    listingType: "sell" as "sell" | "exchange" | "giveaway" | "wanted",
    price: "", description: "",
    fragranceFamily: "", topNotes: "", middleNotes: "", baseNotes: "",
    concentration: "edp" as "edp" | "edt" | "edc" | "parfum" | "oil" | "other",
    contactMethod: "",
  });
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const submitMutation = trpc.community.submit.useMutation();

  async function uploadImage(file: File) {
    setUploading(true);
    try {
      const buffer = await file.arrayBuffer();
      const base64 = btoa(Array.from(new Uint8Array(buffer)).map(b => String.fromCharCode(b)).join(""));
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filename: file.name, contentType: file.type, data: base64 }),
      });
      const { url } = await res.json();
      setImages(prev => [...prev, url]);
    } catch {
      toast.error("Image upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.perfumeName.trim()) { toast.error("Perfume name is required."); return; }
    try {
      const result = await submitMutation.mutateAsync({
        ...form,
        remainingPercent: form.remainingPercent ? parseInt(form.remainingPercent) : undefined,
        imageUrls: JSON.stringify(images),
      });
      toast.success("Listing submitted for review! We'll approve it shortly.");
      onSuccess(result.slug);
    } catch (err: any) {
      toast.error(err?.message ?? "Submission failed. Please try again.");
    }
  }

  return (
    <div className="fixed inset-0 z-40 bg-[#f5f0e8] overflow-y-auto">
      <div className="max-w-lg mx-auto px-5 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <button onClick={onCancel} className="p-2 rounded-xl bg-white border border-[#e8e0d4]">
            <ArrowLeft size={18} className="text-[#0d3320]" />
          </button>
          <div>
            <h1 className="font-serif text-2xl text-[#0d3320]">Post a Listing</h1>
            <p className="text-xs text-[#7a6a58]">All listings are reviewed before publishing</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Listing Type */}
          <div>
            <label className="block text-xs font-semibold text-[#0d3320] mb-2 uppercase tracking-wider">Listing Type</label>
            <div className="grid grid-cols-4 gap-2">
              {(["sell", "exchange", "giveaway", "wanted"] as const).map(type => {
                const info = LISTING_TYPE_LABELS[type];
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setForm(f => ({ ...f, listingType: type }))}
                    className={`py-2.5 px-2 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all ${
                      form.listingType === type
                        ? "bg-[#0d3320] text-white border-[#0d3320]"
                        : "bg-white text-[#7a6a58] border-[#e8e0d4]"
                    }`}
                  >
                    {info.icon}
                    {info.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Images */}
          <div>
            <label className="block text-xs font-semibold text-[#0d3320] mb-2 uppercase tracking-wider">Photos (up to 5)</label>
            <div className="flex gap-2 flex-wrap">
              {images.map((url, i) => (
                <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden border border-[#e8e0d4]">
                  <img src={url} alt="" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setImages(prev => prev.filter((_, j) => j !== i))}
                    className="absolute top-1 right-1 w-5 h-5 bg-black/60 rounded-full flex items-center justify-center"
                  >
                    <X size={10} className="text-white" />
                  </button>
                </div>
              ))}
              {images.length < 5 && (
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  disabled={uploading}
                  className="w-20 h-20 rounded-xl border-2 border-dashed border-[#d4c9b8] flex flex-col items-center justify-center gap-1 text-[#9a8a78] hover:border-[#0d3320] transition-colors"
                >
                  {uploading ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
                  <span className="text-xs">Add</span>
                </button>
              )}
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => { if (e.target.files?.[0]) uploadImage(e.target.files[0]); }} />
            </div>
          </div>

          {/* Perfume Details */}
          <div className="bg-white rounded-2xl p-4 space-y-3 border border-[#e8e0d4]">
            <h3 className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider">Perfume Details</h3>
            <div>
              <label className="block text-xs text-[#7a6a58] mb-1">Perfume Name *</label>
              <input value={form.perfumeName} onChange={e => setForm(f => ({ ...f, perfumeName: e.target.value }))}
                className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320]" placeholder="e.g. Bleu de Chanel" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#7a6a58] mb-1">Brand</label>
                <input value={form.brand} onChange={e => setForm(f => ({ ...f, brand: e.target.value }))}
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320]" placeholder="e.g. Chanel" />
              </div>
              <div>
                <label className="block text-xs text-[#7a6a58] mb-1">Size (ml)</label>
                <input value={form.size} onChange={e => setForm(f => ({ ...f, size: e.target.value }))}
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320]" placeholder="e.g. 100ml" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#7a6a58] mb-1">Concentration</label>
                <select value={form.concentration} onChange={e => setForm(f => ({ ...f, concentration: e.target.value as any }))}
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320] bg-white">
                  <option value="edp">Eau de Parfum</option>
                  <option value="edt">Eau de Toilette</option>
                  <option value="edc">Eau de Cologne</option>
                  <option value="parfum">Parfum / Extrait</option>
                  <option value="oil">Perfume Oil</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-[#7a6a58] mb-1">Fill Level (%)</label>
                <input type="number" min={0} max={100} value={form.remainingPercent}
                  onChange={e => setForm(f => ({ ...f, remainingPercent: e.target.value }))}
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320]" placeholder="e.g. 80" />
              </div>
            </div>
            <div>
              <label className="block text-xs text-[#7a6a58] mb-1">Condition</label>
              <div className="grid grid-cols-4 gap-1.5">
                {(["new", "like_new", "good", "fair"] as const).map(c => (
                  <button key={c} type="button" onClick={() => setForm(f => ({ ...f, condition: c }))}
                    className={`py-2 rounded-lg text-xs font-medium border transition-all ${
                      form.condition === c ? "bg-[#0d3320] text-white border-[#0d3320]" : "bg-white text-[#7a6a58] border-[#e8e0d4]"
                    }`}>
                    {CONDITION_LABELS[c]}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs text-[#7a6a58] mb-1">Fragrance Family</label>
              <input value={form.fragranceFamily} onChange={e => setForm(f => ({ ...f, fragranceFamily: e.target.value }))}
                className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320]" placeholder="e.g. Woody Aromatic" />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(["topNotes", "middleNotes", "baseNotes"] as const).map(field => (
                <div key={field}>
                  <label className="block text-xs text-[#7a6a58] mb-1">{field === "topNotes" ? "Top" : field === "middleNotes" ? "Middle" : "Base"} Notes</label>
                  <input value={form[field]} onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
                    className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:border-[#0d3320]" placeholder="e.g. Bergamot" />
                </div>
              ))}
            </div>
          </div>

          {/* Listing Details */}
          <div className="bg-white rounded-2xl p-4 space-y-3 border border-[#e8e0d4]">
            <h3 className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider">Listing Details</h3>
            {form.listingType === "sell" && (
              <div>
                <label className="block text-xs text-[#7a6a58] mb-1">Asking Price (SGD)</label>
                <input type="number" min={0} step={0.01} value={form.price}
                  onChange={e => setForm(f => ({ ...f, price: e.target.value }))}
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320]" placeholder="e.g. 85.00" />
              </div>
            )}
            <div>
              <label className="block text-xs text-[#7a6a58] mb-1">Description</label>
              <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                rows={4} className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320] resize-none"
                placeholder="Describe the perfume, its condition, any box/accessories included, reason for selling..." />
            </div>
            <div>
              <label className="block text-xs text-[#7a6a58] mb-1">Preferred Contact Method</label>
              <input value={form.contactMethod} onChange={e => setForm(f => ({ ...f, contactMethod: e.target.value }))}
                className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#0d3320]" placeholder="e.g. WhatsApp +65 9XXX XXXX or email@example.com" />
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={submitMutation.isPending}
            className="w-full py-4 rounded-2xl bg-[#0d3320] text-white font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {submitMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle size={16} />}
            Submit for Review
          </button>
          <p className="text-center text-xs text-[#9a8a78]">
            Your listing will be reviewed by the ZUBYR team before it goes live.
          </p>
        </form>
      </div>
    </div>
  );
}

// ── Main Community Page ───────────────────────────────────────────────────────

export default function Community() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [listingTypeFilter, setListingTypeFilter] = useState<"" | "sell" | "exchange" | "giveaway" | "wanted">("");
  const [showTerms, setShowTerms] = useState(false);
  const [showPostForm, setShowPostForm] = useState(false);
  const utils = trpc.useUtils();

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 400);
    return () => clearTimeout(t);
  }, [search]);

  const { data: termsAccepted } = trpc.community.checkTerms.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: listings = [], isLoading } = trpc.community.list.useQuery({
    status: "approved",
    search: debouncedSearch || undefined,
    listingType: listingTypeFilter || undefined,
  });

  // Get 3 ZUBYR products for recommendations
  const { data: products = [] } = trpc.products.list.useQuery({ activeOnly: true });
  const recommendations = products.slice(0, 3);

  function handlePostClick() {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }
    if (!termsAccepted) {
      setShowTerms(true);
    } else {
      setShowPostForm(true);
    }
  }

  function handleTermsAccepted() {
    setShowTerms(false);
    utils.community.checkTerms.invalidate();
    setShowPostForm(true);
  }

  if (showPostForm) {
    return (
      <PostListingForm
        onSuccess={(slug) => {
          setShowPostForm(false);
          utils.community.list.invalidate();
        }}
        onCancel={() => setShowPostForm(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f0e8]">
      {showTerms && (
        <TermsModal
          onAccept={handleTermsAccepted}
          onClose={() => setShowTerms(false)}
        />
      )}

      {/* Header */}
      <div className="bg-[#0d3320] px-5 pt-12 pb-8">
        <Link href="/">
          <button className="flex items-center gap-2 text-[#c9a84c] text-sm mb-5 opacity-80 hover:opacity-100 transition-opacity">
            <ArrowLeft size={16} /> Back
          </button>
        </Link>
        <h1 className="font-serif text-3xl text-white mb-1">Community Marketplace</h1>
        <p className="text-sm text-white/60">Buy, sell, exchange, and discover fragrances — peer to peer.</p>

        {/* Search */}
        <div className="mt-5 relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9a8a78]" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by name or brand..."
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-white text-sm text-[#1a1a1a] placeholder-[#9a8a78] focus:outline-none focus:ring-2 focus:ring-[#c9a84c]"
          />
        </div>
      </div>

      {/* Filter tabs */}
      <div className="px-5 py-3 flex gap-2 overflow-x-auto scrollbar-hide bg-white border-b border-[#e8e0d4]">
        {([["", "All"], ["sell", "For Sale"], ["exchange", "Exchange"], ["giveaway", "Giveaway"], ["wanted", "Wanted"]] as const).map(([val, label]) => (
          <button
            key={val}
            onClick={() => setListingTypeFilter(val as any)}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              listingTypeFilter === val
                ? "bg-[#0d3320] text-white"
                : "bg-[#f5f0e8] text-[#7a6a58] border border-[#e8e0d4]"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="px-5 py-5">
        {/* Stats bar */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-xs text-[#7a6a58]">
            {isLoading ? "Loading..." : `${listings.length} listing${listings.length !== 1 ? "s" : ""} found`}
          </p>
          <button
            onClick={handlePostClick}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0d3320] text-white text-xs font-semibold hover:bg-[#0a2818] transition-colors"
          >
            <Plus size={13} />
            Post a Listing
          </button>
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl overflow-hidden animate-pulse">
                <div className="aspect-square bg-[#e8e0d4]" />
                <div className="p-3 space-y-2">
                  <div className="h-3 bg-[#e8e0d4] rounded w-3/4" />
                  <div className="h-3 bg-[#e8e0d4] rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : listings.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mx-auto mb-4 shadow-sm">
              <span className="text-3xl">🌿</span>
            </div>
            <h3 className="font-serif text-xl text-[#0d3320] mb-2">No listings yet</h3>
            <p className="text-sm text-[#7a6a58] mb-6">Be the first to list a fragrance in the community.</p>
            <button
              onClick={handlePostClick}
              className="px-6 py-3 rounded-xl bg-[#0d3320] text-white text-sm font-semibold"
            >
              Post the First Listing
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {listings.map((listing: any) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        )}

        {/* ZUBYR Recommendations */}
        {recommendations.length > 0 && (
          <div className="mt-10">
            <div className="flex items-center gap-2 mb-4">
              <Star size={14} className="text-[#c9a84c]" fill="#c9a84c" />
              <h2 className="font-serif text-lg text-[#0d3320]">From ZUBYR's Collection</h2>
            </div>
            <div className="space-y-3">
              {recommendations.map((product: any) => (
                <div key={product.id} className="bg-white rounded-2xl p-4 flex items-center gap-4 border border-[#e8e0d4]">
                  <div className="w-14 h-14 rounded-xl bg-[#f5f0e8] flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-2xl">🌿</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-[#1a1a1a] truncate">{product.name}</p>
                    <p className="text-xs text-[#7a6a58] capitalize">{product.collection}</p>
                    {product.price && <p className="text-sm font-bold text-[#0d3320] mt-0.5">S${parseFloat(product.price).toFixed(2)}</p>}
                  </div>
                  <Link href="/shop">
                    <button className="px-3 py-1.5 rounded-lg bg-[#0d3320] text-white text-xs font-semibold flex-shrink-0">
                      Shop
                    </button>
                  </Link>
                </div>
              ))}
            </div>
            <div className="mt-3 text-center">
              <Link href="/shop">
                <button className="text-sm text-[#0d3320] font-semibold underline underline-offset-2 opacity-70 hover:opacity-100">
                  View all ZUBYR products →
                </button>
              </Link>
            </div>
          </div>
        )}

        {/* Disclaimer */}
        <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-2xl">
          <div className="flex gap-3">
            <AlertCircle size={16} className="text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 leading-relaxed">
              <strong>ZUBYR is a neutral platform.</strong> We do not verify listings or guarantee transactions. Always meet in safe public locations and use secure payment methods. Report suspicious listings to admin@zubyr.co.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
