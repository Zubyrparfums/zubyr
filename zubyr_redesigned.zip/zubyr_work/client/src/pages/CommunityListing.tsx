import { useState } from "react";
import { Link, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  ArrowLeft, Tag, Repeat2, Gift, ShoppingBag, Eye, Clock,
  ChevronLeft, ChevronRight, MessageCircle, Star, AlertCircle,
  Share2, Heart
} from "lucide-react";
import { toast } from "sonner";

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatPrice(price: string | null | undefined) {
  if (!price) return "Free / Make an Offer";
  const n = parseFloat(price);
  return isNaN(n) ? price : `S$${n.toFixed(2)}`;
}

function formatDate(d: Date | string) {
  return new Date(d).toLocaleDateString("en-SG", {
    day: "numeric", month: "long", year: "numeric",
  });
}

const LISTING_TYPE_LABELS: Record<string, { label: string; icon: React.ReactNode; color: string; bg: string }> = {
  sell:     { label: "For Sale",  icon: <Tag size={13} />,         color: "text-emerald-700", bg: "bg-emerald-100" },
  exchange: { label: "Exchange",  icon: <Repeat2 size={13} />,     color: "text-blue-700",    bg: "bg-blue-100" },
  giveaway: { label: "Giveaway",  icon: <Gift size={13} />,        color: "text-amber-700",   bg: "bg-amber-100" },
  wanted:   { label: "Wanted",    icon: <ShoppingBag size={13} />, color: "text-purple-700",  bg: "bg-purple-100" },
};

const CONDITION_LABELS: Record<string, string> = {
  new: "Brand New", like_new: "Like New", good: "Good Condition", fair: "Fair Condition",
};

const CONCENTRATION_LABELS: Record<string, string> = {
  edp: "Eau de Parfum", edt: "Eau de Toilette", edc: "Eau de Cologne",
  parfum: "Parfum / Extrait", oil: "Perfume Oil", other: "Other",
};

// ── Image Gallery ─────────────────────────────────────────────────────────────

function ImageGallery({ images }: { images: string[] }) {
  const [current, setCurrent] = useState(0);

  if (images.length === 0) {
    return (
      <div className="aspect-square bg-[#f5f0e8] flex flex-col items-center justify-center gap-3">
        <div className="w-16 h-16 rounded-full bg-[#e8e0d4] flex items-center justify-center">
          <span className="text-3xl">🌿</span>
        </div>
        <p className="text-sm text-[#9a8a78]">No photos provided</p>
      </div>
    );
  }

  return (
    <div className="relative aspect-square bg-[#f5f0e8] overflow-hidden">
      <img src={images[current]} alt="" className="w-full h-full object-cover" />
      {images.length > 1 && (
        <>
          <button
            onClick={() => setCurrent(i => Math.max(0, i - 1))}
            disabled={current === 0}
            className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 flex items-center justify-center disabled:opacity-30"
          >
            <ChevronLeft size={16} className="text-white" />
          </button>
          <button
            onClick={() => setCurrent(i => Math.min(images.length - 1, i + 1))}
            disabled={current === images.length - 1}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 flex items-center justify-center disabled:opacity-30"
          >
            <ChevronRight size={16} className="text-white" />
          </button>
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {images.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-1.5 h-1.5 rounded-full transition-all ${i === current ? "bg-white w-4" : "bg-white/50"}`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

export default function CommunityListing() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug ?? "";

  const { data: listing, isLoading } = trpc.community.bySlug.useQuery({ slug }, { enabled: !!slug });
  const { data: products = [] } = trpc.products.list.useQuery({ activeOnly: true });
  const recommendations = products.slice(0, 3);

  const images: string[] = (() => {
    try { return JSON.parse(listing?.imageUrls ?? "[]"); } catch { return []; }
  })();

  const typeInfo = LISTING_TYPE_LABELS[listing?.listingType ?? "sell"] ?? LISTING_TYPE_LABELS.sell;

  function handleShare() {
    if (navigator.share) {
      navigator.share({ title: listing?.perfumeName, url: window.location.href });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link copied to clipboard!");
    }
  }

  function handleContact() {
    if (listing?.contactMethod) {
      if (listing.contactMethod.includes("@")) {
        window.location.href = `mailto:${listing.contactMethod}`;
      } else if (listing.contactMethod.match(/\d{8,}/)) {
        window.open(`https://wa.me/${listing.contactMethod.replace(/\D/g, "")}`, "_blank");
      } else {
        toast.info(`Contact the seller at: ${listing.contactMethod}`);
      }
    } else {
      toast.info("Contact method not provided. Please reach out via the ZUBYR community.");
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#f5f0e8] flex items-center justify-center">
        <div className="text-center">
          <div className="w-10 h-10 border-2 border-[#0d3320] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#7a6a58]">Loading listing...</p>
        </div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-[#f5f0e8] flex items-center justify-center px-5">
        <div className="text-center">
          <span className="text-5xl mb-4 block">🌿</span>
          <h2 className="font-serif text-2xl text-[#0d3320] mb-2">Listing Not Found</h2>
          <p className="text-sm text-[#7a6a58] mb-6">This listing may have been removed or sold.</p>
          <Link href="/community">
            <button className="px-6 py-3 rounded-xl bg-[#0d3320] text-white text-sm font-semibold">
              Back to Marketplace
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f0e8]">
      {/* SEO meta via document title */}
      {typeof document !== "undefined" && (document.title = `${listing.perfumeName}${listing.brand ? ` by ${listing.brand}` : ""} — ZUBYR Community Marketplace`)}

      {/* Top nav */}
      <div className="sticky top-0 z-20 bg-white/90 backdrop-blur-md border-b border-[#e8e0d4] px-5 py-3 flex items-center justify-between">
        <Link href="/community">
          <button className="flex items-center gap-2 text-[#0d3320] text-sm font-medium">
            <ArrowLeft size={16} /> Marketplace
          </button>
        </Link>
        <div className="flex items-center gap-2">
          <button onClick={handleShare} className="p-2 rounded-xl bg-[#f5f0e8] text-[#7a6a58] hover:bg-[#e8e0d4] transition-colors">
            <Share2 size={16} />
          </button>
        </div>
      </div>

      {/* Image Gallery */}
      <ImageGallery images={images} />

      {/* Content */}
      <div className="px-5 py-5 space-y-5">
        {/* Title & Price */}
        <div>
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${typeInfo.bg} ${typeInfo.color} mb-2`}>
                {typeInfo.icon}
                {typeInfo.label}
              </div>
              <h1 className="font-serif text-2xl text-[#0d3320] leading-tight">{listing.perfumeName}</h1>
              {listing.brand && <p className="text-base text-[#7a6a58] mt-0.5">{listing.brand}</p>}
            </div>
            <div className="text-right flex-shrink-0">
              <p className="text-2xl font-bold text-[#0d3320]">{formatPrice(listing.price)}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 mt-3 text-xs text-[#9a8a78]">
            <span className="flex items-center gap-1"><Eye size={11} /> {listing.viewCount ?? 0} views</span>
            <span>·</span>
            <span className="flex items-center gap-1"><Clock size={11} /> {formatDate(listing.createdAt)}</span>
            {listing.submitterName && <><span>·</span><span>by {listing.submitterName}</span></>}
          </div>
        </div>

        {/* Perfume Details */}
        <div className="bg-white rounded-2xl p-4 border border-[#e8e0d4]">
          <h2 className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider mb-3">Perfume Details</h2>
          <div className="grid grid-cols-2 gap-y-3 gap-x-4 text-sm">
            {listing.size && (
              <div>
                <p className="text-xs text-[#9a8a78]">Size</p>
                <p className="font-medium text-[#1a1a1a]">{listing.size}</p>
              </div>
            )}
            {listing.concentration && (
              <div>
                <p className="text-xs text-[#9a8a78]">Concentration</p>
                <p className="font-medium text-[#1a1a1a]">{CONCENTRATION_LABELS[listing.concentration] ?? listing.concentration}</p>
              </div>
            )}
            {listing.remainingPercent != null && (
              <div>
                <p className="text-xs text-[#9a8a78]">Fill Level</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <div className="flex-1 h-1.5 bg-[#e8e0d4] rounded-full overflow-hidden">
                    <div className="h-full bg-[#0d3320] rounded-full" style={{ width: `${listing.remainingPercent}%` }} />
                  </div>
                  <span className="font-medium text-[#1a1a1a] text-xs">{listing.remainingPercent}%</span>
                </div>
              </div>
            )}
            {listing.condition && (
              <div>
                <p className="text-xs text-[#9a8a78]">Condition</p>
                <p className="font-medium text-[#1a1a1a]">{CONDITION_LABELS[listing.condition] ?? listing.condition}</p>
              </div>
            )}
            {listing.fragranceFamily && (
              <div className="col-span-2">
                <p className="text-xs text-[#9a8a78]">Fragrance Family</p>
                <p className="font-medium text-[#1a1a1a]">{listing.fragranceFamily}</p>
              </div>
            )}
          </div>

          {/* Notes */}
          {(listing.topNotes || listing.middleNotes || listing.baseNotes) && (
            <div className="mt-4 pt-4 border-t border-[#e8e0d4]">
              <p className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider mb-3">Fragrance Notes</p>
              <div className="grid grid-cols-3 gap-3">
                {listing.topNotes && (
                  <div className="bg-[#f5f0e8] rounded-xl p-3 text-center">
                    <p className="text-xs text-[#9a8a78] mb-1">Top</p>
                    <p className="text-xs font-medium text-[#1a1a1a]">{listing.topNotes}</p>
                  </div>
                )}
                {listing.middleNotes && (
                  <div className="bg-[#f5f0e8] rounded-xl p-3 text-center">
                    <p className="text-xs text-[#9a8a78] mb-1">Middle</p>
                    <p className="text-xs font-medium text-[#1a1a1a]">{listing.middleNotes}</p>
                  </div>
                )}
                {listing.baseNotes && (
                  <div className="bg-[#f5f0e8] rounded-xl p-3 text-center">
                    <p className="text-xs text-[#9a8a78] mb-1">Base</p>
                    <p className="text-xs font-medium text-[#1a1a1a]">{listing.baseNotes}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Description */}
        {listing.description && (
          <div className="bg-white rounded-2xl p-4 border border-[#e8e0d4]">
            <h2 className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider mb-3">Description</h2>
            <p className="text-sm text-[#3a2e22] leading-relaxed whitespace-pre-wrap">{listing.description}</p>
          </div>
        )}

        {/* Contact CTA */}
        <button
          onClick={handleContact}
          className="w-full py-4 rounded-2xl bg-[#0d3320] text-white font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#0a2818] transition-colors active:scale-[0.98]"
        >
          <MessageCircle size={16} />
          Contact Seller
        </button>

        {/* Disclaimer */}
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl">
          <div className="flex gap-3">
            <AlertCircle size={15} className="text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 leading-relaxed">
              <strong>ZUBYR is a neutral platform.</strong> We do not verify listings or guarantee authenticity. Always inspect items before purchase and use secure payment methods. Report suspicious listings to admin@zubyr.co.
            </p>
          </div>
        </div>

        {/* ZUBYR Recommendations */}
        {recommendations.length > 0 && (
          <div className="mt-2">
            <div className="flex items-center gap-2 mb-4">
              <Star size={14} className="text-[#c9a84c]" fill="#c9a84c" />
              <h2 className="font-serif text-lg text-[#0d3320]">You Might Also Like</h2>
            </div>
            <p className="text-xs text-[#7a6a58] mb-3">Authentic fragrances from ZUBYR's own collection</p>
            <div className="space-y-3">
              {recommendations.map((product: any) => (
                <div key={product.id} className="bg-white rounded-2xl p-4 flex items-center gap-4 border border-[#e8e0d4]">
                  <div className="w-14 h-14 rounded-xl bg-[#f5f0e8] flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-2xl">🌿</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-[#1a1a1a] truncate">{product.name}</p>
                    <p className="text-xs text-[#7a6a58] capitalize">{product.collection}</p>
                    {product.price && (
                      <p className="text-sm font-bold text-[#0d3320] mt-0.5">
                        S${parseFloat(product.price).toFixed(2)}
                      </p>
                    )}
                  </div>
                  <Link href="/shop">
                    <button className="px-3 py-1.5 rounded-lg bg-[#0d3320] text-white text-xs font-semibold flex-shrink-0">
                      Shop
                    </button>
                  </Link>
                </div>
              ))}
            </div>
            <div className="mt-3 text-center">
              <Link href="/shop">
                <button className="text-sm text-[#0d3320] font-semibold underline underline-offset-2 opacity-70 hover:opacity-100">
                  View all ZUBYR products →
                </button>
              </Link>
            </div>
          </div>
        )}

        {/* More listings */}
        <div className="mt-4 text-center pb-8">
          <Link href="/community">
            <button className="px-6 py-3 rounded-xl border border-[#0d3320] text-[#0d3320] text-sm font-semibold hover:bg-[#0d3320] hover:text-white transition-colors">
              Browse More Listings
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
