import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Lightbulb, Send, CheckCircle } from "lucide-react";

const FOREST="#1a3028",SPICE="#8B3A1A",AMBER="#C8912E",CREAM="#F2EDE4",STONE="#9A8A78",PINE="#2d4a3e";

export default function GiveUsIdeas(){
  const [form,setForm]=useState({name:"",email:"",idea:""});
  const [done,setDone]=useState(false);
  const mut=trpc.ideas.submit.useMutation({onSuccess:()=>setDone(true),onError:()=>toast.error("Something went wrong.")});
  const go=(e:React.FormEvent)=>{
    e.preventDefault();
    if(!form.idea.trim()||form.idea.trim().length<10)return toast.error("Please share your idea (min 10 characters).");
    mut.mutate({name:form.name||undefined,email:form.email||undefined,idea:form.idea});
  };

  return(
    <div className="min-h-screen font-serif" style={{background:CREAM}}>
      <header className="sticky top-0 z-40 px-5 py-4 flex items-center gap-3" style={{background:FOREST}}>
        <a href="/" style={{color:"rgba(255,255,255,0.50)"}}><ArrowLeft className="w-5 h-5"/></a>
        <div>
          <p className="font-bold tracking-widest uppercase text-xs text-white">Give Us Ideas</p>
          <p className="font-sans text-[10px] tracking-widest uppercase" style={{color:"rgba(255,255,255,0.35)"}}>Shape the future of ZUBYR</p>
        </div>
      </header>

      <div className="max-w-md mx-auto px-5 py-8">
        {done?(
          <div className="flex flex-col items-center justify-center py-20 text-center gap-5">
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{background:`rgba(45,74,62,0.10)`}}>
              <CheckCircle className="w-8 h-8" style={{color:PINE}}/>
            </div>
            <div>
              <h2 className="text-2xl font-bold" style={{color:FOREST}}>Thank You!</h2>
              <p className="font-sans text-sm mt-2 leading-relaxed" style={{color:STONE}}>Your idea has been received. We genuinely read every submission — you might just see it come to life.</p>
            </div>
            <a href="/" className="px-6 py-3 rounded-xl font-sans font-bold text-sm" style={{background:PINE,color:"#fff"}}>Back to Home</a>
          </div>
        ):(
          <>
            {/* Brand story card */}
            <div className="rounded-2xl overflow-hidden mb-7" style={{background:FOREST}}>
              <div className="px-5 pt-6 pb-5">
                <div className="flex items-center gap-2 mb-3">
                  <Lightbulb className="w-4 h-4" style={{color:AMBER}}/>
                  <span className="font-sans font-bold text-xs uppercase tracking-widest" style={{color:AMBER}}>About ZUBYR</span>
                </div>
                <p className="text-lg leading-snug text-white mb-3">
                  We're building Singapore's fragrance ecosystem — and we want your voice in it.
                </p>
                <p className="font-sans text-xs leading-relaxed" style={{color:"rgba(255,255,255,0.45)"}}>
                  ZUBYR was born from a belief that fragrance is more than a product — it's a language, a memory, an identity. We're creating a space where people can discover, learn, create, and trade scent in ways that have never existed in Singapore before.
                </p>
              </div>
              <div className="px-5 py-3 flex flex-wrap gap-3" style={{borderTop:`1px solid rgba(255,255,255,0.08)`}}>
                {["New fragrance workshops","Ingredient sourcing guides","Community events","Mobile app features","Collaboration ideas"].map(t=>(
                  <span key={t} className="font-sans text-xs px-2.5 py-1 rounded-full" style={{background:"rgba(200,145,46,0.15)",color:AMBER,border:`1px solid rgba(200,145,46,0.25)`}}>{t}</span>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <p className="font-sans font-bold text-xs tracking-[0.22em] uppercase mb-3" style={{color:SPICE}}>Your Ideas</p>
              <h1 className="text-3xl leading-tight mb-2" style={{color:FOREST}}>What should<br/>ZUBYR build next?</h1>
              <p className="font-sans text-sm leading-relaxed" style={{color:STONE}}>Every idea is read personally by our team. The best ones get built.</p>
            </div>

            <form onSubmit={go} className="flex flex-col gap-4">
              <div>
                <label className="block font-sans font-semibold text-xs uppercase tracking-wider mb-1.5" style={{color:"rgba(26,48,40,0.48)"}}>Your Name</label>
                <input type="text" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="Optional"
                  className="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none"
                  style={{background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST}}/>
              </div>
              <div>
                <label className="block font-sans font-semibold text-xs uppercase tracking-wider mb-1.5" style={{color:"rgba(26,48,40,0.48)"}}>Email</label>
                <input type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} placeholder="Optional — if you'd like a response"
                  className="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none"
                  style={{background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST}}/>
              </div>
              <div>
                <label className="block font-sans font-semibold text-xs uppercase tracking-wider mb-1.5" style={{color:"rgba(26,48,40,0.48)"}}>Your Idea <span style={{color:SPICE}}>*</span></label>
                <textarea rows={6} value={form.idea} onChange={e=>setForm(f=>({...f,idea:e.target.value}))}
                  placeholder="Tell us your idea in as much detail as you like. What would you want ZUBYR to create, build, or improve?"
                  className="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none resize-none"
                  style={{background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST}}/>
                <p className="font-sans text-xs mt-1.5" style={{color:STONE}}>{form.idea.length} characters</p>
              </div>
              <button type="submit" disabled={mut.isPending||form.idea.length<10}
                className="w-full flex items-center justify-center gap-2 py-4 rounded-xl font-sans font-bold text-sm active:scale-[0.98] disabled:opacity-50"
                style={{background:SPICE,color:"#fff"}}>
                <Send className="w-4 h-4"/>{mut.isPending?"Sending…":"Submit Idea"}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
