import { Link, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Clock, Tag, Share2, BookOpen } from "lucide-react";
import { toast } from "sonner";

const CATEGORIES: Record<string, string> = {
  ingredient_academy: "Ingredient Academy", perfume_science: "Perfume Science",
  perfumery_school: "Perfumery School", formula_breakdowns: "Formula Breakdowns",
  perfumer_stories: "Perfumer Stories", singapore_fragrance_reports: "Singapore Fragrance Reports",
  scentmate_insights: "ScentMate Insights", workshop_journal: "Workshop Journal",
  community_spotlight: "Community Spotlight", fragrance_encyclopedia: "Fragrance Encyclopedia",
};

const CATEGORY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  ingredient_academy:          { bg: "rgba(5,90,50,0.12)",   text: "#055a32",  border: "rgba(5,90,50,0.25)"   },
  perfume_science:             { bg: "rgba(20,60,120,0.12)", text: "#143c78",  border: "rgba(20,60,120,0.25)" },
  perfumery_school:            { bg: "rgba(80,20,100,0.12)", text: "#501464",  border: "rgba(80,20,100,0.25)" },
  formula_breakdowns:          { bg: "rgba(140,80,0,0.12)",  text: "#8c5000",  border: "rgba(140,80,0,0.25)"  },
  perfumer_stories:            { bg: "rgba(140,20,40,0.12)", text: "#8c1428",  border: "rgba(140,20,40,0.25)" },
  singapore_fragrance_reports: { bg: "rgba(180,50,0,0.12)",  text: "#b43200",  border: "rgba(180,50,0,0.25)"  },
  scentmate_insights:          { bg: "rgba(0,100,120,0.12)", text: "#006478",  border: "rgba(0,100,120,0.25)" },
  workshop_journal:            { bg: "rgba(140,60,0,0.12)",  text: "#8c3c00",  border: "rgba(140,60,0,0.25)"  },
  community_spotlight:         { bg: "rgba(0,90,80,0.12)",   text: "#005a50",  border: "rgba(0,90,80,0.25)"   },
  fragrance_encyclopedia:      { bg: "rgba(40,40,120,0.12)", text: "#282878",  border: "rgba(40,40,120,0.25)" },
};

function renderMarkdown(md: string): string {
  return md
    .replace(/^## (.+)$/gm, '<h2 style="font-size:1.4rem;font-weight:700;color:#0d1f14;margin:2.5rem 0 1rem;line-height:1.3">$1</h2>')
    .replace(/^### (.+)$/gm, '<h3 style="font-size:1.15rem;font-weight:600;color:#0d1f14;margin:2rem 0 0.75rem">$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong style="font-weight:700;color:#0d1f14">$1</strong>')
    .replace(/\*(.+?)\*/g, '<em style="font-style:italic;color:rgba(13,31,20,0.75)">$1</em>')
    .replace(/^- (.+)$/gm, '<li style="margin-left:1.25rem;margin-bottom:0.4rem;list-style-type:disc;color:rgba(13,31,20,0.70);line-height:1.65">$1</li>')
    .replace(/^\d+\. (.+)$/gm, '<li style="margin-left:1.25rem;margin-bottom:0.4rem;list-style-type:decimal;color:rgba(13,31,20,0.70);line-height:1.65">$1</li>')
    .replace(/^---$/gm, '<hr style="border:none;border-top:1px solid rgba(13,31,20,0.10);margin:2.5rem 0" />')
    .split('\n\n')
    .map(block => {
      const t = block.trim();
      if (!t) return '';
      if (t.startsWith('<h') || t.startsWith('<hr')) return t;
      if (t.includes('<li')) return `<ul style="margin:1rem 0">${t}</ul>`;
      return `<p style="color:rgba(13,31,20,0.68);line-height:1.80;margin:1.2rem 0;font-size:1rem">${t}</p>`;
    })
    .join('\n');
}

export default function BlogArticle() {
  const params = useParams<{ slug: string }>();
  const { data: post, isLoading } = trpc.blog.bySlug.useQuery({ slug: params.slug ?? "" }, { enabled: !!params.slug });
  const { data: related = [] } = trpc.blog.list.useQuery({ category: post?.category ?? undefined, publishedOnly: true }, { enabled: !!post?.category });
  const relatedPosts = related.filter(p => p.id !== post?.id).slice(0, 3);

  function handleShare() {
    if (navigator.share) {
      navigator.share({ title: post?.title ?? "ZUBYR Article", url: window.location.href });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link copied!");
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen" style={{ background: "#f5f0e8" }}>
        <div className="max-w-2xl mx-auto px-5 py-16 space-y-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-4 rounded animate-pulse" style={{ background: "rgba(13,31,20,0.10)", width: `${70 + Math.random() * 30}%` }} />
          ))}
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: "#f5f0e8" }}>
        <div className="text-center px-5">
          <BookOpen className="w-14 h-14 mx-auto mb-4 opacity-20" style={{ color: "#0d1f14" }} />
          <h1 className="text-2xl mb-4" style={{ color: "#0d1f14" }}>Article not found</h1>
          <Link href="/blog"><button className="font-sans text-sm flex items-center gap-2 mx-auto" style={{ color: "rgba(13,31,20,0.55)" }}><ArrowLeft className="w-4 h-4" /> Back to Blog</button></Link>
        </div>
      </div>
    );
  }

  const tags: string[] = (() => { try { return JSON.parse(post.tags ?? "[]"); } catch { return []; } })();
  const col = post.category ? (CATEGORY_COLORS[post.category] ?? null) : null;
  const catLabel = post.category ? (CATEGORIES[post.category] ?? post.category) : "";

  return (
    <div className="min-h-screen" style={{ background: "#f5f0e8" }}>
      {/* Hero */}
      <div className="relative overflow-hidden" style={{ background: "#0d1f14" }}>
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "url('/manus-storage/darkgreen_79cedb4e.jpg')", backgroundSize: "cover" }} />
        <div className="absolute inset-0" style={{ background: "rgba(13,31,20,0.82)" }} />
        <div className="relative z-10 max-w-2xl mx-auto px-5 pt-12 pb-10">
          <Link href="/blog">
            <button className="flex items-center gap-2 text-sm mb-6 transition-opacity opacity-70 hover:opacity-100" style={{ color: "#d4af37" }}>
              <ArrowLeft className="w-4 h-4" /> Blog & Academy
            </button>
          </Link>
          {col && (
            <span className="inline-block px-3 py-1 rounded-full text-xs font-sans font-semibold mb-4" style={{ background: "rgba(212,175,55,0.15)", color: "#d4af37", border: "1px solid rgba(212,175,55,0.25)" }}>
              {catLabel}
            </span>
          )}
          <h1 className="text-3xl leading-tight mb-3" style={{ color: "#fff" }}>{post.title}</h1>
          {post.excerpt && <p className="font-sans text-sm leading-relaxed mb-5" style={{ color: "rgba(255,255,255,0.52)" }}>{post.excerpt}</p>}
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-4 font-sans text-xs" style={{ color: "rgba(255,255,255,0.38)" }}>
              <span>{post.authorName ?? "ZUBYR Editorial"}</span>
              <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{post.readTime ?? 5} min</span>
              <span>{new Date(post.createdAt).toLocaleDateString("en-SG", { day: "numeric", month: "long", year: "numeric" })}</span>
            </div>
            <button onClick={handleShare} className="flex items-center gap-1.5 font-sans text-xs transition-opacity hover:opacity-80" style={{ color: "rgba(212,175,55,0.80)" }}>
              <Share2 className="w-3.5 h-3.5" /> Share
            </button>
          </div>
        </div>
      </div>

      {/* Article */}
      <div className="max-w-2xl mx-auto px-5 py-10">
        {post.content ? (
          <div
            className="font-serif"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(post.content) }}
          />
        ) : (
          <p className="font-sans text-sm" style={{ color: "rgba(13,31,20,0.45)" }}>No content available.</p>
        )}

        {/* Tags */}
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-10 pt-6" style={{ borderTop: "1px solid rgba(13,31,20,0.09)" }}>
            <Tag className="w-4 h-4 mt-0.5" style={{ color: "rgba(13,31,20,0.30)" }} />
            {tags.map(tag => (
              <span key={tag} className="px-3 py-1 rounded-full font-sans text-xs" style={{ background: "rgba(13,31,20,0.06)", color: "rgba(13,31,20,0.50)", border: "1px solid rgba(13,31,20,0.10)" }}>
                {tag}
              </span>
            ))}
          </div>
        )}

        {/* Related */}
        {relatedPosts.length > 0 && (
          <div className="mt-12">
            <h2 className="text-xl mb-5" style={{ color: "#0d1f14" }}>More from {catLabel}</h2>
            <div className="space-y-3">
              {relatedPosts.map(rp => {
                const rc = rp.category ? CATEGORY_COLORS[rp.category] : null;
                return (
                  <Link key={rp.id} href={`/blog/${rp.slug}`}>
                    <div className="group flex items-start gap-4 rounded-2xl p-4 transition-all active:scale-[0.98] hover:shadow-md" style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.08)" }}>
                      <div className="flex-1 min-w-0">
                        {rp.category && rc && (
                          <span className="inline-block px-2 py-0.5 rounded-full font-sans text-xs font-semibold mb-2" style={{ background: rc.bg, color: rc.text, border: `1px solid ${rc.border}` }}>
                            {CATEGORIES[rp.category] ?? rp.category}
                          </span>
                        )}
                        <h3 className="font-semibold text-sm leading-snug group-hover:opacity-70 transition-opacity line-clamp-2" style={{ color: "#0d1f14" }}>{rp.title}</h3>
                        <div className="flex items-center gap-1 mt-2 font-sans text-xs" style={{ color: "rgba(13,31,20,0.35)" }}>
                          <Clock className="w-3 h-3" />{rp.readTime} min
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        )}

        {/* Back */}
        <div className="mt-12 pt-6" style={{ borderTop: "1px solid rgba(13,31,20,0.09)" }}>
          <Link href="/blog">
            <button className="flex items-center gap-2 font-sans text-sm transition-opacity hover:opacity-70" style={{ color: "rgba(13,31,20,0.55)" }}>
              <ArrowLeft className="w-4 h-4" /> Back to Blog & Academy
            </button>
          </Link>
        </div>
      </div>

      <div className="py-8 text-center font-sans text-xs" style={{ color: "rgba(13,31,20,0.22)" }}>
        © {new Date().getFullYear()} ZUBYR — Singapore's Fragrance Ecosystem
      </div>
    </div>
  );
}
