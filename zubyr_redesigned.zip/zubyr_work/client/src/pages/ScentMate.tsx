import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Sparkles, ChevronRight, ChevronLeft, RotateCcw, Loader2 } from "lucide-react";

const QUESTIONS = [
  {
    id: "mood",
    question: "When do you reach for a fragrance most?",
    options: [
      { value: "daily",    label: "Every morning ritual",   emoji: "🌅" },
      { value: "evening",  label: "Evening or going out",   emoji: "🌙" },
      { value: "work",     label: "Professional settings",  emoji: "💼" },
      { value: "special",  label: "Special occasions only", emoji: "✨" },
    ],
  },
  {
    id: "vibe",
    question: "Which word best describes the impression you want to leave?",
    options: [
      { value: "powerful",  label: "Powerful & commanding", emoji: "👑" },
      { value: "sensual",   label: "Warm & sensual",        emoji: "🔥" },
      { value: "fresh",     label: "Clean & fresh",         emoji: "🌊" },
      { value: "mysterious",label: "Mysterious & complex",  emoji: "🌑" },
    ],
  },
  {
    id: "nature",
    question: "Which environment resonates with you most?",
    options: [
      { value: "forest",   label: "Deep forest at dusk",  emoji: "🌲" },
      { value: "desert",   label: "Arabian desert night", emoji: "🏜️" },
      { value: "garden",   label: "Mediterranean garden", emoji: "🌹" },
      { value: "ocean",    label: "Open ocean breeze",    emoji: "🌊" },
    ],
  },
  {
    id: "intensity",
    question: "How close does someone need to be to smell your fragrance?",
    options: [
      { value: "whisper",   label: "Whisper close — intimate", emoji: "🤫" },
      { value: "personal",  label: "Personal space — noticeable", emoji: "👤" },
      { value: "trail",     label: "I leave a trail when I walk", emoji: "💨" },
      { value: "statement", label: "It enters the room before I do", emoji: "🚪" },
    ],
  },
  {
    id: "ingredient",
    question: "Which ingredient family speaks to you?",
    options: [
      { value: "oud",      label: "Oud & Resins",         emoji: "🪵" },
      { value: "floral",   label: "Rose & White Florals", emoji: "🌸" },
      { value: "citrus",   label: "Bergamot & Citrus",    emoji: "🍋" },
      { value: "woody",    label: "Vetiver & Sandalwood", emoji: "🌿" },
    ],
  },
  {
    id: "season",
    question: "Singapore's heat aside — what's your preferred climate for fragrance?",
    options: [
      { value: "warm",   label: "Hot days, bold choices",   emoji: "☀️" },
      { value: "cool",   label: "Cool air, lighter touch",  emoji: "❄️" },
      { value: "rain",   label: "Rainy, earthy freshness",  emoji: "🌧️" },
      { value: "night",  label: "Night-time, all year",     emoji: "🌃" },
    ],
  },
  {
    id: "budget",
    question: "What's your investment level for the right fragrance?",
    options: [
      { value: "everyday",  label: "S$50–150 — everyday luxury",  emoji: "💚" },
      { value: "premium",   label: "S$150–350 — premium choice",  emoji: "💛" },
      { value: "niche",     label: "S$350–700 — niche territory", emoji: "🧡" },
      { value: "bespoke",   label: "Bespoke — no ceiling",        emoji: "💎" },
    ],
  },
];

type Answers = Record<string, string>;

function QuizQuestion({
  question,
  questionNum,
  total,
  selectedValue,
  onSelect,
}: {
  question: typeof QUESTIONS[0];
  questionNum: number;
  total: number;
  selectedValue: string | undefined;
  onSelect: (value: string) => void;
}) {
  return (
    <div className="w-full">
      {/* Progress */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-sans font-semibold tracking-wider uppercase" style={{ color: "#d4af37" }}>
            Question {questionNum} of {total}
          </span>
          <span className="text-xs font-sans" style={{ color: "rgba(255,255,255,0.35)" }}>
            {Math.round((questionNum / total) * 100)}% complete
          </span>
        </div>
        <div className="h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.12)" }}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${(questionNum / total) * 100}%`, background: "linear-gradient(90deg, #d4af37, #c9a84c)" }}
          />
        </div>
      </div>

      <h2 className="text-2xl leading-snug mb-6" style={{ color: "#fff" }}>{question.question}</h2>

      <div className="space-y-3">
        {question.options.map(opt => (
          <button
            key={opt.value}
            onClick={() => onSelect(opt.value)}
            className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-left transition-all duration-200 active:scale-[0.97]"
            style={
              selectedValue === opt.value
                ? { background: "rgba(212,175,55,0.20)", border: "2px solid rgba(212,175,55,0.70)", color: "#fff" }
                : { background: "rgba(255,255,255,0.06)", border: "2px solid rgba(255,255,255,0.10)", color: "rgba(255,255,255,0.80)" }
            }
          >
            <span className="text-2xl flex-shrink-0">{opt.emoji}</span>
            <span className="font-sans text-sm font-medium">{opt.label}</span>
            {selectedValue === opt.value && (
              <div className="ml-auto w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "#d4af37" }}>
                <svg className="w-3 h-3" fill="none" stroke="#0d1f14" strokeWidth="2.5" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

function Result({ answers, onReset }: { answers: Answers; onReset: () => void }) {
  const recommend = trpc.scentmate.recommend.useMutation();
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState(false);
  const hasRun = useState(() => ({ done: false }))[0];

  if (!hasRun.done) {
    hasRun.done = true;
    recommend.mutate(answers as any, {
      onSuccess: (data) => setResult(data.text),
      onError: () => setError(true),
    });
  }

  const loading = recommend.isPending;

  return (
    <div className="w-full">
      <div className="text-center mb-8">
        <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ background: "rgba(212,175,55,0.18)", border: "1px solid rgba(212,175,55,0.35)" }}>
          <Sparkles className="w-8 h-8" style={{ color: "#d4af37" }} />
        </div>
        <p className="text-xs font-sans font-bold tracking-[0.22em] uppercase mb-2" style={{ color: "#d4af37" }}>Your ScentMate Reading</p>
        <h2 className="text-3xl" style={{ color: "#fff" }}>Your signature<br />scent awaits.</h2>
      </div>

      <div className="rounded-2xl p-6 mb-6" style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.10)" }}>
        {loading ? (
          <div className="flex flex-col items-center gap-4 py-8">
            <Loader2 className="w-8 h-8 animate-spin" style={{ color: "#d4af37" }} />
            <p className="font-sans text-sm" style={{ color: "rgba(255,255,255,0.50)" }}>Our master perfumer AI is reading your answers…</p>
          </div>
        ) : error ? (
          <div className="text-center py-6">
            <p className="font-sans text-sm mb-4" style={{ color: "rgba(255,255,255,0.50)" }}>Couldn't generate your reading right now.</p>
            <a href="https://wa.me/6581877202?text=Hi%20ZUBYR%2C%20I%27d%20love%20a%20fragrance%20recommendation." target="_blank" rel="noopener noreferrer" className="text-sm font-sans font-bold" style={{ color: "#d4af37" }}>
              Contact us directly →
            </a>
          </div>
        ) : (
          <div className="font-sans text-sm leading-relaxed whitespace-pre-wrap" style={{ color: "rgba(255,255,255,0.80)" }}>
            {result}
          </div>
        )}
      </div>

      <div className="space-y-3">
        <a
          href="https://wa.me/6581877202?text=Hi%20ZUBYR%2C%20I%20just%20completed%20the%20ScentMate%20quiz%20and%20I%27d%20love%20to%20discuss%20a%20bespoke%20fragrance."
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 w-full py-4 rounded-2xl font-sans font-bold text-sm transition-all hover:opacity-90"
          style={{ background: "#d4af37", color: "#0d1f14" }}
        >
          Create My Bespoke Fragrance <ChevronRight className="w-4 h-4" />
        </a>
        <Link href="/shop">
          <button className="w-full py-4 rounded-2xl font-sans font-semibold text-sm transition-all" style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.80)" }}>
            Browse the Shop
          </button>
        </Link>
        <button onClick={onReset} className="w-full flex items-center justify-center gap-2 py-3 font-sans text-sm" style={{ color: "rgba(255,255,255,0.35)" }}>
          <RotateCcw className="w-4 h-4" /> Retake Quiz
        </button>
      </div>
    </div>
  );
}

export default function ScentMate() {
  const [step, setStep] = useState(0); // 0 = intro, 1–N = questions, N+1 = result
  const [answers, setAnswers] = useState<Answers>({});
  const [currentAnswer, setCurrentAnswer] = useState<string | undefined>(undefined);

  const isIntro = step === 0;
  const isResult = step > QUESTIONS.length;
  const questionIndex = step - 1;
  const currentQuestion = QUESTIONS[questionIndex];

  function handleStart() {
    setStep(1);
    setCurrentAnswer(answers[QUESTIONS[0].id]);
  }

  function handleNext() {
    if (!currentAnswer) return;
    const newAnswers = { ...answers, [currentQuestion.id]: currentAnswer };
    setAnswers(newAnswers);
    if (step >= QUESTIONS.length) {
      setStep(QUESTIONS.length + 1);
    } else {
      setStep(s => s + 1);
      setCurrentAnswer(answers[QUESTIONS[step].id]);
    }
  }

  function handleBack() {
    if (step === 1) { setStep(0); return; }
    setStep(s => s - 1);
    setCurrentAnswer(answers[QUESTIONS[step - 2].id]);
  }

  function handleReset() {
    setStep(0);
    setAnswers({});
    setCurrentAnswer(undefined);
  }

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(160deg, #080f0a 0%, #0d1f14 40%, #1a1208 100%)" }}>
      {/* Top bar */}
      <div className="px-5 pt-10 pb-4 flex items-center gap-3">
        {!isResult && (
          <button onClick={step > 0 ? handleBack : undefined} className="transition-colors" style={{ color: "rgba(212,175,55,0.65)" }}>
            {step > 0 ? <ChevronLeft className="w-5 h-5" /> : null}
          </button>
        )}
        <Link href="/">
          <button className="flex items-center gap-2 text-sm" style={{ color: "rgba(212,175,55,0.65)" }}>
            <ArrowLeft className="w-4 h-4" /> ZUBYR
          </button>
        </Link>
      </div>

      <div className="px-5 pb-16 max-w-md mx-auto">
        {isIntro && (
          <div className="pt-6 text-center">
            <div className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center" style={{ background: "rgba(212,175,55,0.12)", border: "1px solid rgba(212,175,55,0.25)" }}>
              <Sparkles className="w-10 h-10" style={{ color: "#d4af37" }} />
            </div>
            <p className="text-xs font-sans font-bold tracking-[0.25em] uppercase mb-3" style={{ color: "#d4af37" }}>ScentMate AI™</p>
            <h1 className="text-4xl leading-tight mb-4" style={{ color: "#fff" }}>Find your<br />signature scent.</h1>
            <p className="font-sans text-sm leading-relaxed mb-8 max-w-xs mx-auto" style={{ color: "rgba(255,255,255,0.50)" }}>
              Answer 7 questions. Our master perfumer AI — trained on ZUBYR's 4th generation knowledge — will craft a fragrance recommendation uniquely for you.
            </p>
            <div className="flex justify-center gap-6 mb-10">
              {["7 Questions", "~2 Minutes", "AI-Powered"].map(f => (
                <div key={f} className="text-center">
                  <p className="font-sans text-xs font-bold" style={{ color: "#d4af37" }}>{f.split(" ")[0]}</p>
                  <p className="font-sans text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>{f.split(" ").slice(1).join(" ")}</p>
                </div>
              ))}
            </div>
            <button
              onClick={handleStart}
              className="w-full py-4 rounded-2xl font-sans font-bold text-base transition-all hover:opacity-90 active:scale-[0.97]"
              style={{ background: "linear-gradient(135deg, #d4af37, #c09a2a)", color: "#0d1f14", boxShadow: "0 4px 20px rgba(212,175,55,0.35)" }}
            >
              Begin My Scent Reading ✦
            </button>
          </div>
        )}

        {!isIntro && !isResult && currentQuestion && (
          <div className="pt-4">
            <QuizQuestion
              question={currentQuestion}
              questionNum={step}
              total={QUESTIONS.length}
              selectedValue={currentAnswer}
              onSelect={val => {
                setCurrentAnswer(val);
                // Auto-advance after a brief delay
                setTimeout(() => {
                  const newAnswers = { ...answers, [currentQuestion.id]: val };
                  setAnswers(newAnswers);
                  if (step >= QUESTIONS.length) {
                    setStep(QUESTIONS.length + 1);
                  } else {
                    setStep(s => s + 1);
                    setCurrentAnswer(answers[QUESTIONS[step].id]);
                  }
                }, 350);
              }}
            />
          </div>
        )}

        {isResult && (
          <div className="pt-4">
            <Result answers={answers} onReset={handleReset} />
          </div>
        )}
      </div>
    </div>
  );
}
