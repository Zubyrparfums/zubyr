import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Briefcase, MapPin, Clock, Users, ChevronRight, X, Upload, CheckCircle, ChevronDown } from "lucide-react";

const POSITIONS = [
  "Marketing Executive",
  "Senior Perfumer",
  "Junior Perfumer / Apprentice",
  "Sales Associate",
  "Brand Ambassador",
  "Workshop Facilitator",
  "E-Commerce Manager",
  "Content Creator / Social Media",
  "Operations Manager",
  "Customer Experience Executive",
  "Fragrance Consultant",
  "Lab Technician",
  "Business Development Executive",
  "Other",
];

type JobListing = {
  id: number;
  title: string;
  department: string | null;
  location: string | null;
  type: "full_time" | "part_time" | "contract" | "internship" | null;
  description: string | null;
  requirements: string | null;
  videoTopic: string | null;
  active: boolean;
};

const TYPE_LABELS: Record<string, string> = {
  full_time: "Full-Time",
  part_time: "Part-Time",
  contract: "Contract",
  internship: "Internship",
};

function JobCard({ job, onSelect }: { job: JobListing; onSelect: () => void }) {
  const { data: count } = trpc.jobs.applicationCount.useQuery({ jobId: job.id });

  return (
    <button
      onClick={onSelect}
      className="w-full text-left rounded-2xl p-5 transition-all active:scale-[0.98] group"
      style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.10)" }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-base leading-snug" style={{ color: "#0d1f14" }}>{job.title}</h3>
          {job.department && (
            <p className="text-xs font-sans mt-0.5" style={{ color: "#b45a14" }}>{job.department}</p>
          )}
          <div className="flex flex-wrap gap-2 mt-3">
            {job.location && (
              <span className="flex items-center gap-1 text-xs font-sans px-2.5 py-1 rounded-full" style={{ background: "rgba(13,31,20,0.06)", color: "rgba(13,31,20,0.60)" }}>
                <MapPin className="w-3 h-3" />{job.location}
              </span>
            )}
            {job.type && (
              <span className="flex items-center gap-1 text-xs font-sans px-2.5 py-1 rounded-full" style={{ background: "rgba(13,31,20,0.06)", color: "rgba(13,31,20,0.60)" }}>
                <Clock className="w-3 h-3" />{TYPE_LABELS[job.type] || job.type}
              </span>
            )}
            <span className="flex items-center gap-1 text-xs font-sans px-2.5 py-1 rounded-full" style={{ background: "rgba(180,90,20,0.08)", color: "#b45a14" }}>
              <Users className="w-3 h-3" />{count ?? "—"} applied
            </span>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 mt-1 flex-shrink-0 transition-transform group-hover:translate-x-0.5" style={{ color: "rgba(13,31,20,0.30)" }} />
      </div>
    </button>
  );
}

function ApplicationModal({ job, onClose }: { job: JobListing; onClose: () => void }) {
  const [step, setStep] = useState<"detail" | "apply" | "done">("detail");
  const [form, setForm] = useState({ name: "", email: "", phone: "", position: job.title, coverNote: "" });
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const { data: count } = trpc.jobs.applicationCount.useQuery({ jobId: job.id });
  const applyMutation = trpc.jobs.submitApplication.useMutation({
    onSuccess: () => setStep("done"),
    onError: () => toast.error("Something went wrong. Please try again."),
  });

  const uploadFile = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const base64 = btoa(String.fromCharCode(...Array.from(new Uint8Array(arrayBuffer))));
    const res = await fetch("/api/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: file.name, contentType: file.type || "application/octet-stream", data: base64 }),
    });
    if (!res.ok) throw new Error("Upload failed");
    const data = await res.json() as { url: string };
    return data.url;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) return toast.error("Please enter your name.");
    if (!form.email.trim()) return toast.error("Please enter your email.");
    if (!form.position) return toast.error("Please select a position.");

    setUploading(true);
    try {
      let resumeUrl: string | undefined;
      let videoUrl: string | undefined;
      if (resumeFile) resumeUrl = await uploadFile(resumeFile);
      if (videoFile) videoUrl = await uploadFile(videoFile);

      applyMutation.mutate({
        jobId: job.id,
        name: form.name,
        email: form.email,
        phone: form.phone || undefined,
        position: form.position,
        resumeUrl,
        videoUrl,
        coverNote: form.coverNote || undefined,
      });
    } catch {
      toast.error("File upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" style={{ background: "rgba(0,0,0,0.55)" }} onClick={onClose}>
      <div
        className="w-full max-w-md rounded-t-3xl sm:rounded-3xl overflow-y-auto max-h-[92vh]"
        style={{ background: "#f5f0e8" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4" style={{ background: "#0d1f14" }}>
          <div>
            <h2 className="text-white font-bold text-base leading-tight">{job.title}</h2>
            {job.department && <p className="text-xs font-sans" style={{ color: "#c8a96e" }}>{job.department}</p>}
          </div>
          <button onClick={onClose} className="text-white/50 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 pb-8">
          {step === "done" ? (
            <div className="flex flex-col items-center justify-center py-12 text-center gap-4">
              <CheckCircle className="w-14 h-14" style={{ color: "#0d1f14" }} />
              <div>
                <h3 className="text-xl font-bold" style={{ color: "#0d1f14" }}>Application Submitted!</h3>
                <p className="text-sm font-sans mt-2" style={{ color: "rgba(13,31,20,0.55)" }}>
                  Thank you for applying. We'll be in touch if your profile matches what we're looking for.
                </p>
              </div>
              <button onClick={onClose} className="mt-2 px-6 py-3 rounded-2xl text-sm font-sans font-semibold" style={{ background: "#0d1f14", color: "#f5f0e8" }}>
                Close
              </button>
            </div>
          ) : step === "detail" ? (
            <>
              {/* Meta badges */}
              <div className="flex flex-wrap gap-2 mt-5 mb-5">
                {job.location && (
                  <span className="flex items-center gap-1 text-xs font-sans px-3 py-1.5 rounded-full" style={{ background: "rgba(13,31,20,0.08)", color: "rgba(13,31,20,0.65)" }}>
                    <MapPin className="w-3 h-3" />{job.location}
                  </span>
                )}
                {job.type && (
                  <span className="flex items-center gap-1 text-xs font-sans px-3 py-1.5 rounded-full" style={{ background: "rgba(13,31,20,0.08)", color: "rgba(13,31,20,0.65)" }}>
                    <Clock className="w-3 h-3" />{TYPE_LABELS[job.type] || job.type}
                  </span>
                )}
                <span className="flex items-center gap-1 text-xs font-sans px-3 py-1.5 rounded-full" style={{ background: "rgba(180,90,20,0.10)", color: "#b45a14" }}>
                  <Users className="w-3 h-3" />{count ?? "—"} applied so far
                </span>
              </div>

              {job.description && (
                <div className="mb-5">
                  <h4 className="text-xs font-sans font-bold uppercase tracking-widest mb-2" style={{ color: "rgba(13,31,20,0.40)" }}>About the Role</h4>
                  <p className="text-sm font-sans leading-relaxed whitespace-pre-line" style={{ color: "rgba(13,31,20,0.75)" }}>{job.description}</p>
                </div>
              )}

              {job.requirements && (
                <div className="mb-5">
                  <h4 className="text-xs font-sans font-bold uppercase tracking-widest mb-2" style={{ color: "rgba(13,31,20,0.40)" }}>Requirements</h4>
                  <p className="text-sm font-sans leading-relaxed whitespace-pre-line" style={{ color: "rgba(13,31,20,0.75)" }}>{job.requirements}</p>
                </div>
              )}

              {job.videoTopic && (
                <div className="rounded-2xl p-4 mb-5" style={{ background: "rgba(180,90,20,0.08)", border: "1px solid rgba(180,90,20,0.20)" }}>
                  <h4 className="text-xs font-sans font-bold uppercase tracking-widest mb-1.5" style={{ color: "#b45a14" }}>Video Submission Topic</h4>
                  <p className="text-sm font-sans leading-relaxed" style={{ color: "rgba(13,31,20,0.75)" }}>{job.videoTopic}</p>
                  <p className="text-xs font-sans mt-1.5" style={{ color: "rgba(13,31,20,0.40)" }}>Please record a 1-minute video addressing this topic when you apply.</p>
                </div>
              )}

              <button
                onClick={() => setStep("apply")}
                className="w-full py-4 rounded-2xl text-sm font-sans font-bold tracking-wider transition-all active:scale-[0.98]"
                style={{ background: "#0d1f14", color: "#f5f0e8" }}
              >
                Apply for This Role
              </button>
            </>
          ) : (
            /* Application Form */
            <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-5">
              <div>
                <label className="block text-xs font-sans font-semibold uppercase tracking-wider mb-1.5" style={{ color: "rgba(13,31,20,0.50)" }}>
                  Full Name <span style={{ color: "#b45a14" }}>*</span>
                </label>
                <input type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Your full name" required
                  className="w-full rounded-2xl px-4 py-3.5 text-sm font-sans focus:outline-none"
                  style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.12)", color: "#0d1f14" }} />
              </div>

              <div>
                <label className="block text-xs font-sans font-semibold uppercase tracking-wider mb-1.5" style={{ color: "rgba(13,31,20,0.50)" }}>
                  Email <span style={{ color: "#b45a14" }}>*</span>
                </label>
                <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="you@example.com" required
                  className="w-full rounded-2xl px-4 py-3.5 text-sm font-sans focus:outline-none"
                  style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.12)", color: "#0d1f14" }} />
              </div>

              <div>
                <label className="block text-xs font-sans font-semibold uppercase tracking-wider mb-1.5" style={{ color: "rgba(13,31,20,0.50)" }}>
                  Phone Number
                </label>
                <input type="tel" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+65 XXXX XXXX"
                  className="w-full rounded-2xl px-4 py-3.5 text-sm font-sans focus:outline-none"
                  style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.12)", color: "#0d1f14" }} />
              </div>

              <div>
                <label className="block text-xs font-sans font-semibold uppercase tracking-wider mb-1.5" style={{ color: "rgba(13,31,20,0.50)" }}>
                  Position Applying For <span style={{ color: "#b45a14" }}>*</span>
                </label>
                <div className="relative">
                  <select value={form.position} onChange={e => setForm(f => ({ ...f, position: e.target.value }))} required
                    className="w-full rounded-2xl px-4 py-3.5 text-sm font-sans focus:outline-none appearance-none"
                    style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.12)", color: "#0d1f14" }}>
                    {POSITIONS.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none" style={{ color: "rgba(13,31,20,0.40)" }} />
                </div>
              </div>

              {/* Resume Upload */}
              <div>
                <label className="block text-xs font-sans font-semibold uppercase tracking-wider mb-1.5" style={{ color: "rgba(13,31,20,0.50)" }}>
                  Resume / CV
                </label>
                <label className="flex items-center gap-3 rounded-2xl px-4 py-3.5 cursor-pointer transition-all"
                  style={{ background: "#fff", border: "1px dashed rgba(13,31,20,0.20)" }}>
                  <Upload className="w-4 h-4 flex-shrink-0" style={{ color: "rgba(13,31,20,0.40)" }} />
                  <span className="text-sm font-sans" style={{ color: resumeFile ? "#0d1f14" : "rgba(13,31,20,0.40)" }}>
                    {resumeFile ? resumeFile.name : "Upload PDF or DOC"}
                  </span>
                  <input type="file" accept=".pdf,.doc,.docx" className="hidden" onChange={e => setResumeFile(e.target.files?.[0] ?? null)} />
                </label>
              </div>

              {/* Video Upload */}
              {job.videoTopic && (
                <div>
                  <label className="block text-xs font-sans font-semibold uppercase tracking-wider mb-1" style={{ color: "rgba(13,31,20,0.50)" }}>
                    1-Minute Video
                  </label>
                  <p className="text-xs font-sans mb-1.5" style={{ color: "rgba(13,31,20,0.40)" }}>Topic: {job.videoTopic}</p>
                  <label className="flex items-center gap-3 rounded-2xl px-4 py-3.5 cursor-pointer transition-all"
                    style={{ background: "#fff", border: "1px dashed rgba(13,31,20,0.20)" }}>
                    <Upload className="w-4 h-4 flex-shrink-0" style={{ color: "rgba(13,31,20,0.40)" }} />
                    <span className="text-sm font-sans" style={{ color: videoFile ? "#0d1f14" : "rgba(13,31,20,0.40)" }}>
                      {videoFile ? videoFile.name : "Upload MP4 or MOV (max 100MB)"}
                    </span>
                    <input type="file" accept="video/*" className="hidden" onChange={e => setVideoFile(e.target.files?.[0] ?? null)} />
                  </label>
                </div>
              )}

              {/* Cover Note */}
              <div>
                <label className="block text-xs font-sans font-semibold uppercase tracking-wider mb-1.5" style={{ color: "rgba(13,31,20,0.50)" }}>
                  Cover Note
                </label>
                <textarea rows={4} value={form.coverNote} onChange={e => setForm(f => ({ ...f, coverNote: e.target.value }))}
                  placeholder="Tell us why you'd be a great fit for ZUBYR..."
                  className="w-full rounded-2xl px-4 py-3.5 text-sm font-sans focus:outline-none resize-none"
                  style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.12)", color: "#0d1f14" }} />
              </div>

              <button type="submit" disabled={applyMutation.isPending || uploading}
                className="w-full py-4 rounded-2xl text-sm font-sans font-bold tracking-wider transition-all active:scale-[0.98] disabled:opacity-60"
                style={{ background: "#0d1f14", color: "#f5f0e8" }}>
                {uploading ? "Uploading Files…" : applyMutation.isPending ? "Submitting…" : "Submit Application"}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Careers() {
  const { data: jobs, isLoading } = trpc.jobs.list.useQuery({ activeOnly: true });
  const [selectedJob, setSelectedJob] = useState<JobListing | null>(null);

  const defaultJobs: JobListing[] = [
    {
      id: -1, title: "Marketing Executive", department: "Marketing", location: "Singapore",
      type: "full_time", active: true,
      description: "Drive ZUBYR's brand presence across digital and physical touchpoints. You'll manage campaigns, coordinate with influencers, and help tell the story of Singapore's most exciting fragrance brand.\n\nYou'll work closely with our creative team to produce content that resonates with fragrance lovers across Southeast Asia.",
      requirements: "• 2+ years in marketing or brand communications\n• Strong understanding of social media platforms (Instagram, TikTok)\n• Excellent written and verbal communication\n• Passion for luxury, lifestyle, or fragrance brands\n• Experience with content creation tools is a plus",
      videoTopic: "Tell us about a brand campaign you admire and how you would adapt a similar concept for ZUBYR.",
    },
    {
      id: -2, title: "Senior Perfumer", department: "Creative & Formulation", location: "Singapore",
      type: "full_time", active: true,
      description: "Lead the creation of ZUBYR's signature fragrance collections. As our Senior Perfumer, you will develop original scent compositions, guide the formulation process, and collaborate with our creative director to bring each fragrance story to life.",
      requirements: "• Formal training from a recognised perfumery school (ISIPCA, Givaudan, etc.)\n• 5+ years of professional formulation experience\n• Deep knowledge of raw materials, accords, and fragrance families\n• Experience with both fine fragrance and functional applications\n• Strong creative vision and storytelling ability",
      videoTopic: "Describe a fragrance accord you have created that you are most proud of, and walk us through your creative process.",
    },
    {
      id: -3, title: "Workshop Facilitator", department: "Education & Experiences", location: "Singapore",
      type: "part_time", active: true,
      description: "Facilitate ZUBYR's personalised perfume-making workshops for individuals, groups, and corporate clients. You'll guide participants through the art of scent blending, creating memorable and educational experiences.",
      requirements: "• Background in fragrance, beauty, or experiential education\n• Confident public speaker with warm, engaging presence\n• Ability to work weekends and evenings\n• Basic knowledge of fragrance notes and blending\n• Customer service experience preferred",
      videoTopic: "Imagine you are facilitating a workshop for a group of first-time perfumers. How would you introduce them to the world of fragrance in the first 5 minutes?",
    },
    {
      id: -4, title: "Sales Associate", department: "Retail & Sales", location: "Singapore",
      type: "full_time", active: true,
      description: "Be the face of ZUBYR at our showroom and pop-up events. You'll help customers discover their signature scent, manage the retail experience, and contribute to our growing community of fragrance enthusiasts.",
      requirements: "• 1+ year in retail or luxury sales\n• Passion for fragrance and beauty\n• Excellent interpersonal and communication skills\n• Ability to work retail hours including weekends\n• Multilingual ability (English + Mandarin or Malay) is a plus",
      videoTopic: "A customer walks in and says they have never bought a perfume for themselves before. How do you guide them?",
    },
    {
      id: -5, title: "Junior Perfumer / Apprentice", department: "Creative & Formulation", location: "Singapore",
      type: "internship", active: true,
      description: "An exciting opportunity to learn the craft of perfumery under the guidance of our Senior Perfumer. You'll assist in formulation, raw material evaluation, and the development of new accords while building your professional portfolio.",
      requirements: "• Currently enrolled in or recently graduated from a perfumery or chemistry programme\n• Keen sensory awareness and curiosity about scent\n• Detail-oriented and methodical in lab settings\n• Eager to learn and grow within the fragrance industry",
      videoTopic: "What drew you to perfumery, and what scent memory from your life would you most want to recreate as a fragrance?",
    },
  ];

  const displayJobs = (jobs && jobs.length > 0) ? jobs : defaultJobs;

  return (
    <div className="min-h-screen font-serif" style={{ background: "#f5f0e8" }}>
      {/* Header */}
      <header className="sticky top-0 z-40 px-4 py-4 flex items-center gap-3" style={{ background: "#0d1f14" }}>
        <a href="/" className="text-white/60 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </a>
        <div>
          <h1 className="text-white font-bold tracking-widest uppercase text-sm">Careers</h1>
          <p className="text-white/40 text-xs font-sans">Join the ZUBYR team</p>
        </div>
      </header>

      <div className="max-w-md mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold" style={{ color: "#0d1f14" }}>Work With Us</h2>
          <p className="text-sm font-sans mt-2 leading-relaxed" style={{ color: "rgba(13,31,20,0.55)" }}>
            We're building Singapore's most exciting fragrance ecosystem. If you're passionate about scent, culture, and craft — we'd love to meet you.
          </p>
        </div>

        {isLoading ? (
          <div className="flex flex-col gap-3">
            {[1,2,3].map(i => (
              <div key={i} className="h-28 rounded-2xl animate-pulse" style={{ background: "rgba(13,31,20,0.06)" }} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {displayJobs.map(job => (
              <JobCard key={job.id} job={job} onSelect={() => setSelectedJob(job)} />
            ))}
          </div>
        )}

        <div className="mt-8 rounded-2xl p-5 text-center" style={{ background: "rgba(13,31,20,0.05)", border: "1px dashed rgba(13,31,20,0.15)" }}>
          <Briefcase className="w-6 h-6 mx-auto mb-2" style={{ color: "rgba(13,31,20,0.30)" }} />
          <p className="text-sm font-sans" style={{ color: "rgba(13,31,20,0.50)" }}>
            Don't see a role that fits? Send your portfolio to{" "}
            <a href="mailto:admin@zubyr.co" className="underline" style={{ color: "#b45a14" }}>admin@zubyr.co</a>
          </p>
        </div>
      </div>

      {selectedJob && <ApplicationModal job={selectedJob} onClose={() => setSelectedJob(null)} />}
    </div>
  );
}
