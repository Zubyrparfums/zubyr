import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ShoppingBag, CalendarDays, Sparkles, BookOpen, FlaskConical,
  GraduationCap, Newspaper, Users, Mail, MapPin, Instagram,
  Youtube, Facebook, Linkedin, ChevronRight, Leaf, Phone, Star,
} from "lucide-react";

// ── Brand tokens ──────────────────────────────────────────────────────────────
const PINE     = "#2d4a3e";
const FOREST   = "#1a3028";
const EVERGREEN= "#0f1f18";
const SPICE    = "#8B3A1A";
const RUST     = "#A0390F";
const AMBER    = "#C8912E";
const CREAM    = "#F2EDE4";
const LINEN    = "#E8E0D4";
const STONE    = "#9A8A78";

const KLOOK_URL    = "https://s.klook.com/c/mwkG00KkyQ";
const WHATSAPP_URL = "https://wa.me/6581877202?text=Hi%20ZUBYR%2C%20I%27m%20interested%20in%20a%20private%20or%20corporate%20workshop.";
const GMAPS_URL    = "https://maps.google.com/?q=ZUBYR+Singapore";

const heroModules = [
  { id:"shop",     label:"Shop Perfumes",           sub:"Curated collections & bespoke scents",       icon:ShoppingBag, href:"/shop",   ext:false },
  { id:"workshop", label:"Perfume Making Workshop",  sub:"Group · Private · Corporate",                icon:CalendarDays,href:KLOOK_URL,ext:true  },
  { id:"scentmate",label:"ScentMate AI™",            sub:"Find your signature scent in 2 minutes",    icon:Sparkles,    href:"/scentmate",ext:false},
];

const exploreModules = [
  { id:"concierge",    label:"Fragrance Concierge",    sub:"Explore the fragrance universe",     icon:BookOpen,      href:"/concierge"    },
  { id:"ingredients",  label:"Ingredient Library",     sub:"Every note & raw material",          icon:Leaf,          href:"/ingredients"  },
  { id:"formulations", label:"Formulation Marketplace",sub:"Buy & download perfume formulas",    icon:FlaskConical,  href:"/formulations" },
  { id:"school",       label:"Perfumery School",       sub:"Professional courses & certification",icon:GraduationCap,href:"/school"       },
  { id:"blog",         label:"Blog & Academy",         sub:"Deep dives into fragrance science",  icon:Newspaper,     href:"/blog"         },
  { id:"community",    label:"Community Marketplace",  sub:"Buy, sell & exchange with peers",    icon:Users,         href:"/community"    },
  { id:"newsletter",   label:"Weekly Newsletter",      sub:"Every Monday & Friday",              icon:Mail,          href:"/newsletter"   },
];

const socials = [
  { label:"Instagram", icon:Instagram, href:"https://instagram.com/zubyr.co" },
  { label:"TikTok", icon:()=>(
    <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
      <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.18 8.18 0 004.78 1.52V6.78a4.85 4.85 0 01-1.01-.09z"/>
    </svg>
  ), href:"https://tiktok.com/@zubyr.co" },
  { label:"YouTube",  icon:Youtube,  href:"https://youtube.com/@zubyr-co" },
  { label:"Facebook", icon:Facebook, href:"https://facebook.com/zubyr.co" },
  { label:"LinkedIn", icon:Linkedin, href:"https://linkedin.com/company/zubyr.co" },
];

function NewsletterRow() {
  const [email, setEmail] = useState("");
  const [done, setDone]   = useState(false);
  const sub = trpc.newsletter.subscribe.useMutation({
    onSuccess: () => setDone(true),
    onError: (e) => toast.error(e.message || "Something went wrong."),
  });
  if (done) return (
    <p className="text-sm font-sans font-semibold tracking-wide text-center py-1" style={{color:AMBER}}>
      ✦ You're subscribed. Welcome to ZUBYR.
    </p>
  );
  return (
    <div className="flex gap-2">
      <input
        type="email" value={email} onChange={e=>setEmail(e.target.value)}
        placeholder="your@email.com"
        onKeyDown={e=>e.key==="Enter"&&email&&sub.mutate({email})}
        className="flex-1 min-w-0 px-4 py-3 rounded-xl font-sans text-sm focus:outline-none"
        style={{background:"rgba(255,255,255,0.08)",border:"1px solid rgba(255,255,255,0.16)",color:"#fff"}}
      />
      <button
        onClick={()=>email&&sub.mutate({email})}
        disabled={sub.isPending||!email}
        className="px-5 py-3 rounded-xl font-sans font-bold text-sm flex-shrink-0 disabled:opacity-50 active:scale-95"
        style={{background:SPICE,color:"#fff"}}
      >
        {sub.isPending?"…":"Join"}
      </button>
    </div>
  );
}

export default function Home() {
  return (
    <div className="min-h-screen font-serif" style={{background:EVERGREEN}}>

      {/* ═══════════════════════════════════════════════════════════
          HERO — full-bleed pine dark, gold wordmark, three CTAs
      ═══════════════════════════════════════════════════════════ */}
      <section className="relative flex flex-col items-center justify-center overflow-hidden" style={{minHeight:"100svh"}}>
        {/* Textured bg */}
        <div className="absolute inset-0" style={{backgroundImage:"url('/manus-storage/darkgreen_79cedb4e.jpg')",backgroundSize:"cover",backgroundPosition:"center"}}/>
        {/* Layered vignette */}
        <div className="absolute inset-0" style={{background:`radial-gradient(ellipse at 50% 35%, rgba(15,31,24,0.10) 0%, rgba(15,31,24,0.78) 100%)`}}/>
        {/* Bottom fade into section below */}
        <div className="absolute inset-x-0 bottom-0 h-48" style={{background:`linear-gradient(to bottom, transparent, ${EVERGREEN})`}}/>

        <div className="relative z-10 flex flex-col items-center px-5 text-center w-full max-w-sm mx-auto pt-20 pb-36">

          {/* Logo */}
          <div style={{width:260,height:104,marginBottom:"1.75rem"}}>
            <img
              src="/manus-storage/zubyrlogo_gold_2715579e.png" alt="ZUBYR"
              style={{width:"100%",height:"100%",objectFit:"contain",filter:"drop-shadow(0 6px 28px rgba(200,145,46,0.50))"}}
            />
          </div>

          {/* Hair rule */}
          <div style={{width:36,height:1,background:`linear-gradient(90deg, transparent, ${AMBER}, transparent)`,marginBottom:"1.25rem"}}/>

          {/* Heritage tag */}
          <p className="font-sans font-semibold text-xs tracking-[0.28em] uppercase mb-4" style={{color:AMBER,opacity:.82}}>
            4th Generation Master Perfumer · Singapore
          </p>

          {/* Tagline */}
          <p className="text-[1.45rem] leading-relaxed mb-1.5" style={{color:"rgba(255,255,255,0.92)",fontStyle:"italic",fontWeight:300}}>
            "Wear a scent<br/>entirely your own."
          </p>
          <p className="font-sans text-xs leading-relaxed mb-9 max-w-[240px] mx-auto" style={{color:"rgba(255,255,255,0.38)"}}>
            Singapore's only multi-generational bespoke perfumery house.
          </p>

          {/* ── Hero CTAs ── */}
          <div className="flex flex-col gap-2.5 w-full">
            {heroModules.map(mod => {
              const Icon = mod.icon;
              return (
                <a key={mod.id} href={mod.href} target={mod.ext?"_blank":undefined} rel={mod.ext?"noopener noreferrer":undefined}
                  className="relative overflow-hidden rounded-2xl flex items-center gap-3.5 px-5 py-4 no-underline group active:scale-[0.97]"
                  style={{backgroundImage:"url('/manus-storage/burntamber_426b14a7.jpg')",backgroundSize:"cover",backgroundPosition:"center",boxShadow:"0 4px 24px rgba(0,0,0,0.50)"}}>
                  {/* overlays */}
                  <div className="absolute inset-0 rounded-2xl" style={{background:"rgba(26,48,40,0.52)"}}/>
                  <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{background:"rgba(139,58,26,0.18)"}}/>
                  {/* icon */}
                  <div className="relative z-10 w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:"rgba(200,145,46,0.18)",border:"1px solid rgba(200,145,46,0.32)"}}>
                    <Icon className="w-4.5 h-4.5" style={{color:AMBER}}/>
                  </div>
                  {/* text */}
                  <div className="relative z-10 flex-1 min-w-0 text-left">
                    <p className="font-bold text-sm leading-tight tracking-wide" style={{color:"#fff"}}>{mod.label}</p>
                    <p className="font-sans text-xs mt-0.5 leading-snug" style={{color:"rgba(255,255,255,0.50)"}}>{mod.sub}</p>
                  </div>
                  <ChevronRight className="relative z-10 w-4 h-4 flex-shrink-0 transition-transform group-hover:translate-x-1" style={{color:AMBER}}/>
                </a>
              );
            })}
          </div>

          {/* WhatsApp pill */}
          <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer"
            className="mt-3.5 flex items-center justify-center gap-2 w-full py-3 rounded-2xl font-sans font-semibold text-sm no-underline active:scale-95"
            style={{background:"rgba(34,197,94,0.12)",border:"1px solid rgba(34,197,94,0.28)",color:"#4ade80"}}>
            <Phone className="w-4 h-4"/>
            WhatsApp for Private &amp; Corporate
          </a>

          {/* Scroll indicator */}
          <div className="mt-12 flex flex-col items-center gap-1.5 opacity-30">
            <p className="font-sans text-xs uppercase tracking-[0.22em]" style={{color:AMBER}}>Explore</p>
            <div className="w-px h-7" style={{background:`linear-gradient(to bottom, ${AMBER}, transparent)`}}/>
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════
          CREDENTIAL STRIP
      ═══════════════════════════════════════════════════════════ */}
      <section style={{background:FOREST,borderTop:`1px solid rgba(200,145,46,0.14)`,borderBottom:`1px solid rgba(200,145,46,0.14)`}} className="py-5 px-5">
        <div className="max-w-sm mx-auto flex items-center justify-between gap-2">
          {[{n:"4th",l:"Generation"},{n:"100+",l:"Formulas"},{n:"10K+",l:"Clients"},{n:"SG",l:"Based"}].map(s=>(
            <div key={s.n} className="text-center flex-shrink-0">
              <p className="font-sans font-bold text-lg leading-none" style={{color:AMBER}}>{s.n}</p>
              <p className="font-sans text-[10px] uppercase tracking-widest mt-1" style={{color:"rgba(255,255,255,0.30)"}}>{s.l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════
          EXPLORE GRID — pine fade into cream
      ═══════════════════════════════════════════════════════════ */}
      <section style={{background:`linear-gradient(180deg, ${FOREST} 0%, ${CREAM} 90px)`}} className="px-5 pt-0 pb-3">
        <div className="max-w-sm mx-auto">
          {/* Section label */}
          <div className="flex items-center gap-3 pt-8 pb-5">
            <div className="flex-1 h-px" style={{background:"rgba(200,145,46,0.18)"}}/>
            <p className="font-sans font-bold text-xs tracking-[0.24em] uppercase" style={{color:AMBER}}>Explore ZUBYR</p>
            <div className="flex-1 h-px" style={{background:"rgba(200,145,46,0.18)"}}/>
          </div>

          <div className="flex flex-col gap-2">
            {exploreModules.map(mod => {
              const Icon = mod.icon;
              return (
                <a key={mod.id} href={mod.href}
                  className="group flex items-center gap-3.5 rounded-2xl px-4 py-3.5 no-underline active:scale-[0.98]"
                  style={{background:"#fff",border:`1px solid rgba(45,74,62,0.09)`,boxShadow:"0 1px 6px rgba(26,48,40,0.05)"}}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:`rgba(45,74,62,0.07)`}}>
                    <Icon className="w-4 h-4" style={{color:PINE}}/>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm" style={{color:FOREST}}>{mod.label}</p>
                    <p className="font-sans text-xs mt-0.5" style={{color:STONE}}>{mod.sub}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 flex-shrink-0 transition-transform group-hover:translate-x-1" style={{color:`rgba(139,58,26,0.45)`}}/>
                </a>
              );
            })}
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════
          NEWSLETTER CTA
      ═══════════════════════════════════════════════════════════ */}
      <section className="px-5 py-7" style={{background:CREAM}}>
        <div className="max-w-sm mx-auto rounded-2xl overflow-hidden" style={{background:FOREST,boxShadow:"0 8px 40px rgba(26,48,40,0.22)"}}>
          <div className="px-6 pt-6 pb-5">
            <div className="flex items-center gap-2 mb-2">
              <Mail className="w-4 h-4" style={{color:AMBER}}/>
              <span className="font-sans font-bold text-xs tracking-[0.22em] uppercase" style={{color:AMBER}}>Weekly Newsletter</span>
            </div>
            <h3 className="text-[1.4rem] mb-1 leading-snug" style={{color:"#fff"}}>Stay inside the world<br/>of fragrance.</h3>
            <p className="font-sans text-xs leading-relaxed mb-5" style={{color:"rgba(255,255,255,0.42)"}}>
              Every Monday &amp; Friday — inside ZUBYR and around the fragrance world. No spam, ever.
            </p>
            <NewsletterRow/>
          </div>
          <div className="px-6 py-3 flex items-center gap-2" style={{background:"rgba(200,145,46,0.08)",borderTop:`1px solid rgba(200,145,46,0.12)`}}>
            <Star className="w-3 h-3" style={{color:AMBER}} fill={AMBER}/>
            <p className="font-sans text-xs" style={{color:"rgba(255,255,255,0.35)"}}>2,000+ fragrance enthusiasts across Singapore &amp; beyond</p>
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════
          SOCIAL LINKS
      ═══════════════════════════════════════════════════════════ */}
      <section className="px-5 pb-5" style={{background:CREAM}}>
        <p className="font-sans font-semibold text-xs tracking-[0.22em] uppercase text-center mb-4" style={{color:"rgba(26,48,40,0.28)"}}>Follow Along</p>
        <div className="flex justify-center gap-2 flex-wrap max-w-sm mx-auto">
          {socials.map(s=>{
            const Icon = s.icon;
            return (
              <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-full px-4 py-2.5 no-underline active:scale-95"
                style={{background:"#fff",border:`1px solid rgba(45,74,62,0.09)`,color:FOREST,boxShadow:"0 1px 4px rgba(26,48,40,0.06)"}}>
                <Icon className="w-3.5 h-3.5"/>
                <span className="font-sans font-medium text-xs">{s.label}</span>
              </a>
            );
          })}
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════
          SHOWROOM / MAPS
      ═══════════════════════════════════════════════════════════ */}
      <section className="px-5 pb-5" style={{background:CREAM}}>
        <div className="max-w-sm mx-auto">
          <a href={GMAPS_URL} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-3.5 rounded-2xl px-5 py-4 no-underline group active:scale-[0.98]"
            style={{background:"#fff",border:`1px solid rgba(45,74,62,0.09)`,boxShadow:"0 1px 6px rgba(26,48,40,0.05)"}}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:`rgba(45,74,62,0.07)`}}>
              <MapPin className="w-4.5 h-4.5" style={{color:PINE}}/>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm" style={{color:FOREST}}>Visit Our Showroom</p>
              <p className="font-sans text-xs mt-0.5" style={{color:STONE}}>Singapore · by appointment</p>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-sans font-bold text-xs" style={{background:PINE,color:"#fff"}}>
              Directions
            </div>
          </a>
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════
          FOOTER
      ═══════════════════════════════════════════════════════════ */}
      <footer className="px-5 pb-20" style={{background:CREAM}}>
        <div className="max-w-sm mx-auto">
          <div className="flex justify-center gap-5 mb-4 flex-wrap">
            {[["Contact","/contact"],["Careers","/careers"],["Wholesale","/wholesale"],["Collabs","/collaborations"],["Ideas","/ideas"]].map(([l,h])=>(
              <a key={l} href={h} className="font-sans text-xs no-underline" style={{color:"rgba(26,48,40,0.38)"}}>
                {l}
              </a>
            ))}
          </div>
          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 h-px" style={{background:"rgba(26,48,40,0.09)"}}/>
            <div className="w-1 h-1 rounded-full" style={{background:`rgba(139,58,26,0.30)`}}/>
            <div className="flex-1 h-px" style={{background:"rgba(26,48,40,0.09)"}}/>
          </div>
          <div className="text-center">
            <p className="font-sans text-xs uppercase tracking-[0.18em]" style={{color:"rgba(26,48,40,0.22)"}}>Vision 2035</p>
            <p className="font-sans text-xs mt-1" style={{color:"rgba(26,48,40,0.18)"}}>
              © {new Date().getFullYear()} ZUBYR — Singapore's Fragrance Ecosystem
            </p>
          </div>
        </div>
      </footer>

    </div>
  );
}
