import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ShoppingBag, ChevronRight, Search, Sparkles, Filter } from "lucide-react";

const COLLECTIONS = [
  { value: "all",       label: "All Collections" },
  { value: "signature", label: "Signature"        },
  { value: "premium",   label: "Premium"          },
  { value: "niche",     label: "Niche"            },
  { value: "oud",       label: "Oud"              },
  { value: "collabs",   label: "Collabs"          },
];

const COLLECTION_PALETTES: Record<string, { bg: string; text: string; border: string }> = {
  signature: { bg: "rgba(13,31,20,0.08)",   text: "#1a3028", border: "rgba(13,31,20,0.15)" },
  premium:   { bg: "rgba(212,175,55,0.15)", text: "#92710e", border: "rgba(212,175,55,0.35)" },
  niche:     { bg: "rgba(90,50,120,0.10)",  text: "#5a3278", border: "rgba(90,50,120,0.20)" },
  oud:       { bg: "rgba(120,50,15,0.10)",  text: "#78320f", border: "rgba(120,50,15,0.20)" },
  collabs:   { bg: "rgba(20,80,120,0.10)",  text: "#145078", border: "rgba(20,80,120,0.20)" },
};

const FRAGRANCE_FAMILIES = ["All", "Woody", "Floral", "Oriental", "Fresh", "Citrus", "Gourmand", "Chypre", "Fougère"];

function ProductCard({ product }: { product: any }) {
  const palette = COLLECTION_PALETTES[product.collection] ?? COLLECTION_PALETTES.signature;
  return (
    <div className="group rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl active:scale-[0.98]" style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.07)", boxShadow: "0 2px 12px rgba(13,31,20,0.06)" }}>
      {/* Image */}
      <div className="relative aspect-square overflow-hidden" style={{ background: "linear-gradient(135deg, #f5f0e8 0%, #ede6d8 100%)" }}>
        {product.imageUrl ? (
          <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Sparkles className="w-12 h-12 opacity-20" style={{ color: "#1a3028" }} />
          </div>
        )}
        {/* Collection badge */}
        <div className="absolute top-3 left-3">
          <span className="text-[10px] font-sans font-bold uppercase tracking-wider px-2 py-1 rounded-full" style={{ background: palette.bg, color: palette.text, border: `1px solid ${palette.border}`, backdropFilter: "blur(8px)" }}>
            {product.collection}
          </span>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <h3 className="font-semibold text-sm leading-snug mb-1" style={{ color: "#1a3028" }}>{product.name}</h3>
        {product.fragranceFamily && (
          <p className="text-xs font-sans mb-1" style={{ color: "rgba(13,31,20,0.45)" }}>{product.fragranceFamily}</p>
        )}
        {(product.topNotes || product.baseNotes) && (
          <p className="text-xs font-sans mb-3 line-clamp-1" style={{ color: "rgba(13,31,20,0.35)" }}>
            {[product.topNotes, product.middleNotes, product.baseNotes].filter(Boolean).join(" · ")}
          </p>
        )}
        <div className="flex items-center justify-between mt-2">
          <p className="font-bold text-base" style={{ color: "#1a3028" }}>
            {product.price ? `S$${parseFloat(product.price).toFixed(2)}` : "Enquire"}
          </p>
          <a
            href={`https://wa.me/6581877202?text=Hi%20ZUBYR%2C%20I%27m%20interested%20in%20${encodeURIComponent(product.name)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-sans font-bold px-3 py-1.5 rounded-xl transition-all hover:opacity-85"
            style={{ background: "#1a3028", color: "#F2EDE4" }}
          >
            Enquire
          </a>
        </div>
      </div>
    </div>
  );
}

export default function Shop() {
  const [activeCollection, setActiveCollection] = useState("all");
  const [search, setSearch] = useState("");

  const { data: products = [], isLoading } = trpc.products.list.useQuery({ activeOnly: true });

  const filtered = products.filter(p => {
    const matchesColl = activeCollection === "all" || p.collection === activeCollection;
    const matchesSearch = !search || p.name.toLowerCase().includes(search.toLowerCase()) || (p.description ?? "").toLowerCase().includes(search.toLowerCase());
    return matchesColl && matchesSearch;
  });

  return (
    <div className="min-h-screen" style={{ background: "#F2EDE4" }}>

      {/* Header */}
      <div className="relative overflow-hidden" style={{ background: "#1a3028", paddingBottom: "2rem" }}>
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "url('/manus-storage/darkgreen_79cedb4e.jpg')", backgroundSize: "cover" }} />
        <div className="absolute inset-0" style={{ background: "rgba(13,31,20,0.75)" }} />
        <div className="relative z-10 px-5 pt-12 pb-6 max-w-2xl mx-auto">
          <Link href="/">
            <button className="flex items-center gap-2 text-sm mb-6 transition-colors" style={{ color: "rgba(212,175,55,0.75)" }}>
              <ArrowLeft className="w-4 h-4" /> Back to ZUBYR
            </button>
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <ShoppingBag className="w-6 h-6" style={{ color: "#d4af37" }} />
            <span className="text-xs font-sans font-bold tracking-[0.22em] uppercase" style={{ color: "#d4af37" }}>ZUBYR</span>
          </div>
          <h1 className="text-4xl mb-2" style={{ color: "#fff" }}>Shop Perfumes</h1>
          <p className="font-sans text-sm mb-6" style={{ color: "rgba(255,255,255,0.50)" }}>
            Bespoke fragrances crafted by Singapore's 4th generation master perfumer.
          </p>
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: "rgba(255,255,255,0.35)" }} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by name or notes…"
              className="w-full pl-11 pr-4 py-3 rounded-xl font-sans text-sm focus:outline-none"
              style={{ background: "rgba(255,255,255,0.10)", border: "1px solid rgba(255,255,255,0.18)", color: "#fff" }}
            />
          </div>
        </div>
      </div>

      {/* Collection Filter */}
      <div className="sticky top-0 z-20 border-b px-5 py-3" style={{ background: "rgba(245,240,232,0.97)", borderColor: "rgba(13,31,20,0.08)", backdropFilter: "blur(12px)" }}>
        <div className="flex gap-2 overflow-x-auto max-w-2xl mx-auto" style={{ scrollbarWidth: "none" }}>
          {COLLECTIONS.map(col => (
            <button
              key={col.value}
              onClick={() => setActiveCollection(col.value)}
              className="flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-sans font-semibold tracking-wide transition-all duration-200"
              style={
                activeCollection === col.value
                  ? { background: "#1a3028", color: "#F2EDE4", border: "1px solid #0d1f14" }
                  : { background: "transparent", color: "rgba(13,31,20,0.55)", border: "1px solid rgba(13,31,20,0.15)" }
              }
            >
              {col.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="px-4 py-6 max-w-2xl mx-auto">
        {isLoading ? (
          <div className="grid grid-cols-2 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-2xl overflow-hidden animate-pulse" style={{ background: "#e8e0d4" }}>
                <div className="aspect-square" />
                <div className="p-4 space-y-2">
                  <div className="h-3 rounded w-3/4" style={{ background: "rgba(13,31,20,0.10)" }} />
                  <div className="h-3 rounded w-1/2" style={{ background: "rgba(13,31,20,0.07)" }} />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <ShoppingBag className="w-14 h-14 mx-auto mb-4 opacity-15" style={{ color: "#1a3028" }} />
            <h3 className="text-xl mb-2" style={{ color: "#1a3028" }}>No products found</h3>
            <p className="font-sans text-sm" style={{ color: "rgba(13,31,20,0.45)" }}>
              {search ? "Try a different search term." : "No products in this collection yet. Check back soon."}
            </p>
          </div>
        ) : (
          <>
            <p className="text-xs font-sans mb-4" style={{ color: "rgba(13,31,20,0.40)" }}>
              {filtered.length} fragrance{filtered.length !== 1 ? "s" : ""}
            </p>
            <div className="grid grid-cols-2 gap-4">
              {filtered.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </>
        )}

        {/* Bespoke CTA */}
        <div className="mt-10 rounded-2xl overflow-hidden" style={{ background: "#1a3028" }}>
          <div className="px-6 py-6">
            <p className="text-xs font-sans font-bold tracking-[0.20em] uppercase mb-2" style={{ color: "#d4af37" }}>Bespoke Service</p>
            <h3 className="text-2xl mb-2" style={{ color: "#fff" }}>Can't find your scent?</h3>
            <p className="font-sans text-sm mb-5" style={{ color: "rgba(255,255,255,0.50)" }}>
              Work directly with our master perfumer to create a fragrance that is entirely, uniquely yours.
            </p>
            <a
              href="https://wa.me/6581877202?text=Hi%20ZUBYR%2C%20I%27m%20interested%20in%20a%20bespoke%20fragrance."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl font-sans font-bold text-sm transition-all hover:opacity-90"
              style={{ background: "#d4af37", color: "#1a3028" }}
            >
              Enquire via WhatsApp <ChevronRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>

      <div className="py-8 text-center font-sans text-xs" style={{ color: "rgba(13,31,20,0.25)" }}>
        © {new Date().getFullYear()} ZUBYR — Singapore's Fragrance Ecosystem
      </div>
    </div>
  );
}
