import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { BookOpen, Clock, ArrowLeft, Search } from "lucide-react";

const CATEGORIES = [
  { value: "all",                          label: "All"                       },
  { value: "ingredient_academy",           label: "Ingredient Academy"        },
  { value: "perfume_science",              label: "Perfume Science"           },
  { value: "perfumery_school",             label: "Perfumery School"          },
  { value: "formula_breakdowns",           label: "Formula Breakdowns"        },
  { value: "perfumer_stories",             label: "Perfumer Stories"          },
  { value: "singapore_fragrance_reports",  label: "SG Fragrance"             },
  { value: "scentmate_insights",           label: "ScentMate"                },
  { value: "workshop_journal",             label: "Workshop"                  },
  { value: "community_spotlight",          label: "Community"                 },
  { value: "fragrance_encyclopedia",       label: "Encyclopedia"              },
];

const CATEGORY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  ingredient_academy:          { bg: "rgba(5,90,50,0.12)",   text: "#055a32",  border: "rgba(5,90,50,0.25)"   },
  perfume_science:             { bg: "rgba(20,60,120,0.12)", text: "#143c78",  border: "rgba(20,60,120,0.25)" },
  perfumery_school:            { bg: "rgba(80,20,100,0.12)", text: "#501464",  border: "rgba(80,20,100,0.25)" },
  formula_breakdowns:          { bg: "rgba(140,80,0,0.12)",  text: "#8c5000",  border: "rgba(140,80,0,0.25)"  },
  perfumer_stories:            { bg: "rgba(140,20,40,0.12)", text: "#8c1428",  border: "rgba(140,20,40,0.25)" },
  singapore_fragrance_reports: { bg: "rgba(180,50,0,0.12)",  text: "#b43200",  border: "rgba(180,50,0,0.25)"  },
  scentmate_insights:          { bg: "rgba(0,100,120,0.12)", text: "#006478",  border: "rgba(0,100,120,0.25)" },
  workshop_journal:            { bg: "rgba(140,60,0,0.12)",  text: "#8c3c00",  border: "rgba(140,60,0,0.25)"  },
  community_spotlight:         { bg: "rgba(0,90,80,0.12)",   text: "#005a50",  border: "rgba(0,90,80,0.25)"   },
  fragrance_encyclopedia:      { bg: "rgba(40,40,120,0.12)", text: "#282878",  border: "rgba(40,40,120,0.25)" },
};

const DARK_CATEGORY_COLORS: Record<string, string> = {
  ingredient_academy: "bg-emerald-900/60 text-emerald-200 border-emerald-700",
  perfume_science: "bg-blue-900/60 text-blue-200 border-blue-700",
  perfumery_school: "bg-purple-900/60 text-purple-200 border-purple-700",
  formula_breakdowns: "bg-amber-900/60 text-amber-200 border-amber-700",
  perfumer_stories: "bg-rose-900/60 text-rose-200 border-rose-700",
  singapore_fragrance_reports: "bg-red-900/60 text-red-200 border-red-700",
  scentmate_insights: "bg-cyan-900/60 text-cyan-200 border-cyan-700",
  workshop_journal: "bg-orange-900/60 text-orange-200 border-orange-700",
  community_spotlight: "bg-teal-900/60 text-teal-200 border-teal-700",
  fragrance_encyclopedia: "bg-indigo-900/60 text-indigo-200 border-indigo-700",
};

function categoryLabel(cat: string) {
  return CATEGORIES.find(c => c.value === cat)?.label ?? cat;
}

function PostCard({ post }: { post: any }) {
  const col = post.category ? CATEGORY_COLORS[post.category] : null;
  return (
    <Link href={`/blog/${post.slug}`}>
      <article className="group h-full rounded-2xl overflow-hidden transition-all duration-300 cursor-pointer flex flex-col hover:shadow-lg active:scale-[0.98]" style={{ background: "#fff", border: "1px solid rgba(13,31,20,0.08)", boxShadow: "0 2px 10px rgba(13,31,20,0.05)" }}>
        {/* Top color strip based on category */}
        <div className="h-1" style={{ background: col ? `${col.text}40` : "#0d1f1430" }} />
        <div className="p-5 flex flex-col flex-1">
          {/* Category */}
          {post.category && col && (
            <span className="inline-block px-2.5 py-1 rounded-full text-xs font-sans font-semibold mb-3 w-fit" style={{ background: col.bg, color: col.text, border: `1px solid ${col.border}` }}>
              {categoryLabel(post.category)}
            </span>
          )}
          <h2 className="text-base font-semibold leading-snug mb-2 group-hover:opacity-75 transition-opacity line-clamp-2" style={{ color: "#0d1f14" }}>
            {post.title}
          </h2>
          <p className="font-sans text-xs leading-relaxed line-clamp-3 flex-1" style={{ color: "rgba(13,31,20,0.50)" }}>
            {post.excerpt}
          </p>
          <div className="flex items-center justify-between mt-4 pt-3" style={{ borderTop: "1px solid rgba(13,31,20,0.07)" }}>
            <span className="font-sans text-xs" style={{ color: "rgba(13,31,20,0.38)" }}>{post.authorName ?? "ZUBYR Editorial"}</span>
            <div className="flex items-center gap-1 font-sans text-xs" style={{ color: "rgba(13,31,20,0.38)" }}>
              <Clock className="w-3 h-3" />
              {post.readTime} min
            </div>
          </div>
        </div>
      </article>
    </Link>
  );
}

function FeaturedPost({ post }: { post: any }) {
  const col = post.category ? CATEGORY_COLORS[post.category] : null;
  return (
    <Link href={`/blog/${post.slug}`}>
      <article className="group rounded-2xl overflow-hidden cursor-pointer transition-all hover:shadow-xl active:scale-[0.98]" style={{ background: "linear-gradient(135deg, #0d1f14 0%, #1a3520 100%)", border: "1px solid rgba(212,175,55,0.20)" }}>
        <div className="p-6">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-sans font-bold tracking-[0.18em] uppercase" style={{ color: "#d4af37" }}>Featured</span>
            <span className="w-1 h-1 rounded-full" style={{ background: "rgba(212,175,55,0.40)" }} />
            {post.category && col && (
              <span className="inline-block px-2 py-0.5 rounded-full text-xs font-sans font-semibold" style={{ background: "rgba(212,175,55,0.15)", color: "#d4af37", border: "1px solid rgba(212,175,55,0.25)" }}>
                {categoryLabel(post.category)}
              </span>
            )}
          </div>
          <h2 className="text-2xl leading-snug mb-3 group-hover:text-amber-200 transition-colors" style={{ color: "#fff" }}>
            {post.title}
          </h2>
          <p className="font-sans text-sm leading-relaxed line-clamp-2 mb-4" style={{ color: "rgba(255,255,255,0.55)" }}>
            {post.excerpt}
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 font-sans text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>
              <span>{post.authorName ?? "ZUBYR Editorial"}</span>
              <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{post.readTime} min</span>
            </div>
            <span className="font-sans text-xs font-bold" style={{ color: "#d4af37" }}>Read →</span>
          </div>
        </div>
      </article>
    </Link>
  );
}

export default function Blog() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [search, setSearch] = useState("");

  const { data: posts = [], isLoading } = trpc.blog.list.useQuery({
    category: activeCategory === "all" ? undefined : activeCategory,
    publishedOnly: true,
  });

  const filtered = posts.filter(p =>
    !search || p.title.toLowerCase().includes(search.toLowerCase()) || (p.excerpt ?? "").toLowerCase().includes(search.toLowerCase())
  );

  const featured = filtered[0];
  const rest = filtered.slice(1);

  return (
    <div className="min-h-screen" style={{ background: "#f5f0e8" }}>
      {/* Header */}
      <div className="relative overflow-hidden" style={{ background: "#0d1f14", paddingBottom: "2rem" }}>
        <div className="absolute inset-0 opacity-25" style={{ backgroundImage: "url('/manus-storage/darkgreen_79cedb4e.jpg')", backgroundSize: "cover" }} />
        <div className="absolute inset-0" style={{ background: "rgba(13,31,20,0.80)" }} />
        <div className="relative z-10 max-w-2xl mx-auto px-5 pt-12 pb-6">
          <Link href="/">
            <button className="flex items-center gap-2 text-sm mb-6 transition-opacity hover:opacity-100 opacity-70" style={{ color: "#d4af37" }}>
              <ArrowLeft className="w-4 h-4" /> Back to ZUBYR
            </button>
          </Link>
          <div className="flex items-center gap-2 mb-3">
            <BookOpen className="w-5 h-5" style={{ color: "#d4af37" }} />
            <span className="text-xs font-sans font-bold tracking-[0.22em] uppercase" style={{ color: "#d4af37" }}>ZUBYR</span>
          </div>
          <h1 className="text-4xl mb-2" style={{ color: "#fff" }}>Blog & Academy</h1>
          <p className="font-sans text-sm mb-6" style={{ color: "rgba(255,255,255,0.48)" }}>
            Expert writing on fragrance science, ingredients, culture, and the art of perfumery.
          </p>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: "rgba(255,255,255,0.35)" }} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search articles…"
              className="w-full pl-11 pr-4 py-3 rounded-xl font-sans text-sm focus:outline-none"
              style={{ background: "rgba(255,255,255,0.10)", border: "1px solid rgba(255,255,255,0.16)", color: "#fff" }}
            />
          </div>
        </div>
      </div>

      {/* Category filter */}
      <div className="sticky top-0 z-20 border-b px-5 py-3" style={{ background: "rgba(245,240,232,0.97)", borderColor: "rgba(13,31,20,0.08)", backdropFilter: "blur(12px)" }}>
        <div className="flex gap-2 overflow-x-auto max-w-2xl mx-auto" style={{ scrollbarWidth: "none" }}>
          {CATEGORIES.map(cat => (
            <button
              key={cat.value}
              onClick={() => setActiveCategory(cat.value)}
              className="flex-shrink-0 px-3 py-1.5 rounded-full font-sans text-xs font-semibold tracking-wide transition-all duration-200"
              style={
                activeCategory === cat.value
                  ? { background: "#0d1f14", color: "#f5f0e8", border: "1px solid #0d1f14" }
                  : { background: "transparent", color: "rgba(13,31,20,0.50)", border: "1px solid rgba(13,31,20,0.14)" }
              }
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-5 py-6">
        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-36 rounded-2xl animate-pulse" style={{ background: "rgba(13,31,20,0.08)" }} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-15" style={{ color: "#0d1f14" }} />
            <h3 className="text-xl mb-2" style={{ color: "#0d1f14" }}>No articles found</h3>
            <p className="font-sans text-sm" style={{ color: "rgba(13,31,20,0.45)" }}>
              {search ? "Try different search terms." : "No published articles in this category yet."}
            </p>
          </div>
        ) : (
          <>
            {featured && !search && activeCategory === "all" && (
              <div className="mb-5">
                <FeaturedPost post={featured} />
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {(search || activeCategory !== "all" ? filtered : rest).map(post => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          </>
        )}
      </div>

      <div className="py-8 text-center font-sans text-xs" style={{ color: "rgba(13,31,20,0.25)" }}>
        © {new Date().getFullYear()} ZUBYR — Singapore's Fragrance Ecosystem
      </div>
    </div>
  );
}
