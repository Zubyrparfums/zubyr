import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Calendar, BookOpen, Globe, Mail, Clock, ChevronRight } from "lucide-react";

const PINE="#2d4a3e",FOREST="#1a3028",SPICE="#8B3A1A",AMBER="#C8912E",CREAM="#F2EDE4",LINEN="#E8E0D4",STONE="#9A8A78";

function fmt(d:Date|string){
  return new Date(d).toLocaleDateString("en-SG",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
}

function IssueCard({issue,onClick}:{issue:any,onClick:()=>void}){
  const isMon=issue.editionType==="monday";
  return(
    <button onClick={onClick} className="w-full text-left rounded-2xl overflow-hidden active:scale-[0.98] transition-all" style={{background:"#fff",border:`1px solid rgba(45,74,62,0.10)`,boxShadow:"0 2px 12px rgba(26,48,40,0.06)"}}>
      {/* Top strip — pine for monday, spice for friday */}
      <div className="px-5 py-2 flex items-center gap-2" style={{background:isMon?PINE:SPICE}}>
        <Clock size={11} style={{color:"rgba(255,255,255,0.70)"}}/>
        <span className="font-sans font-bold text-[10px] tracking-[0.20em] uppercase text-white opacity-90">
          {isMon?"Monday Edition — While You Were Away":"Friday Edition — While You Were Busy"}
        </span>
      </div>
      <div className="p-5">
        <h3 className="font-semibold text-base leading-snug mb-2" style={{color:FOREST}}>{issue.title}</h3>
        <div className="flex items-center gap-1.5 font-sans text-xs mb-3" style={{color:STONE}}>
          <Calendar size={11}/><span>{fmt(issue.publishedAt)}</span>
        </div>
        <div className="space-y-2 mb-4">
          <div className="flex items-start gap-2">
            <BookOpen size={12} className="mt-0.5 flex-shrink-0" style={{color:PINE}}/>
            <p className="font-sans text-xs line-clamp-2" style={{color:STONE}}>{issue.insideZubyrContent?.split("\n\n")[0]??"Inside ZUBYR this week…"}</p>
          </div>
          <div className="flex items-start gap-2">
            <Globe size={12} className="mt-0.5 flex-shrink-0" style={{color:SPICE}}/>
            <p className="font-sans text-xs line-clamp-2" style={{color:STONE}}>{issue.worldFragranceContent?.split("\n\n")[0]??"Around the world of fragrance…"}</p>
          </div>
        </div>
        <div className="flex items-center gap-1 font-sans text-xs font-bold" style={{color:PINE}}>
          Read this issue <ChevronRight size={12}/>
        </div>
      </div>
    </button>
  );
}

function IssueDetail({issue,onBack}:{issue:any,onBack:()=>void}){
  const isMon=issue.editionType==="monday";
  const images:string[]=(()=>{try{return JSON.parse(issue.imageUrls??"[]")}catch{return[]}})();
  const accentColor=isMon?PINE:SPICE;

  return(
    <div className="min-h-screen" style={{background:CREAM}}>
      {/* Hero */}
      <div className="px-5 pt-12 pb-8" style={{background:accentColor}}>
        <button onClick={onBack} className="flex items-center gap-2 font-sans text-sm mb-6 opacity-75 hover:opacity-100" style={{color:"rgba(255,255,255,0.90)"}}>
          <ArrowLeft size={16}/>Back to all issues
        </button>
        <div className="font-sans font-bold text-[10px] tracking-[0.22em] uppercase mb-3" style={{color:"rgba(255,255,255,0.60)"}}>
          {isMon?"Monday Edition":"Friday Edition"}
        </div>
        <h1 className="text-3xl text-white leading-tight mb-3">{issue.title}</h1>
        <div className="flex items-center gap-2 font-sans text-xs" style={{color:"rgba(255,255,255,0.55)"}}>
          <Calendar size={11}/><span>{fmt(issue.publishedAt)}</span>
        </div>
      </div>

      <div className="px-5 py-8 max-w-2xl mx-auto">
        {/* Inside ZUBYR */}
        <div className="mb-10">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-0.5 h-5 rounded-full" style={{background:PINE}}/>
            <h2 className="text-lg" style={{color:FOREST}}>Inside ZUBYR</h2>
          </div>
          {(issue.insideZubyrContent??"").split("\n\n").map((p:string,i:number)=>(
            <p key={i} className="font-sans text-sm leading-relaxed mb-3" style={{color:"rgba(26,48,40,0.72)"}}>{p}</p>
          ))}
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3 my-7">
          <div className="flex-1 h-px" style={{background:LINEN}}/>
          <span className="font-sans text-[10px] tracking-[0.20em] uppercase" style={{color:STONE}}>Around the World</span>
          <div className="flex-1 h-px" style={{background:LINEN}}/>
        </div>

        {/* World of Fragrance */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-0.5 h-5 rounded-full" style={{background:SPICE}}/>
            <h2 className="text-lg" style={{color:FOREST}}>Around the World of Fragrance</h2>
          </div>
          {(issue.worldFragranceContent??"").split("\n\n").map((p:string,i:number)=>(
            <p key={i} className="font-sans text-sm leading-relaxed mb-3" style={{color:"rgba(26,48,40,0.72)"}}>{p}</p>
          ))}
        </div>

        {/* Images */}
        {images.length>0&&(
          <div className={`grid gap-3 mb-8 ${images.length===1?"grid-cols-1":images.length===2?"grid-cols-2":"grid-cols-2"}`}>
            {images.map((url,i)=>(
              <img key={i} src={url} alt="" className={`w-full rounded-xl object-cover ${images.length===3&&i===0?"col-span-2 h-44":"h-32"}`} loading="lazy"/>
            ))}
          </div>
        )}

        {/* Subscribe CTA */}
        <div className="rounded-2xl p-5 text-center" style={{background:accentColor}}>
          <p className="text-lg text-white mb-1">Enjoyed this issue?</p>
          <p className="font-sans text-xs mb-4" style={{color:"rgba(255,255,255,0.55)"}}>Subscribe to get ZUBYR every Monday and Friday.</p>
          <button onClick={onBack} className="font-sans font-bold text-sm underline underline-offset-2" style={{color:"rgba(255,255,255,0.80)"}}>Subscribe below</button>
        </div>
      </div>
    </div>
  );
}

function SignupForm(){
  const [name,setName]=useState(""),[email,setEmail]=useState(""),[done,setDone]=useState(false);
  const sub=trpc.newsletter.subscribe.useMutation({
    onSuccess:()=>setDone(true),
    onError:(e)=>toast.error(e.message||"Something went wrong."),
  });
  if(done) return(
    <div className="rounded-2xl p-7 text-center" style={{background:FOREST}}>
      <div className="text-2xl mb-2">✦</div>
      <h3 className="text-xl text-white mb-1">You're in.</h3>
      <p className="font-sans text-xs" style={{color:"rgba(255,255,255,0.45)"}}>Expect your first issue on the next Monday or Friday.</p>
    </div>
  );
  return(
    <div className="rounded-2xl overflow-hidden" style={{background:FOREST}}>
      <div className="px-5 pt-5 pb-5">
        <div className="flex items-center gap-2 mb-1">
          <Mail size={14} style={{color:AMBER}}/>
          <span className="font-sans font-bold text-[10px] tracking-[0.22em] uppercase" style={{color:AMBER}}>Subscribe</span>
        </div>
        <h3 className="text-xl text-white mb-1">Get the ZUBYR Letter</h3>
        <p className="font-sans text-xs mb-5" style={{color:"rgba(255,255,255,0.45)"}}>Every Monday and Friday — inside ZUBYR and around the world of fragrance.</p>
        <div className="space-y-2.5">
          <input type="text" value={name} onChange={e=>setName(e.target.value)} placeholder="Your name"
            className="w-full rounded-xl px-4 py-3 font-sans text-sm focus:outline-none"
            style={{background:"rgba(255,255,255,0.09)",border:"1px solid rgba(255,255,255,0.16)",color:"#fff"}}/>
          <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email address *"
            className="w-full rounded-xl px-4 py-3 font-sans text-sm focus:outline-none"
            style={{background:"rgba(255,255,255,0.09)",border:"1px solid rgba(255,255,255,0.16)",color:"#fff"}}/>
          <button onClick={()=>{if(!email){toast.error("Enter your email.");return;}sub.mutate({email,name:name||undefined});}}
            disabled={sub.isPending}
            className="w-full rounded-xl py-3 font-sans font-bold text-sm active:scale-[0.97] disabled:opacity-50"
            style={{background:SPICE,color:"#fff"}}>
            {sub.isPending?"Subscribing…":"Subscribe — It's Free"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Newsletter(){
  const [slug,setSlug]=useState<string|null>(null);
  const {data:issues=[],isLoading}=trpc.newsletterIssues.list.useQuery();
  const {data:selected}=trpc.newsletterIssues.bySlug.useQuery({slug:slug!},{enabled:!!slug});

  if(slug&&selected) return <IssueDetail issue={selected} onBack={()=>setSlug(null)}/>;
  if(slug&&!selected) return <div className="min-h-screen flex items-center justify-center" style={{background:CREAM}}><div className="w-6 h-6 border-2 rounded-full animate-spin" style={{borderColor:PINE,borderTopColor:"transparent"}}/></div>;

  return(
    <div className="min-h-screen" style={{background:CREAM}}>
      {/* Header */}
      <div className="px-5 pt-12 pb-10" style={{background:FOREST}}>
        <Link href="/">
          <button className="flex items-center gap-2 font-sans text-sm mb-6 opacity-70 hover:opacity-100" style={{color:AMBER}}>
            <ArrowLeft size={16}/>Back to ZUBYR
          </button>
        </Link>
        <div className="font-sans font-bold text-[10px] tracking-[0.24em] uppercase mb-3" style={{color:AMBER}}>The ZUBYR Letter</div>
        <h1 className="text-4xl text-white leading-tight mb-3">Weekly Newsletter<br/>by ZUBYR</h1>
        <p className="font-sans text-sm max-w-sm" style={{color:"rgba(255,255,255,0.50)"}}>
          Every Monday and Friday — what happened inside ZUBYR and around the world of fragrance while you were away.
        </p>
        {/* Edition keys */}
        <div className="flex gap-3 mt-6">
          <div className="flex items-center gap-1.5 rounded-full px-3 py-1.5" style={{background:"rgba(255,255,255,0.08)"}}>
            <div className="w-2 h-2 rounded-full" style={{background:PINE}}/>
            <span className="font-sans text-xs" style={{color:"rgba(255,255,255,0.60)"}}>Monday — Weekend Recap</span>
          </div>
          <div className="flex items-center gap-1.5 rounded-full px-3 py-1.5" style={{background:"rgba(255,255,255,0.08)"}}>
            <div className="w-2 h-2 rounded-full" style={{background:SPICE}}/>
            <span className="font-sans text-xs" style={{color:"rgba(255,255,255,0.60)"}}>Friday — Weekday Recap</span>
          </div>
        </div>
      </div>

      {/* Issues */}
      <div className="px-5 py-7">
        <p className="font-sans font-bold text-[10px] tracking-[0.22em] uppercase mb-4" style={{color:STONE}}>Past Issues</p>
        {isLoading?(
          <div className="space-y-4">{[1,2].map(i=><div key={i} className="h-44 rounded-2xl animate-pulse" style={{background:LINEN}}/>)}</div>
        ):issues.length===0?(
          <div className="text-center py-12">
            <BookOpen size={28} className="mx-auto mb-3 opacity-30" style={{color:PINE}}/>
            <p className="font-sans text-sm" style={{color:STONE}}>No issues published yet. Check back soon.</p>
          </div>
        ):(
          <div className="space-y-4">
            {issues.map((issue:any)=><IssueCard key={issue.id} issue={issue} onClick={()=>setSlug(issue.slug)}/>)}
          </div>
        )}
        <div className="mt-8"><SignupForm/></div>
        <p className="font-sans text-xs text-center mt-4" style={{color:STONE}}>Published every Monday and Friday. Unsubscribe any time.</p>
      </div>
    </div>
  );
}
