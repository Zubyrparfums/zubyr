import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Send, CheckCircle } from "lucide-react";

const PINE="#2d4a3e",FOREST="#1a3028",SPICE="#8B3A1A",AMBER="#C8912E",CREAM="#F2EDE4",STONE="#9A8A78";

const REASONS=[
  {value:"general",label:"General Enquiry"},
  {value:"workshop",label:"Workshop Enquiry"},
  {value:"school",label:"Perfumery School"},
  {value:"wholesale",label:"Wholesale"},
  {value:"collaboration",label:"Collaboration"},
  {value:"careers",label:"Careers"},
];

const Label=({children,req=false}:{children:React.ReactNode,req?:boolean})=>(
  <label className="block font-sans font-semibold text-xs uppercase tracking-wider mb-1.5" style={{color:"rgba(26,48,40,0.48)"}}>
    {children}{req&&<span style={{color:SPICE}}> *</span>}
  </label>
);

const Input=(props: React.InputHTMLAttributes<HTMLInputElement>)=>(
  <input {...props} className="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none"
    style={{background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST,...props.style}}/>
);

export default function Contact(){
  const [form,setForm]=useState({name:"",phone:"",email:"",type:"general",message:""});
  const [done,setDone]=useState(false);
  const mut=trpc.contact.submit.useMutation({
    onSuccess:()=>setDone(true),
    onError:()=>toast.error("Something went wrong. Please try again."),
  });
  const go=(e:React.FormEvent)=>{
    e.preventDefault();
    if(!form.name.trim())return toast.error("Please enter your name.");
    if(!form.email.trim())return toast.error("Please enter your email.");
    mut.mutate({name:form.name,phone:form.phone,email:form.email,type:form.type as any,message:form.message});
  };

  return(
    <div className="min-h-screen font-serif" style={{background:CREAM}}>
      {/* Header */}
      <header className="sticky top-0 z-40 px-5 py-4 flex items-center gap-3" style={{background:FOREST}}>
        <a href="/" style={{color:"rgba(255,255,255,0.50)"}}>
          <ArrowLeft className="w-5 h-5"/>
        </a>
        <div>
          <p className="font-bold tracking-widest uppercase text-xs text-white">Contact</p>
          <p className="font-sans text-[10px] tracking-widest uppercase" style={{color:"rgba(255,255,255,0.35)"}}>ZUBYR</p>
        </div>
      </header>

      <div className="max-w-md mx-auto px-5 py-8">
        {done?(
          <div className="flex flex-col items-center justify-center py-20 text-center gap-5">
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{background:`rgba(45,74,62,0.10)`}}>
              <CheckCircle className="w-8 h-8" style={{color:PINE}}/>
            </div>
            <div>
              <h2 className="text-2xl font-bold" style={{color:FOREST}}>Message Received</h2>
              <p className="font-sans text-sm mt-2 leading-relaxed" style={{color:STONE}}>
                We'll get back to you within 1–2 business days.
              </p>
            </div>
            <a href="/" className="px-6 py-3 rounded-xl font-sans font-bold text-sm" style={{background:PINE,color:"#fff"}}>
              Back to Home
            </a>
          </div>
        ):(
          <>
            <div className="mb-8">
              <p className="font-sans font-bold text-xs tracking-[0.22em] uppercase mb-3" style={{color:SPICE}}>Get in Touch</p>
              <h1 className="text-3xl leading-tight mb-2" style={{color:FOREST}}>We'd love to<br/>hear from you.</h1>
              <p className="font-sans text-sm leading-relaxed" style={{color:STONE}}>
                Fill in the form below and we'll respond as soon as possible.
              </p>
            </div>

            <form onSubmit={go} className="flex flex-col gap-4">
              <div><Label req>Full Name</Label><Input type="text" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="Your full name"/></div>
              <div><Label>Phone</Label><Input type="tel" value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} placeholder="+65 XXXX XXXX"/></div>
              <div><Label req>Email</Label><Input type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} placeholder="you@example.com"/></div>
              <div>
                <Label req>Reason</Label>
                <select value={form.type} onChange={e=>setForm(f=>({...f,type:e.target.value}))}
                  className="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none appearance-none"
                  style={{background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST}}>
                  {REASONS.map(r=><option key={r.value} value={r.value}>{r.label}</option>)}
                </select>
              </div>
              <div>
                <Label>Message</Label>
                <textarea rows={5} value={form.message} onChange={e=>setForm(f=>({...f,message:e.target.value}))}
                  placeholder="Tell us more about your enquiry…"
                  className="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none resize-none"
                  style={{background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST}}/>
              </div>
              <button type="submit" disabled={mut.isPending}
                className="w-full flex items-center justify-center gap-2 py-4 rounded-xl font-sans font-bold text-sm tracking-wider active:scale-[0.98] disabled:opacity-60"
                style={{background:SPICE,color:"#fff"}}>
                <Send className="w-4 h-4"/>
                {mut.isPending?"Sending…":"Send Message"}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
