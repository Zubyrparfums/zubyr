import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, ArrowLeft, ExternalLink } from "lucide-react";

const KLOOK_DEFAULT = "https://s.klook.com/c/mwkG00KkyQ";

type WorkshopForm = {
  title: string;
  description: string;
  imageUrl: string;
  klookUrl: string;
  whatsappNumber: string;
  price: string;
  duration: string;
  type: "group" | "private" | "corporate" | "school";
  active: boolean;
};

const emptyForm: WorkshopForm = {
  title: "",
  description: "",
  imageUrl: "",
  klookUrl: KLOOK_DEFAULT,
  whatsappNumber: "",
  price: "",
  duration: "",
  type: "group",
  active: true,
};

export default function AdminWorkshops() {
  const { user } = useAuth();
  const [form, setForm] = useState<WorkshopForm>(emptyForm);
  const [editId, setEditId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const utils = trpc.useUtils();

  const workshopsQ = trpc.workshops.list.useQuery();
  const createMutation = trpc.workshops.create.useMutation({
    onSuccess: () => { utils.workshops.list.invalidate(); setShowForm(false); setForm(emptyForm); toast.success("Workshop created"); },
    onError: () => toast.error("Failed to create workshop"),
  });
  const updateMutation = trpc.workshops.update.useMutation({
    onSuccess: () => { utils.workshops.list.invalidate(); setShowForm(false); setEditId(null); setForm(emptyForm); toast.success("Workshop updated"); },
    onError: () => toast.error("Failed to update workshop"),
  });
  const deleteMutation = trpc.workshops.delete.useMutation({
    onSuccess: () => { utils.workshops.list.invalidate(); toast.success("Workshop deleted"); },
    onError: () => toast.error("Failed to delete workshop"),
  });

  if (!user || user.role !== "admin") return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editId !== null) {
      updateMutation.mutate({ id: editId, ...form });
    } else {
      createMutation.mutate(form);
    }
  };

  const handleEdit = (w: any) => {
    setForm({
      title: w.title || "",
      description: w.description || "",
      imageUrl: w.imageUrl || "",
      klookUrl: w.klookUrl || KLOOK_DEFAULT,
      whatsappNumber: w.whatsappNumber || "",
      price: w.price?.toString() || "",
      duration: w.duration || "",
      type: w.type || "group",
      active: w.active ?? true,
    });
    setEditId(w.id);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const typeLabels: Record<string, string> = {
    group: "Group (Klook)",
    private: "Private (WhatsApp)",
    corporate: "Corporate (WhatsApp)",
    school: "School",
  };

  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-pine px-5 py-4 flex items-center gap-3 sticky top-0 z-40 shadow-lg">
        <a href="/admin" className="text-white/60 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </a>
        <div>
          <h1 className="text-white font-bold tracking-widest uppercase text-sm">Workshops</h1>
          <p className="text-white/40 text-xs">ZUBYR Admin</p>
        </div>
        <button
          onClick={() => { setForm(emptyForm); setEditId(null); setShowForm(true); }}
          className="ml-auto flex items-center gap-1.5 bg-zubyr-gold text-pine px-3 py-2 rounded-xl text-xs font-bold tracking-wider hover:bg-spice transition-colors"
        >
          <Plus className="w-4 h-4" /> Add Workshop
        </button>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {showForm && (
          <div className="bg-white rounded-2xl border border-pine/20 shadow-md p-6 mb-6">
            <h2 className="font-bold text-pine text-lg mb-4">{editId !== null ? "Edit Workshop" : "New Workshop"}</h2>
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div>
                <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Title *</label>
                <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
              </div>
              <div>
                <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Description</label>
                <textarea rows={3} className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50 resize-none" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Type</label>
                  <select className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value as any }))}>
                    <option value="group">Group (Klook)</option>
                    <option value="private">Private (WhatsApp)</option>
                    <option value="corporate">Corporate (WhatsApp)</option>
                    <option value="school">School</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Price (SGD)</label>
                  <input type="number" step="0.01" className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
                </div>
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Duration</label>
                  <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.duration} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))} placeholder="e.g. 2.5 hours" />
                </div>
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">WhatsApp Number</label>
                  <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.whatsappNumber} onChange={e => setForm(f => ({ ...f, whatsappNumber: e.target.value }))} placeholder="6581877202" />
                </div>
              </div>
              <div>
                <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Klook Booking URL</label>
                <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.klookUrl} onChange={e => setForm(f => ({ ...f, klookUrl: e.target.value }))} />
              </div>
              <div>
                <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Image URL</label>
                <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.imageUrl} onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))} placeholder="https://..." />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="active-w" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} className="w-4 h-4 accent-zubyr-green" />
                <label htmlFor="active-w" className="text-sm text-pine">Active (visible on site)</label>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={createMutation.isPending || updateMutation.isPending} className="flex-1 py-3 bg-pine text-white rounded-xl text-sm font-bold tracking-wider hover:bg-zubyr-dark transition-colors disabled:opacity-60">
                  {editId !== null ? "Update Workshop" : "Create Workshop"}
                </button>
                <button type="button" onClick={() => { setShowForm(false); setEditId(null); setForm(emptyForm); }} className="px-4 py-3 border border-pine/20 text-pine rounded-xl text-sm hover:bg-pine/5 transition-colors">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="flex flex-col gap-3">
          {workshopsQ.isLoading && <p className="text-center text-pine/40 text-sm py-8">Loading…</p>}
          {workshopsQ.data?.length === 0 && !showForm && (
            <div className="bg-white rounded-2xl p-8 text-center border border-pine/10">
              <p className="text-pine/40 text-sm">No workshops yet. Add your first workshop.</p>
            </div>
          )}
          {workshopsQ.data?.map((w: any) => (
            <div key={w.id} className="bg-white rounded-2xl border border-pine/10 shadow-sm p-4 flex items-start gap-4">
              <div className="w-14 h-14 rounded-xl bg-cream flex items-center justify-center flex-shrink-0 overflow-hidden">
                {w.imageUrl ? <img src={w.imageUrl} alt={w.title} className="w-full h-full object-cover" /> : <span className="text-2xl">🧪</span>}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-pine text-sm">{w.title}</p>
                  <span className="text-xs bg-spice/10 text-spice px-2 py-0.5 rounded-full">{typeLabels[w.type] || w.type}</span>
                  {!w.active && <span className="text-xs bg-red-50 text-red-500 px-2 py-0.5 rounded-full">Inactive</span>}
                </div>
                {w.price && <p className="text-xs text-spice font-semibold mt-0.5">SGD {Number(w.price).toFixed(2)}</p>}
                {w.duration && <p className="text-xs text-pine/50 mt-0.5">{w.duration}</p>}
                {w.klookUrl && (
                  <a href={w.klookUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-spice hover:underline mt-1">
                    <ExternalLink className="w-3 h-3" /> Klook Link
                  </a>
                )}
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => handleEdit(w)} className="p-2 rounded-xl hover:bg-cream transition-colors text-pine/40 hover:text-pine">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => { if (confirm("Delete this workshop?")) deleteMutation.mutate({ id: w.id }); }} className="p-2 rounded-xl hover:bg-red-50 transition-colors text-pine/40 hover:text-red-500">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
