import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, ArrowLeft, Eye, EyeOff } from "lucide-react";

type ProductForm = {
  name: string;
  collection: "premium" | "signature" | "niche" | "oud" | "collabs";
  description: string;
  scentStory: string;
  topNotes: string;
  middleNotes: string;
  baseNotes: string;
  fragranceFamily: string;
  price: string;
  imageUrl: string;
  active: boolean;
};

const emptyForm: ProductForm = {
  name: "",
  collection: "signature",
  description: "",
  scentStory: "",
  topNotes: "",
  middleNotes: "",
  baseNotes: "",
  fragranceFamily: "",
  price: "",
  imageUrl: "",
  active: true,
};

export default function AdminProducts() {
  const { user } = useAuth();
  const [form, setForm] = useState<ProductForm>(emptyForm);
  const [editId, setEditId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const utils = trpc.useUtils();

  const productsQ = trpc.products.list.useQuery();
  const createMutation = trpc.products.create.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); setShowForm(false); setForm(emptyForm); toast.success("Product created"); },
    onError: () => toast.error("Failed to create product"),
  });
  const updateMutation = trpc.products.update.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); setShowForm(false); setEditId(null); setForm(emptyForm); toast.success("Product updated"); },
    onError: () => toast.error("Failed to update product"),
  });
  const deleteMutation = trpc.products.delete.useMutation({
    onSuccess: () => { utils.products.list.invalidate(); toast.success("Product deleted"); },
    onError: () => toast.error("Failed to delete product"),
  });

  if (!user || user.role !== "admin") return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editId !== null) {
      updateMutation.mutate({ id: editId, ...form });
    } else {
      createMutation.mutate(form);
    }
  };

  const handleEdit = (p: any) => {
    setForm({
      name: p.name || "",
      collection: p.collection || "signature",
      description: p.description || "",
      scentStory: p.scentStory || "",
      topNotes: p.topNotes || "",
      middleNotes: p.middleNotes || "",
      baseNotes: p.baseNotes || "",
      fragranceFamily: p.fragranceFamily || "",
      price: p.price?.toString() || "",
      imageUrl: p.imageUrl || "",
      active: p.active ?? true,
    });
    setEditId(p.id);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-pine px-5 py-4 flex items-center gap-3 sticky top-0 z-40 shadow-lg">
        <a href="/admin" className="text-white/60 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </a>
        <div>
          <h1 className="text-white font-bold tracking-widest uppercase text-sm">Products</h1>
          <p className="text-white/40 text-xs">ZUBYR Admin</p>
        </div>
        <button
          onClick={() => { setForm(emptyForm); setEditId(null); setShowForm(true); }}
          className="ml-auto flex items-center gap-1.5 bg-zubyr-gold text-pine px-3 py-2 rounded-xl text-xs font-bold tracking-wider hover:bg-spice transition-colors"
        >
          <Plus className="w-4 h-4" /> Add Product
        </button>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Form */}
        {showForm && (
          <div className="bg-white rounded-2xl border border-pine/20 shadow-md p-6 mb-6">
            <h2 className="font-bold text-pine text-lg mb-4">
              {editId !== null ? "Edit Product" : "New Product"}
            </h2>
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Name *</label>
                  <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
                </div>
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Collection</label>
                  <select className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.collection} onChange={e => setForm(f => ({ ...f, collection: e.target.value as any }))}>
                    <option value="premium">Premium</option>
                    <option value="signature">Signature</option>
                    <option value="niche">Niche</option>
                    <option value="oud">Oud</option>
                    <option value="collabs">Collabs</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Price (SGD)</label>
                  <input type="number" step="0.01" className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
                </div>
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Fragrance Family</label>
                  <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.fragranceFamily} onChange={e => setForm(f => ({ ...f, fragranceFamily: e.target.value }))} placeholder="e.g. Oriental Woody" />
                </div>
              </div>
              <div>
                <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Description</label>
                <textarea rows={3} className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50 resize-none" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
              <div>
                <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Scent Story</label>
                <textarea rows={3} className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50 resize-none" value={form.scentStory} onChange={e => setForm(f => ({ ...f, scentStory: e.target.value }))} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Top Notes</label>
                  <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.topNotes} onChange={e => setForm(f => ({ ...f, topNotes: e.target.value }))} placeholder="Bergamot, Lemon" />
                </div>
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Middle Notes</label>
                  <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.middleNotes} onChange={e => setForm(f => ({ ...f, middleNotes: e.target.value }))} placeholder="Rose, Jasmine" />
                </div>
                <div>
                  <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Base Notes</label>
                  <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.baseNotes} onChange={e => setForm(f => ({ ...f, baseNotes: e.target.value }))} placeholder="Oud, Sandalwood" />
                </div>
              </div>
              <div>
                <label className="text-xs text-pine/60 font-semibold uppercase tracking-wider block mb-1">Image URL</label>
                <input className="w-full border border-pine/20 rounded-xl px-3 py-2.5 text-sm text-pine focus:outline-none focus:border-pine/60 bg-cream/50" value={form.imageUrl} onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))} placeholder="https://..." />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="active" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} className="w-4 h-4 accent-zubyr-green" />
                <label htmlFor="active" className="text-sm text-pine">Active (visible on site)</label>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={createMutation.isPending || updateMutation.isPending} className="flex-1 py-3 bg-pine text-white rounded-xl text-sm font-bold tracking-wider hover:bg-zubyr-dark transition-colors disabled:opacity-60">
                  {editId !== null ? "Update Product" : "Create Product"}
                </button>
                <button type="button" onClick={() => { setShowForm(false); setEditId(null); setForm(emptyForm); }} className="px-4 py-3 border border-pine/20 text-pine rounded-xl text-sm hover:bg-pine/5 transition-colors">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Products List */}
        <div className="flex flex-col gap-3">
          {productsQ.isLoading && <p className="text-center text-pine/40 text-sm py-8">Loading…</p>}
          {productsQ.data?.length === 0 && !showForm && (
            <div className="bg-white rounded-2xl p-8 text-center border border-pine/10">
              <p className="text-pine/40 text-sm">No products yet. Add your first product.</p>
            </div>
          )}
          {productsQ.data?.map((p: any) => (
            <div key={p.id} className="bg-white rounded-2xl border border-pine/10 shadow-sm p-4 flex items-start gap-4">
              <div className="w-14 h-14 rounded-xl bg-cream flex items-center justify-center flex-shrink-0 overflow-hidden">
                {p.imageUrl ? (
                  <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-2xl">🌸</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-pine text-sm">{p.name}</p>
                  <span className="text-xs bg-pine/10 text-pine px-2 py-0.5 rounded-full capitalize">{p.collection}</span>
                  {!p.active && <span className="text-xs bg-red-50 text-red-500 px-2 py-0.5 rounded-full">Inactive</span>}
                </div>
                {p.price && <p className="text-xs text-spice font-semibold mt-0.5">SGD {Number(p.price).toFixed(2)}</p>}
                {p.fragranceFamily && <p className="text-xs text-pine/50 mt-0.5">{p.fragranceFamily}</p>}
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => updateMutation.mutate({ id: p.id, active: !p.active })} className="p-2 rounded-xl hover:bg-cream transition-colors text-pine/40 hover:text-pine" title={p.active ? "Deactivate" : "Activate"}>
                  {p.active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
                <button onClick={() => handleEdit(p)} className="p-2 rounded-xl hover:bg-cream transition-colors text-pine/40 hover:text-pine">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => { if (confirm("Delete this product?")) deleteMutation.mutate({ id: p.id }); }} className="p-2 rounded-xl hover:bg-red-50 transition-colors text-pine/40 hover:text-red-500">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
