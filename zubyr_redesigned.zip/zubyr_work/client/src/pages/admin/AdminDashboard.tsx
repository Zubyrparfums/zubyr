import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { ShoppingBag, CalendarDays, Newspaper, Users, Mail, MessageSquare, LogOut, LayoutDashboard, ChevronRight, Briefcase, Handshake, ShoppingCart, Lightbulb } from "lucide-react";

const PINE="#2d4a3e",FOREST="#1a3028",SPICE="#8B3A1A",AMBER="#C8912E",CREAM="#F2EDE4",LINEN="#E8E0D4",STONE="#9A8A78";

const navItems=[
  {label:"Products",       icon:ShoppingBag,   href:"/admin/products"},
  {label:"Workshops",      icon:CalendarDays,  href:"/admin/workshops"},
  {label:"Blog Posts",     icon:Newspaper,     href:"/admin/blog"},
  {label:"Community",      icon:Users,         href:"/admin/community"},
  {label:"Newsletter",     icon:Mail,          href:"/admin/newsletter"},
  {label:"All Enquiries",  icon:MessageSquare, href:"/admin/enquiries"},
];

export default function AdminDashboard(){
  const {user,loading}=useAuth();
  const [,nav]=useLocation();
  const logout=trpc.auth.logout.useMutation({onSuccess:()=>nav("/")});

  const pQ=trpc.products.list.useQuery();
  const wQ=trpc.workshops.list.useQuery();
  const bQ=trpc.blog.list.useQuery();
  const cQ=trpc.community.list.useQuery({status:"pending"});
  const nQ=trpc.newsletter.list.useQuery();
  const eQ=trpc.contact.list.useQuery();
  const whQ=trpc.wholesale.list.useQuery();
  const coQ=trpc.collabs.list.useQuery();
  const iQ=trpc.ideas.list.useQuery();
  const apQ=trpc.jobs.applications.useQuery();

  if(loading) return(
    <div className="min-h-screen flex items-center justify-center" style={{background:CREAM}}>
      <p className="font-sans text-xs tracking-widest uppercase animate-pulse" style={{color:STONE}}>Loading…</p>
    </div>
  );

  if(!user||user.role!=="admin") return(
    <div className="min-h-screen flex flex-col items-center justify-center gap-5 px-5" style={{background:CREAM}}>
      <div className="text-center">
        <div className="w-20 h-20 rounded-full bg-white shadow-lg flex items-center justify-center overflow-hidden mx-auto mb-4" style={{border:`1px solid rgba(45,74,62,0.15)`}}>
          <img src="/manus-storage/zubyrlogo_aac59b85.jpg" alt="ZUBYR" className="w-full h-full object-contain p-2"/>
        </div>
        <h1 className="text-2xl font-bold tracking-widest uppercase mb-1" style={{color:FOREST}}>ZUBYR</h1>
        <p className="font-sans text-xs tracking-widest uppercase mb-6" style={{color:SPICE}}>Admin Portal</p>
        {!user?(
          <>
            <p className="font-sans text-sm mb-5" style={{color:STONE}}>Sign in to access the admin dashboard.</p>
            <a href={getLoginUrl()} className="inline-block px-7 py-3 rounded-xl font-sans font-bold text-sm" style={{background:PINE,color:"#fff"}}>Sign In</a>
            <div className="mt-3"><a href="/" className="font-sans text-xs" style={{color:STONE}}>← Back to site</a></div>
          </>
        ):(
          <>
            <p className="font-sans text-sm mb-5" style={{color:STONE}}>Your account does not have admin access.</p>
            <a href="/" className="inline-block px-6 py-3 rounded-xl font-sans font-bold text-sm" style={{background:PINE,color:"#fff"}}>Return to Home</a>
          </>
        )}
      </div>
    </div>
  );

  const unreadEnq=(eQ.data?.filter((e:any)=>!e.read).length??0)+(whQ.data?.filter((e:any)=>!e.read).length??0)+(coQ.data?.filter((e:any)=>!e.read).length??0)+(iQ.data?.filter((e:any)=>!e.read).length??0);

  const stats=[
    {label:"Products",       val:pQ.data?.length??"-",   href:"/admin/products",  hi:false},
    {label:"Workshops",      val:wQ.data?.length??"-",   href:"/admin/workshops", hi:false},
    {label:"Blog Posts",     val:bQ.data?.length??"-",   href:"/admin/blog",      hi:false},
    {label:"Pending Review", val:cQ.data?.length??"-",   href:"/admin/community", hi:true},
    {label:"Subscribers",    val:nQ.data?.length??"-",   href:"/admin/newsletter",hi:false},
    {label:"New Enquiries",  val:unreadEnq||"-",          href:"/admin/enquiries", hi:unreadEnq>0},
    {label:"Job Apps",       val:apQ.data?.length??"-",  href:"/admin/enquiries", hi:false},
    {label:"Ideas",          val:iQ.data?.length??"-",   href:"/admin/enquiries", hi:false},
  ];

  return(
    <div className="min-h-screen" style={{background:CREAM}}>
      {/* Header */}
      <header className="sticky top-0 z-40 px-5 py-4 flex items-center justify-between" style={{background:FOREST}}>
        <div>
          <p className="text-white font-bold tracking-[0.22em] text-sm uppercase">ZUBYR</p>
          <p className="font-sans text-[10px] tracking-widest uppercase" style={{color:"rgba(255,255,255,0.35)"}}>Admin</p>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-sans text-xs hidden sm:block" style={{color:"rgba(255,255,255,0.55)"}}>{user.name}</span>
          <button onClick={()=>logout.mutate()} className="flex items-center gap-1.5 font-sans text-xs" style={{color:"rgba(255,255,255,0.50)"}}>
            <LogOut className="w-4 h-4"/>Logout
          </button>
        </div>
      </header>

      <div className="max-w-md mx-auto px-5 py-6">
        {/* Welcome */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-1">
            <LayoutDashboard className="w-3.5 h-3.5" style={{color:AMBER}}/>
            <p className="font-sans font-bold text-[10px] tracking-[0.22em] uppercase" style={{color:AMBER}}>Dashboard</p>
          </div>
          <h2 className="text-2xl font-bold" style={{color:FOREST}}>Welcome back, {user.name?.split(" ")[0]??"Admin"}</h2>
          <p className="font-sans text-xs mt-1" style={{color:STONE}}>Manage your ZUBYR platform from here.</p>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-2.5 mb-7">
          {stats.map(s=>(
            <a key={s.label} href={s.href}
              className="rounded-2xl p-4 active:scale-[0.97]"
              style={{background:"#fff",border:`1px solid ${s.hi?"rgba(139,58,26,0.25)":"rgba(45,74,62,0.09)"}`,boxShadow:"0 1px 6px rgba(26,48,40,0.05)"}}>
              <p className="font-sans font-bold text-2xl" style={{color:s.hi?SPICE:PINE}}>{s.val}</p>
              <p className="font-sans text-[10px] uppercase tracking-wide mt-1" style={{color:STONE}}>{s.label}</p>
            </a>
          ))}
        </div>

        {/* Nav */}
        <p className="font-sans font-bold text-[10px] tracking-[0.22em] uppercase mb-3 px-1" style={{color:STONE}}>Manage</p>
        <div className="flex flex-col gap-2">
          {navItems.map(item=>{
            const Icon=item.icon;
            return(
              <a key={item.label} href={item.href}
                className="flex items-center gap-3.5 rounded-2xl px-5 py-4 active:scale-[0.98]"
                style={{background:"#fff",border:`1px solid rgba(45,74,62,0.09)`,boxShadow:"0 1px 5px rgba(26,48,40,0.04)"}}>
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:`rgba(45,74,62,0.07)`}}>
                  <Icon className="w-4 h-4" style={{color:PINE}}/>
                </div>
                <span className="flex-1 font-semibold text-sm" style={{color:FOREST}}>{item.label}</span>
                <ChevronRight className="w-4 h-4" style={{color:"rgba(45,74,62,0.25)"}}/>
              </a>
            );
          })}
        </div>

        <div className="mt-6 text-center">
          <a href="/" className="font-sans text-xs" style={{color:STONE}}>← Back to public site</a>
        </div>
      </div>
    </div>
  );
}
