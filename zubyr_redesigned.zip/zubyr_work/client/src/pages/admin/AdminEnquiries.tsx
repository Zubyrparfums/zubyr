import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowLeft, CheckCheck, Briefcase, ShoppingCart, Handshake, Lightbulb, MessageSquare, Users, ExternalLink } from "lucide-react";
import { toast } from "sonner";

type Tab = "contact" | "wholesale" | "collabs" | "ideas" | "applications";

const tabs: { value: Tab; label: string; icon: React.ReactNode }[] = [
  { value: "contact",      label: "Contact",      icon: <MessageSquare size={14} /> },
  { value: "wholesale",    label: "Wholesale",    icon: <ShoppingCart size={14} /> },
  { value: "collabs",      label: "Collabs",      icon: <Handshake size={14} /> },
  { value: "ideas",        label: "Ideas",        icon: <Lightbulb size={14} /> },
  { value: "applications", label: "Job Apps",     icon: <Briefcase size={14} /> },
];

const contactTypeLabels: Record<string, string> = {
  general: "General", careers: "Careers", wholesale: "Wholesale",
  collaboration: "Collaboration", school: "Perfumery School", workshop: "Workshop",
};

const jobStatusColors: Record<string, string> = {
  new: "bg-zubyr-amber/10 text-zubyr-amber",
  reviewing: "bg-blue-100 text-blue-700",
  shortlisted: "bg-emerald-100 text-emerald-700",
  rejected: "bg-red-100 text-red-600",
};

function Badge({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${className}`}>{children}</span>;
}

function EnquiryCard({ e, onMarkRead }: { e: any; onMarkRead?: () => void }) {
  return (
    <div className={`bg-white rounded-2xl border shadow-sm p-4 ${!e.read ? "border-zubyr-amber/30" : "border-zubyr-green/10"}`}>
      <div className="flex items-start justify-between gap-2 mb-2">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-semibold text-zubyr-green text-sm">{e.name}</p>
            {e.type && <Badge className="bg-zubyr-green/10 text-zubyr-green">{contactTypeLabels[e.type] || e.type}</Badge>}
            {!e.read && <Badge className="bg-zubyr-amber/10 text-zubyr-amber">New</Badge>}
          </div>
          <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-zubyr-green/40">
            {e.email && <span>✉️ {e.email}</span>}
            {e.phone && <span>📱 {e.phone}</span>}
          </div>
        </div>
        <p className="text-xs text-zubyr-green/30 flex-shrink-0">{new Date(e.createdAt).toLocaleDateString()}</p>
      </div>
      {e.message && <p className="text-sm text-zubyr-green/70 leading-relaxed border-t border-zubyr-beige pt-3 mt-2">{e.message}</p>}
      {onMarkRead && !e.read && (
        <button onClick={onMarkRead} className="mt-3 flex items-center gap-1.5 text-xs text-zubyr-green/40 hover:text-zubyr-green transition-colors">
          <CheckCheck className="w-3.5 h-3.5" /> Mark as read
        </button>
      )}
    </div>
  );
}

function WholesaleTab() {
  const q = trpc.wholesale.list.useQuery();
  const items = q.data ?? [];
  const unread = items.filter((e: any) => !e.read).length;
  return (
    <div className="flex flex-col gap-3">
      {unread > 0 && <p className="text-xs text-zubyr-amber font-semibold px-1">{unread} unread inquiry{unread !== 1 ? "ies" : "y"}</p>}
      {q.isLoading && <p className="text-center text-zubyr-green/40 text-sm py-8">Loading…</p>}
      {items.length === 0 && !q.isLoading && <EmptyState label="No wholesale inquiries yet." />}
      {items.map((e: any) => (
        <div key={e.id} className={`bg-white rounded-2xl border shadow-sm p-4 ${!e.read ? "border-zubyr-amber/30" : "border-zubyr-green/10"}`}>
          <div className="flex items-start justify-between gap-2 mb-2">
            <div>
              <p className="font-semibold text-zubyr-green text-sm">{e.name}</p>
              <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-zubyr-green/40">
                {e.email && <span>✉️ {e.email}</span>}
                {e.phone && <span>📱 {e.phone}</span>}
              </div>
            </div>
            <p className="text-xs text-zubyr-green/30 flex-shrink-0">{new Date(e.createdAt).toLocaleDateString()}</p>
          </div>
          {e.productInterest && <p className="text-xs text-zubyr-green/60 mb-2">🛍 {e.productInterest}</p>}
          {e.message && <p className="text-sm text-zubyr-green/70 leading-relaxed border-t border-zubyr-beige pt-3 mt-2">{e.message}</p>}
        </div>
      ))}
    </div>
  );
}

function CollabsTab() {
  const q = trpc.collabs.list.useQuery();
  const items = q.data ?? [];
  return (
    <div className="flex flex-col gap-3">
      {q.isLoading && <p className="text-center text-zubyr-green/40 text-sm py-8">Loading…</p>}
      {items.length === 0 && !q.isLoading && <EmptyState label="No collaboration inquiries yet." />}
      {items.map((e: any) => (
        <div key={e.id} className="bg-white rounded-2xl border border-zubyr-green/10 shadow-sm p-4">
          <div className="flex items-start justify-between gap-2 mb-2">
            <div>
              <p className="font-semibold text-zubyr-green text-sm">{e.name}</p>
              <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-zubyr-green/40">
                {e.email && <span>✉️ {e.email}</span>}
                {e.phone && <span>📱 {e.phone}</span>}
              </div>
            </div>
            <p className="text-xs text-zubyr-green/30 flex-shrink-0">{new Date(e.createdAt).toLocaleDateString()}</p>
          </div>
          <div className="flex flex-wrap gap-2 mt-2 mb-2">
            {e.instagram && <a href={`https://instagram.com/${e.instagram.replace("@","")}`} target="_blank" className="flex items-center gap-1 text-xs text-pink-600 hover:underline"><ExternalLink size={10} />@{e.instagram.replace("@","")}</a>}
            {e.tiktok && <a href={`https://tiktok.com/@${e.tiktok.replace("@","")}`} target="_blank" className="flex items-center gap-1 text-xs text-black hover:underline"><ExternalLink size={10} />TikTok</a>}
            {e.youtube && <span className="text-xs text-red-500">▶ {e.youtube}</span>}
            {e.otherSocials && <span className="text-xs text-zubyr-green/40">{e.otherSocials}</span>}
          </div>
          {e.message && <p className="text-sm text-zubyr-green/70 leading-relaxed border-t border-zubyr-beige pt-3 mt-2">{e.message}</p>}
        </div>
      ))}
    </div>
  );
}

function IdeasTab() {
  const q = trpc.ideas.list.useQuery();
  const items = q.data ?? [];
  return (
    <div className="flex flex-col gap-3">
      {q.isLoading && <p className="text-center text-zubyr-green/40 text-sm py-8">Loading…</p>}
      {items.length === 0 && !q.isLoading && <EmptyState label="No ideas submitted yet." />}
      {items.map((e: any) => (
        <div key={e.id} className="bg-white rounded-2xl border border-zubyr-green/10 shadow-sm p-4">
          <div className="flex items-start justify-between gap-2 mb-3">
            <div>
              <p className="font-semibold text-zubyr-green text-sm">{e.name || "Anonymous"}</p>
              {e.email && <p className="text-xs text-zubyr-green/40 mt-0.5">✉️ {e.email}</p>}
            </div>
            <p className="text-xs text-zubyr-green/30 flex-shrink-0">{new Date(e.createdAt).toLocaleDateString()}</p>
          </div>
          <div className="bg-zubyr-beige rounded-xl p-3">
            <p className="text-sm text-zubyr-green/80 leading-relaxed">{e.idea}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

function ApplicationsTab() {
  const q = trpc.jobs.applications.useQuery();
  const items = q.data ?? [];

  const statusUpdateMutation = trpc.jobs.update.useMutation();

  return (
    <div className="flex flex-col gap-3">
      {q.isLoading && <p className="text-center text-zubyr-green/40 text-sm py-8">Loading…</p>}
      {items.length === 0 && !q.isLoading && <EmptyState label="No job applications yet." />}
      {items.map((e: any) => (
        <div key={e.id} className="bg-white rounded-2xl border border-zubyr-green/10 shadow-sm p-4">
          <div className="flex items-start justify-between gap-2 mb-2">
            <div>
              <p className="font-semibold text-zubyr-green text-sm">{e.name}</p>
              <p className="text-xs text-zubyr-amber font-medium mt-0.5">{e.position}</p>
              <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-zubyr-green/40">
                {e.email && <span>✉️ {e.email}</span>}
                {e.phone && <span>📱 {e.phone}</span>}
              </div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <p className="text-xs text-zubyr-green/30">{new Date(e.createdAt).toLocaleDateString()}</p>
              <Badge className={jobStatusColors[e.status] || "bg-gray-100 text-gray-600"}>{e.status}</Badge>
            </div>
          </div>
          {e.coverNote && <p className="text-sm text-zubyr-green/70 leading-relaxed border-t border-zubyr-beige pt-3 mt-2 line-clamp-3">{e.coverNote}</p>}
          <div className="flex gap-2 mt-3 flex-wrap">
            {e.resumeUrl && <a href={e.resumeUrl} target="_blank" className="flex items-center gap-1 text-xs text-zubyr-green underline"><ExternalLink size={10} />Resume</a>}
            {e.videoUrl && <a href={e.videoUrl} target="_blank" className="flex items-center gap-1 text-xs text-zubyr-amber underline"><ExternalLink size={10} />Video</a>}
          </div>
        </div>
      ))}
    </div>
  );
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="bg-white rounded-2xl p-8 text-center border border-zubyr-green/10">
      <p className="text-zubyr-green/40 text-sm">{label}</p>
    </div>
  );
}

export default function AdminEnquiries() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>("contact");
  const utils = trpc.useUtils();
  const enquiriesQ = trpc.contact.list.useQuery();
  const markReadMutation = trpc.contact.markRead.useMutation({
    onSuccess: () => { utils.contact.list.invalidate(); toast.success("Marked as read"); },
  });

  if (!user || user.role !== "admin") return null;

  const unreadContactCount = enquiriesQ.data?.filter((e: any) => !e.read).length ?? 0;

  return (
    <div className="min-h-screen bg-zubyr-beige">
      <header className="bg-zubyr-green px-5 py-4 flex items-center gap-3 sticky top-0 z-40 shadow-lg">
        <a href="/admin" className="text-white/60 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </a>
        <div>
          <h1 className="text-white font-bold tracking-widest uppercase text-sm">Enquiries & Applications</h1>
          <p className="text-white/40 text-xs">ZUBYR Admin</p>
        </div>
        {unreadContactCount > 0 && (
          <span className="ml-auto bg-zubyr-amber text-zubyr-green text-xs font-bold px-2.5 py-1 rounded-full">
            {unreadContactCount} unread
          </span>
        )}
      </header>

      {/* Tab bar */}
      <div className="bg-white border-b border-zubyr-green/10 px-4 overflow-x-auto">
        <div className="flex gap-1 max-w-2xl mx-auto">
          {tabs.map((tab) => (
            <button
              key={tab.value}
              onClick={() => setActiveTab(tab.value)}
              className={`flex items-center gap-1.5 px-3 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${
                activeTab === tab.value
                  ? "border-zubyr-green text-zubyr-green"
                  : "border-transparent text-zubyr-green/40 hover:text-zubyr-green/70"
              }`}
            >
              {tab.icon}
              {tab.label}
              {tab.value === "contact" && unreadContactCount > 0 && (
                <span className="bg-zubyr-amber text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full leading-none">
                  {unreadContactCount}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {activeTab === "contact" && (
          <div className="flex flex-col gap-3">
            {enquiriesQ.isLoading && <p className="text-center text-zubyr-green/40 text-sm py-8">Loading…</p>}
            {enquiriesQ.data?.length === 0 && <EmptyState label="No contact enquiries yet." />}
            {enquiriesQ.data?.map((e: any) => (
              <EnquiryCard
                key={e.id}
                e={e}
                onMarkRead={() => markReadMutation.mutate({ id: e.id })}
              />
            ))}
          </div>
        )}
        {activeTab === "wholesale" && <WholesaleTab />}
        {activeTab === "collabs" && <CollabsTab />}
        {activeTab === "ideas" && <IdeasTab />}
        {activeTab === "applications" && <ApplicationsTab />}
      </div>
    </div>
  );
}
