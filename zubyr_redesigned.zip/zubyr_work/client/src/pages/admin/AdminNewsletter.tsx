import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowLeft, Download } from "lucide-react";

export default function AdminNewsletter() {
  const { user } = useAuth();
  const subscribersQ = trpc.newsletter.list.useQuery();

  if (!user || user.role !== "admin") return null;

  const handleExport = () => {
    if (!subscribersQ.data) return;
    const csv = ["Name,Email,Subscribed At"]
      .concat(subscribersQ.data.map((s: any) => `"${s.name || ""}","${s.email}","${new Date(s.createdAt).toLocaleDateString()}"`))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `zubyr-newsletter-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-pine px-5 py-4 flex items-center gap-3 sticky top-0 z-40 shadow-lg">
        <a href="/admin" className="text-white/60 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </a>
        <div>
          <h1 className="text-white font-bold tracking-widest uppercase text-sm">Newsletter Subscribers</h1>
          <p className="text-white/40 text-xs">ZUBYR Admin</p>
        </div>
        <button
          onClick={handleExport}
          className="ml-auto flex items-center gap-1.5 bg-zubyr-gold text-pine px-3 py-2 rounded-xl text-xs font-bold tracking-wider hover:bg-spice transition-colors"
        >
          <Download className="w-4 h-4" /> Export CSV
        </button>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-6">
        <div className="bg-white rounded-2xl border border-pine/10 shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-cream flex items-center justify-between">
            <p className="text-xs text-pine/50 uppercase tracking-widest font-semibold">Subscribers</p>
            <p className="text-xs text-spice font-bold">{subscribersQ.data?.length ?? 0} total</p>
          </div>
          {subscribersQ.isLoading && <p className="text-center text-pine/40 text-sm py-8">Loading…</p>}
          {subscribersQ.data?.length === 0 && (
            <p className="text-center text-pine/40 text-sm py-8">No subscribers yet.</p>
          )}
          <div className="divide-y divide-cream">
            {subscribersQ.data?.map((s: any) => (
              <div key={s.id} className="px-5 py-3 flex items-center justify-between">
                <div>
                  {s.name && <p className="text-sm text-pine font-medium">{s.name}</p>}
                  <p className="text-xs text-pine/60">{s.email}</p>
                </div>
                <p className="text-xs text-pine/30">{new Date(s.createdAt).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
