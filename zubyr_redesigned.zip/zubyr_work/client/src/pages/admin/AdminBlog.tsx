import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, ArrowLeft, Globe, EyeOff, CheckCircle, Clock, Archive } from "lucide-react";
import { Link } from "wouter";

type BlogCategory =
  | "ingredient_academy" | "perfume_science" | "perfumery_school"
  | "formula_breakdowns" | "perfumer_stories" | "singapore_fragrance_reports"
  | "scentmate_insights" | "workshop_journal" | "community_spotlight"
  | "fragrance_encyclopedia";

type BlogStatus = "draft" | "pending_review" | "published" | "archived";

type BlogForm = {
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  category: BlogCategory;
  imageUrl: string;
  authorName: string;
  readTime: number;
  tags: string;
  status: BlogStatus;
  published: boolean;
};

const emptyForm: BlogForm = {
  title: "",
  slug: "",
  content: "",
  excerpt: "",
  category: "perfume_science",
  imageUrl: "",
  authorName: "ZUBYR Editorial",
  readTime: 5,
  tags: "",
  status: "draft",
  published: false,
};

const CATEGORIES: { value: BlogCategory; label: string }[] = [
  { value: "ingredient_academy", label: "Ingredient Academy" },
  { value: "perfume_science", label: "Perfume Science" },
  { value: "perfumery_school", label: "Perfumery School" },
  { value: "formula_breakdowns", label: "Formula Breakdowns" },
  { value: "perfumer_stories", label: "Perfumer Stories" },
  { value: "singapore_fragrance_reports", label: "Singapore Fragrance Reports" },
  { value: "scentmate_insights", label: "ScentMate Insights" },
  { value: "workshop_journal", label: "Workshop Journal" },
  { value: "community_spotlight", label: "Community Spotlight" },
  { value: "fragrance_encyclopedia", label: "Fragrance Encyclopedia" },
];

const STATUS_CONFIG: Record<BlogStatus, { label: string; color: string; bg: string; icon: React.ReactNode }> = {
  draft:          { label: "Draft",          color: "text-gray-600",   bg: "bg-gray-100",   icon: <Clock size={12} /> },
  pending_review: { label: "Pending Review", color: "text-amber-700",  bg: "bg-amber-100",  icon: <Clock size={12} /> },
  published:      { label: "Published",      color: "text-green-700",  bg: "bg-green-100",  icon: <CheckCircle size={12} /> },
  archived:       { label: "Archived",       color: "text-purple-700", bg: "bg-purple-100", icon: <Archive size={12} /> },
};

function slugify(str: string) {
  return str.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export default function AdminBlog() {
  const { user } = useAuth();
  const [form, setForm] = useState<BlogForm>(emptyForm);
  const [editId, setEditId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const utils = trpc.useUtils();

  const blogQ = trpc.blog.list.useQuery({ adminAll: true });
  const createMutation = trpc.blog.create.useMutation({
    onSuccess: () => { utils.blog.list.invalidate(); setShowForm(false); setForm(emptyForm); toast.success("Post created"); },
    onError: () => toast.error("Failed to create post"),
  });
  const updateMutation = trpc.blog.update.useMutation({
    onSuccess: () => { utils.blog.list.invalidate(); setShowForm(false); setEditId(null); setForm(emptyForm); toast.success("Post updated"); },
    onError: () => toast.error("Failed to update post"),
  });
  const publishMutation = trpc.blog.publish.useMutation({
    onSuccess: () => { utils.blog.list.invalidate(); toast.success("Post published"); },
    onError: () => toast.error("Failed to publish"),
  });
  const unpublishMutation = trpc.blog.unpublish.useMutation({
    onSuccess: () => { utils.blog.list.invalidate(); toast.success("Post unpublished"); },
    onError: () => toast.error("Failed to unpublish"),
  });
  const deleteMutation = trpc.blog.delete.useMutation({
    onSuccess: () => { utils.blog.list.invalidate(); toast.success("Post deleted"); },
    onError: () => toast.error("Failed to delete post"),
  });

  if (!user || user.role !== "admin") return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { ...form, readTime: Number(form.readTime) };
    if (editId !== null) {
      updateMutation.mutate({ id: editId, ...payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleEdit = (p: any) => {
    setForm({
      title: p.title || "",
      slug: p.slug || "",
      content: p.content || "",
      excerpt: p.excerpt || "",
      category: p.category || "perfume_science",
      imageUrl: p.imageUrl || "",
      authorName: p.authorName || "ZUBYR Editorial",
      readTime: p.readTime || 5,
      tags: p.tags || "",
      status: p.status || "draft",
      published: p.published ?? false,
    });
    setEditId(p.id);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const posts = blogQ.data ?? [];
  const filtered = filterStatus === "all" ? posts : posts.filter(p => p.status === filterStatus);

  return (
    <div className="min-h-screen bg-[#f5f0e8] p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Link href="/admin">
            <button className="p-2 rounded-xl bg-white border border-[#e8e0d4] text-[#0d3320]">
              <ArrowLeft size={16} />
            </button>
          </Link>
          <div>
            <h1 className="font-serif text-xl text-[#0d3320]">Blog & Academy</h1>
            <p className="text-xs text-[#7a6a58]">{posts.length} articles total</p>
          </div>
        </div>
        <button
          onClick={() => { setForm(emptyForm); setEditId(null); setShowForm(true); }}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#0d3320] text-white text-sm font-semibold"
        >
          <Plus size={14} /> New Article
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-2xl border border-[#e8e0d4] p-5 mb-6">
          <h2 className="font-serif text-lg text-[#0d3320] mb-4">
            {editId !== null ? "Edit Article" : "New Article"}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Title *</label>
                <input
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20"
                  value={form.title}
                  onChange={e => {
                    const title = e.target.value;
                    setForm(f => ({ ...f, title, slug: editId ? f.slug : slugify(title) }));
                  }}
                  required
                  placeholder="Article title..."
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Slug (URL)</label>
                <input
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 font-mono"
                  value={form.slug}
                  onChange={e => setForm(f => ({ ...f, slug: slugify(e.target.value) }))}
                  placeholder="auto-generated-from-title"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Excerpt</label>
                <textarea
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 resize-none"
                  rows={2}
                  value={form.excerpt}
                  onChange={e => setForm(f => ({ ...f, excerpt: e.target.value }))}
                  placeholder="Short summary shown in article cards..."
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Full Content</label>
                <textarea
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none focus:ring-2 focus:ring-[#0d3320]/20 resize-none font-mono"
                  rows={14}
                  value={form.content}
                  onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
                  placeholder="Full article content (supports plain text or markdown)..."
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Category</label>
                  <select
                    className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none"
                    value={form.category}
                    onChange={e => setForm(f => ({ ...f, category: e.target.value as BlogCategory }))}
                  >
                    {CATEGORIES.map(c => (
                      <option key={c.value} value={c.value}>{c.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Status</label>
                  <select
                    className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none"
                    value={form.status}
                    onChange={e => setForm(f => ({ ...f, status: e.target.value as BlogStatus, published: e.target.value === "published" }))}
                  >
                    <option value="draft">Draft</option>
                    <option value="pending_review">Pending Review</option>
                    <option value="published">Published</option>
                    <option value="archived">Archived</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Author Name</label>
                  <input
                    className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none"
                    value={form.authorName}
                    onChange={e => setForm(f => ({ ...f, authorName: e.target.value }))}
                    placeholder="ZUBYR Editorial"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Read Time (mins)</label>
                  <input
                    type="number"
                    min={1}
                    max={60}
                    className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none"
                    value={form.readTime}
                    onChange={e => setForm(f => ({ ...f, readTime: parseInt(e.target.value) || 5 }))}
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Cover Image URL</label>
                <input
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none"
                  value={form.imageUrl}
                  onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))}
                  placeholder="https://..."
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-[#0d3320] uppercase tracking-wider block mb-1">Tags (comma separated)</label>
                <input
                  className="w-full border border-[#e8e0d4] rounded-xl px-3 py-2.5 text-sm bg-[#f5f0e8] focus:outline-none"
                  value={form.tags}
                  onChange={e => setForm(f => ({ ...f, tags: e.target.value }))}
                  placeholder="oud, singapore, niche perfume..."
                />
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                className="flex-1 py-3 rounded-xl bg-[#0d3320] text-white text-sm font-semibold disabled:opacity-50"
              >
                {editId !== null ? "Save Changes" : "Create Article"}
              </button>
              <button
                type="button"
                onClick={() => { setShowForm(false); setEditId(null); setForm(emptyForm); }}
                className="px-5 py-3 rounded-xl border border-[#e8e0d4] text-[#7a6a58] text-sm font-semibold"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filter tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
        {["all", "draft", "pending_review", "published", "archived"].map(s => (
          <button
            key={s}
            onClick={() => setFilterStatus(s)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
              filterStatus === s
                ? "bg-[#0d3320] text-white"
                : "bg-white border border-[#e8e0d4] text-[#7a6a58]"
            }`}
          >
            {s === "all" ? "All" : STATUS_CONFIG[s as BlogStatus]?.label ?? s}
            <span className="ml-1 opacity-60">
              ({s === "all" ? posts.length : posts.filter(p => p.status === s).length})
            </span>
          </button>
        ))}
      </div>

      {/* Articles list */}
      {blogQ.isLoading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="h-24 bg-white rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <span className="text-4xl block mb-3">📝</span>
          <p className="text-[#7a6a58] text-sm">No articles yet. Create your first one above.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((post: any) => {
            const statusCfg = STATUS_CONFIG[post.status as BlogStatus] ?? STATUS_CONFIG.draft;
            const catLabel = CATEGORIES.find(c => c.value === post.category)?.label ?? post.category;
            return (
              <div key={post.id} className="bg-white rounded-2xl border border-[#e8e0d4] p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${statusCfg.bg} ${statusCfg.color}`}>
                        {statusCfg.icon} {statusCfg.label}
                      </span>
                      <span className="text-xs text-[#9a8a78] bg-[#f5f0e8] px-2 py-0.5 rounded-full">{catLabel}</span>
                    </div>
                    <h3 className="font-semibold text-sm text-[#1a1a1a] leading-tight">{post.title}</h3>
                    {post.excerpt && <p className="text-xs text-[#7a6a58] mt-1 line-clamp-2">{post.excerpt}</p>}
                    <p className="text-xs text-[#9a8a78] mt-1">
                      {post.authorName} · {post.readTime} min read · {new Date(post.createdAt).toLocaleDateString("en-SG")}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 mt-3 pt-3 border-t border-[#f5f0e8]">
                  {post.status !== "published" ? (
                    <button
                      onClick={() => publishMutation.mutate({ id: post.id })}
                      disabled={publishMutation.isPending}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-50 text-green-700 text-xs font-semibold hover:bg-green-100 transition-colors"
                    >
                      <Globe size={12} /> Publish
                    </button>
                  ) : (
                    <button
                      onClick={() => unpublishMutation.mutate({ id: post.id })}
                      disabled={unpublishMutation.isPending}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 text-amber-700 text-xs font-semibold hover:bg-amber-100 transition-colors"
                    >
                      <EyeOff size={12} /> Unpublish
                    </button>
                  )}
                  <button
                    onClick={() => handleEdit(post)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#f5f0e8] text-[#0d3320] text-xs font-semibold hover:bg-[#e8e0d4] transition-colors"
                  >
                    <Pencil size={12} /> Edit
                  </button>
                  {post.status === "published" && (
                    <a
                      href={`/blog/${post.slug}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#f5f0e8] text-[#0d3320] text-xs font-semibold hover:bg-[#e8e0d4] transition-colors"
                    >
                      <Globe size={12} /> View Live
                    </a>
                  )}
                  <button
                    onClick={() => {
                      if (confirm("Delete this article permanently?")) deleteMutation.mutate({ id: post.id });
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-50 text-red-600 text-xs font-semibold hover:bg-red-100 transition-colors ml-auto"
                  >
                    <Trash2 size={12} /> Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
