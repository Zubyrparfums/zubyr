import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { ArrowLeft, CheckCircle, XCircle, Trash2, Filter } from "lucide-react";

type StatusFilter = "all" | "pending" | "approved" | "rejected";

const conditionLabels: Record<string, string> = {
  new: "New",
  like_new: "Like New",
  good: "Good",
  fair: "Fair",
};

export default function AdminCommunity() {
  const { user } = useAuth();
  const [filter, setFilter] = useState<StatusFilter>("pending");
  const utils = trpc.useUtils();

  const listingsQ = trpc.community.list.useQuery(
    filter === "all" ? {} : { status: filter as any }
  );

  const updateStatusMutation = trpc.community.updateStatus.useMutation({
    onSuccess: () => { utils.community.list.invalidate(); toast.success("Listing updated"); },
    onError: () => toast.error("Failed to update listing"),
  });

  const deleteMutation = trpc.community.delete.useMutation({
    onSuccess: () => { utils.community.list.invalidate(); toast.success("Listing deleted"); },
    onError: () => toast.error("Failed to delete listing"),
  });

  if (!user || user.role !== "admin") return null;

  const filterOptions: { value: StatusFilter; label: string }[] = [
    { value: "pending", label: "Pending" },
    { value: "approved", label: "Approved" },
    { value: "rejected", label: "Rejected" },
    { value: "all", label: "All" },
  ];

  return (
    <div className="min-h-screen bg-cream">
      <header className="bg-pine px-5 py-4 flex items-center gap-3 sticky top-0 z-40 shadow-lg">
        <a href="/admin" className="text-white/60 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </a>
        <div>
          <h1 className="text-white font-bold tracking-widest uppercase text-sm">Community Listings</h1>
          <p className="text-white/40 text-xs">ZUBYR Admin</p>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Filter tabs */}
        <div className="flex gap-2 mb-6 bg-white rounded-2xl p-1.5 border border-pine/10 shadow-sm">
          {filterOptions.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setFilter(opt.value)}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all ${
                filter === opt.value
                  ? "bg-pine text-white shadow-sm"
                  : "text-pine/50 hover:text-pine"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <div className="flex flex-col gap-3">
          {listingsQ.isLoading && <p className="text-center text-pine/40 text-sm py-8">Loading…</p>}
          {listingsQ.data?.length === 0 && (
            <div className="bg-white rounded-2xl p-8 text-center border border-pine/10">
              <p className="text-pine/40 text-sm">No {filter === "all" ? "" : filter} listings.</p>
            </div>
          )}
          {listingsQ.data?.map((listing: any) => (
            <div key={listing.id} className="bg-white rounded-2xl border border-pine/10 shadow-sm p-4">
              {/* Header */}
              <div className="flex items-start justify-between gap-2 mb-3">
                <div>
                  <p className="font-semibold text-pine text-sm">{listing.perfumeName}</p>
                  {listing.brand && <p className="text-xs text-spice">{listing.brand}</p>}
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                  listing.status === "approved" ? "bg-green-50 text-green-600" :
                  listing.status === "rejected" ? "bg-red-50 text-red-500" :
                  "bg-yellow-50 text-yellow-600"
                }`}>
                  {listing.status}
                </span>
              </div>

              {/* Details */}
              <div className="grid grid-cols-2 gap-2 mb-3">
                {listing.size && <div><p className="text-xs text-pine/40">Size</p><p className="text-xs text-pine font-medium">{listing.size}</p></div>}
                {listing.remainingPercent != null && <div><p className="text-xs text-pine/40">Remaining</p><p className="text-xs text-pine font-medium">{listing.remainingPercent}%</p></div>}
                {listing.condition && <div><p className="text-xs text-pine/40">Condition</p><p className="text-xs text-pine font-medium">{conditionLabels[listing.condition]}</p></div>}
                {listing.price && <div><p className="text-xs text-pine/40">Price</p><p className="text-xs text-spice font-semibold">SGD {Number(listing.price).toFixed(2)}</p></div>}
              </div>

              {listing.description && (
                <p className="text-xs text-pine/60 mb-3 leading-relaxed border-t border-cream pt-3">{listing.description}</p>
              )}

              {/* Submitter */}
              <div className="flex items-center gap-3 text-xs text-pine/40 mb-3">
                {listing.submitterName && <span>👤 {listing.submitterName}</span>}
                {listing.submitterEmail && <span>✉️ {listing.submitterEmail}</span>}
                {listing.contactMethod && <span>📱 {listing.contactMethod}</span>}
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-2 border-t border-cream">
                {listing.status !== "approved" && (
                  <button
                    onClick={() => updateStatusMutation.mutate({ id: listing.id, status: "approved" })}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-green-50 text-green-600 rounded-xl text-xs font-semibold hover:bg-green-100 transition-colors"
                  >
                    <CheckCircle className="w-4 h-4" /> Approve
                  </button>
                )}
                {listing.status !== "rejected" && (
                  <button
                    onClick={() => updateStatusMutation.mutate({ id: listing.id, status: "rejected" })}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-red-50 text-red-500 rounded-xl text-xs font-semibold hover:bg-red-100 transition-colors"
                  >
                    <XCircle className="w-4 h-4" /> Reject
                  </button>
                )}
                <button
                  onClick={() => { if (confirm("Delete this listing permanently?")) deleteMutation.mutate({ id: listing.id }); }}
                  className="px-3 py-2 bg-cream text-pine/40 rounded-xl text-xs hover:bg-red-50 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
