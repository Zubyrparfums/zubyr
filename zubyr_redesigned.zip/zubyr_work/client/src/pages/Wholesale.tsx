import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Send, CheckCircle, ChevronDown } from "lucide-react";

const PINE="#2d4a3e",FOREST="#1a3028",SPICE="#8B3A1A",AMBER="#C8912E",CREAM="#F2EDE4",STONE="#9A8A78";
const PRODUCTS=["ZUBYR Signature Collection","ZUBYR Premium Collection","ZUBYR Niche Collection","ZUBYR Oud Collection","ZUBYR Collabs Collection","Workshop Kits & Supplies","Fragrance Accessories","Gift Sets","Multiple Product Lines","Other / Custom Inquiry"];

export default function Wholesale(){
  const [form,setForm]=useState({name:"",phone:"",email:"",productInterest:"",message:""});
  const [done,setDone]=useState(false);
  const mut=trpc.wholesale.submit.useMutation({onSuccess:()=>setDone(true),onError:()=>toast.error("Something went wrong.")});
  const go=(e:React.FormEvent)=>{
    e.preventDefault();
    if(!form.name.trim()||!form.email.trim())return toast.error("Name and email are required.");
    mut.mutate({name:form.name,phone:form.phone||undefined,email:form.email,productInterest:form.productInterest||undefined,message:form.message||undefined});
  };

  const inputCls="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none";
  const inputStyle={background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST};
  const labelCls="block font-sans font-semibold text-xs uppercase tracking-wider mb-1.5";
  const labelStyle={color:"rgba(26,48,40,0.48)"};

  return(
    <div className="min-h-screen font-serif" style={{background:CREAM}}>
      <header className="sticky top-0 z-40 px-5 py-4 flex items-center gap-3" style={{background:FOREST}}>
        <a href="/" style={{color:"rgba(255,255,255,0.50)"}}><ArrowLeft className="w-5 h-5"/></a>
        <div>
          <p className="font-bold tracking-widest uppercase text-xs text-white">Wholesale</p>
          <p className="font-sans text-[10px] tracking-widest uppercase" style={{color:"rgba(255,255,255,0.35)"}}>Partner with ZUBYR</p>
        </div>
      </header>

      <div className="max-w-md mx-auto px-5 py-8">
        {done?(
          <div className="flex flex-col items-center justify-center py-20 text-center gap-5">
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{background:`rgba(45,74,62,0.10)`}}>
              <CheckCircle className="w-8 h-8" style={{color:PINE}}/>
            </div>
            <div>
              <h2 className="text-2xl font-bold" style={{color:FOREST}}>Inquiry Received</h2>
              <p className="font-sans text-sm mt-2" style={{color:STONE}}>Our wholesale team will reach out within 2–3 business days.</p>
            </div>
            <a href="/" className="px-6 py-3 rounded-xl font-sans font-bold text-sm" style={{background:PINE,color:"#fff"}}>Back to Home</a>
          </div>
        ):(
          <>
            <div className="mb-7">
              <p className="font-sans font-bold text-xs tracking-[0.22em] uppercase mb-3" style={{color:SPICE}}>Partner with ZUBYR</p>
              <h1 className="text-3xl leading-tight mb-2" style={{color:FOREST}}>Wholesale<br/>Inquiry</h1>
              <p className="font-sans text-sm leading-relaxed" style={{color:STONE}}>Interested in stocking ZUBYR products? Fill in the form and our team will be in touch.</p>
            </div>

            {/* Info tiles */}
            <div className="grid grid-cols-2 gap-2.5 mb-7">
              {[["Minimum Order","By arrangement"],["Lead Time","2–4 weeks"],["Markets","SG & Regional"],["Support","Dedicated rep"]].map(([l,v])=>(
                <div key={l} className="rounded-xl p-3.5" style={{background:"#fff",border:`1px solid rgba(45,74,62,0.09)`}}>
                  <p className="font-sans text-[10px] uppercase tracking-wider" style={{color:STONE}}>{l}</p>
                  <p className="font-sans font-bold text-sm mt-1" style={{color:FOREST}}>{v}</p>
                </div>
              ))}
            </div>

            <form onSubmit={go} className="flex flex-col gap-4">
              <div><label className={labelCls} style={labelStyle}>Name / Business <span style={{color:SPICE}}>*</span></label>
                <input type="text" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="Your name or business name" className={inputCls} style={inputStyle}/></div>
              <div><label className={labelCls} style={labelStyle}>Phone</label>
                <input type="tel" value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} placeholder="+65 XXXX XXXX" className={inputCls} style={inputStyle}/></div>
              <div><label className={labelCls} style={labelStyle}>Email <span style={{color:SPICE}}>*</span></label>
                <input type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} placeholder="you@example.com" className={inputCls} style={inputStyle}/></div>
              <div>
                <label className={labelCls} style={labelStyle}>Products of Interest</label>
                <div className="relative">
                  <select value={form.productInterest} onChange={e=>setForm(f=>({...f,productInterest:e.target.value}))} className={`${inputCls} appearance-none`} style={inputStyle}>
                    <option value="">Select a product line…</option>
                    {PRODUCTS.map(p=><option key={p} value={p}>{p}</option>)}
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none" style={{color:STONE}}/>
                </div>
              </div>
              <div><label className={labelCls} style={labelStyle}>Additional Details</label>
                <textarea rows={4} value={form.message} onChange={e=>setForm(f=>({...f,message:e.target.value}))} placeholder="Business type, volumes, specific requirements…" className={`${inputCls} resize-none`} style={inputStyle}/></div>
              <button type="submit" disabled={mut.isPending} className="w-full flex items-center justify-center gap-2 py-4 rounded-xl font-sans font-bold text-sm active:scale-[0.98] disabled:opacity-60" style={{background:SPICE,color:"#fff"}}>
                <Send className="w-4 h-4"/>{mut.isPending?"Sending…":"Send Inquiry"}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
