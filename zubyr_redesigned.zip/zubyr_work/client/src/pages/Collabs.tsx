import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Send, CheckCircle } from "lucide-react";

const FOREST="#1a3028",SPICE="#8B3A1A",CREAM="#F2EDE4",STONE="#9A8A78",PINE="#2d4a3e";

export default function Collabs(){
  const [form,setForm]=useState({name:"",phone:"",email:"",instagram:"",tiktok:"",youtube:"",otherSocials:"",message:""});
  const [done,setDone]=useState(false);
  const mut=trpc.collabs.submit.useMutation({onSuccess:()=>setDone(true),onError:()=>toast.error("Something went wrong.")});
  const go=(e:React.FormEvent)=>{
    e.preventDefault();
    if(!form.name.trim()||!form.email.trim())return toast.error("Name and email are required.");
    mut.mutate({name:form.name,email:form.email,phone:form.phone||undefined,instagram:form.instagram||undefined,tiktok:form.tiktok||undefined,youtube:form.youtube||undefined,otherSocials:form.otherSocials||undefined,message:form.message||undefined});
  };

  const F=({label,k,type="text",ph=""}:{label:string,k:keyof typeof form,type?:string,ph?:string})=>(
    <div>
      <label className="block font-sans font-semibold text-xs uppercase tracking-wider mb-1.5" style={{color:"rgba(26,48,40,0.48)"}}>{label}</label>
      <input type={type} value={form[k]} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))} placeholder={ph}
        className="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none"
        style={{background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST}}/>
    </div>
  );

  return(
    <div className="min-h-screen font-serif" style={{background:CREAM}}>
      <header className="sticky top-0 z-40 px-5 py-4 flex items-center gap-3" style={{background:FOREST}}>
        <a href="/" style={{color:"rgba(255,255,255,0.50)"}}><ArrowLeft className="w-5 h-5"/></a>
        <div>
          <p className="font-bold tracking-widest uppercase text-xs text-white">Collabs</p>
          <p className="font-sans text-[10px] tracking-widest uppercase" style={{color:"rgba(255,255,255,0.35)"}}>Create with ZUBYR</p>
        </div>
      </header>

      <div className="max-w-md mx-auto px-5 py-8">
        {done?(
          <div className="flex flex-col items-center justify-center py-20 text-center gap-5">
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{background:`rgba(45,74,62,0.10)`}}>
              <CheckCircle className="w-8 h-8" style={{color:PINE}}/>
            </div>
            <div>
              <h2 className="text-2xl font-bold" style={{color:FOREST}}>Proposal Received</h2>
              <p className="font-sans text-sm mt-2" style={{color:STONE}}>We review every proposal and will reach out if there's a good fit.</p>
            </div>
            <a href="/" className="px-6 py-3 rounded-xl font-sans font-bold text-sm" style={{background:PINE,color:"#fff"}}>Back to Home</a>
          </div>
        ):(
          <>
            <div className="mb-7">
              <p className="font-sans font-bold text-xs tracking-[0.22em] uppercase mb-3" style={{color:SPICE}}>Create with ZUBYR</p>
              <h1 className="text-3xl leading-tight mb-2" style={{color:FOREST}}>Collaborate<br/>With Us</h1>
              <p className="font-sans text-sm leading-relaxed" style={{color:STONE}}>We partner with creators and brands who share our love for scent, culture, and craft.</p>
            </div>

            {/* Collab types */}
            <div className="flex flex-col gap-2 mb-7">
              {[["Content Creators","Fragrance reviews, workshops vlogs, brand storytelling."],["Brand Partnerships","Co-branded collections, limited editions, cross-promotions."],["Artists & Designers","Bottle design, installation art, sensory experiences."]].map(([t,d])=>(
                <div key={t} className="flex gap-3 rounded-xl p-4" style={{background:"#fff",border:`1px solid rgba(45,74,62,0.09)`}}>
                  <span style={{color:SPICE}} className="font-serif text-lg leading-none mt-0.5">✦</span>
                  <div>
                    <p className="font-semibold text-sm" style={{color:FOREST}}>{t}</p>
                    <p className="font-sans text-xs mt-0.5" style={{color:STONE}}>{d}</p>
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={go} className="flex flex-col gap-4">
              <F label="Full Name *" k="name" ph="Your name"/>
              <F label="Email *" k="email" type="email" ph="you@example.com"/>
              <F label="Phone" k="phone" type="tel" ph="+65 XXXX XXXX"/>
              <div className="grid grid-cols-2 gap-3">
                <F label="Instagram" k="instagram" ph="@handle"/>
                <F label="TikTok" k="tiktok" ph="@handle"/>
              </div>
              <F label="YouTube" k="youtube" ph="Channel URL"/>
              <F label="Other Socials" k="otherSocials" ph="LinkedIn, website, etc."/>
              <div>
                <label className="block font-sans font-semibold text-xs uppercase tracking-wider mb-1.5" style={{color:"rgba(26,48,40,0.48)"}}>Your Proposal</label>
                <textarea rows={4} value={form.message} onChange={e=>setForm(f=>({...f,message:e.target.value}))} placeholder="Tell us how you'd like to collaborate…"
                  className="w-full rounded-xl px-4 py-3.5 font-sans text-sm focus:outline-none resize-none"
                  style={{background:"#fff",border:`1px solid rgba(45,74,62,0.14)`,color:FOREST}}/>
              </div>
              <button type="submit" disabled={mut.isPending} className="w-full flex items-center justify-center gap-2 py-4 rounded-xl font-sans font-bold text-sm active:scale-[0.98] disabled:opacity-60" style={{background:SPICE,color:"#fff"}}>
                <Send className="w-4 h-4"/>{mut.isPending?"Sending…":"Send Proposal"}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
