import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Mail, Lock, User as UserIcon, Loader2 } from "lucide-react";

const PINE="#2d4a3e", FOREST="#1a3028", SPICE="#8B3A1A", AMBER="#C8912E", CREAM="#F2EDE4", STONE="#9A8A78";

function getReturnTo() {
  if (typeof window === "undefined") return "/";
  const params = new URLSearchParams(window.location.search);
  return params.get("returnTo") || "/";
}

export default function Login() {
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [form, setForm] = useState({ email: "", password: "", name: "" });
  const utils = trpc.useUtils();

  const login = trpc.auth.login.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      toast.success("Welcome back.");
      navigate(getReturnTo());
    },
    onError: (e) => toast.error(e.message || "Login failed."),
  });

  const register = trpc.auth.register.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      toast.success("Account created.");
      navigate(getReturnTo());
    },
    onError: (e) => toast.error(e.message || "Registration failed."),
  });

  const pending = login.isPending || register.isPending;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.email.trim() || !form.password.trim()) {
      toast.error("Email and password are required.");
      return;
    }
    if (mode === "login") {
      login.mutate({ email: form.email, password: form.password });
    } else {
      if (form.password.length < 8) {
        toast.error("Password must be at least 8 characters.");
        return;
      }
      register.mutate({ email: form.email, password: form.password, name: form.name || undefined });
    }
  }

  const inputCls = "w-full pl-11 pr-4 py-3.5 rounded-xl font-sans text-sm focus:outline-none";
  const inputStyle = { background: "#fff", border: "1px solid rgba(45,74,62,0.14)", color: FOREST };

  return (
    <div className="min-h-screen flex flex-col font-serif" style={{ background: CREAM }}>
      <header className="px-5 py-4 flex items-center gap-3">
        <a href="/" style={{ color: "rgba(26,48,40,0.45)" }}>
          <ArrowLeft className="w-5 h-5" />
        </a>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center px-5 pb-20">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-full bg-white shadow-md flex items-center justify-center mx-auto mb-4 overflow-hidden" style={{ border: `1px solid rgba(45,74,62,0.12)` }}>
              <img src="/manus-storage/zubyrlogo_aac59b85.jpg" alt="ZUBYR" className="w-full h-full object-contain p-2" />
            </div>
            <h1 className="text-2xl font-bold tracking-widest uppercase mb-1" style={{ color: FOREST }}>ZUBYR</h1>
            <p className="font-sans text-xs" style={{ color: STONE }}>
              {mode === "login" ? "Sign in to your account" : "Create your account"}
            </p>
          </div>

          {/* Toggle */}
          <div className="flex rounded-xl p-1 mb-6" style={{ background: "rgba(45,74,62,0.07)" }}>
            {(["login", "register"] as const).map(m => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className="flex-1 py-2.5 rounded-lg font-sans font-semibold text-xs uppercase tracking-wider transition-all"
                style={mode === m ? { background: "#fff", color: FOREST, boxShadow: "0 1px 4px rgba(26,48,40,0.10)" } : { color: STONE }}
              >
                {m === "login" ? "Sign In" : "Register"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="flex flex-col gap-3">
            {mode === "register" && (
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: STONE }} />
                <input
                  type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="Your name" className={inputCls} style={inputStyle}
                />
              </div>
            )}
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: STONE }} />
              <input
                type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                placeholder="Email address" className={inputCls} style={inputStyle}
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: STONE }} />
              <input
                type="password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                placeholder={mode === "register" ? "Password (min. 8 characters)" : "Password"}
                className={inputCls} style={inputStyle}
              />
            </div>

            <button
              type="submit" disabled={pending}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-sans font-bold text-sm mt-2 active:scale-[0.98] disabled:opacity-60"
              style={{ background: SPICE, color: "#fff" }}
            >
              {pending && <Loader2 className="w-4 h-4 animate-spin" />}
              {mode === "login" ? "Sign In" : "Create Account"}
            </button>
          </form>

          {mode === "register" && (
            <p className="font-sans text-xs text-center mt-5" style={{ color: STONE }}>
              The first account created becomes the admin account automatically.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
