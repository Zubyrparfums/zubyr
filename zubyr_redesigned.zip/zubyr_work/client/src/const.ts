export const COOKIE_NAME = "zubyr_session";
export const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;

/**
 * Returns the path to ZUBYR's own login page (replaces the old Manus OAuth
 * portal redirect). Optionally pass a path to return to after login.
 */
export const getLoginUrl = (returnTo?: string) => {
  const path = returnTo ?? window.location.pathname;
  return `/login?returnTo=${encodeURIComponent(path)}`;
};
