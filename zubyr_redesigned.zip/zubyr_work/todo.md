# ZUBYR Platform TODO

## Phase 1 — Landing Page + Admin Backend

### Database & Schema
- [x] Products table (name, price, description, imageUrl, collection, active)
- [x] Workshops table (title, description, imageUrl, klookUrl, whatsappNumber, price, active)
- [x] Blog posts table (title, slug, content, category, published, authorId)
- [x] Community listings table (perfumeName, brand, size, condition, price, photos, status, userId)
- [x] Newsletter subscribers table (email, createdAt)
- [x] Contact enquiries table (name, email, type, message, createdAt)

### Server / API
- [x] Products CRUD router (admin only)
- [x] Workshops CRUD router (admin only)
- [x] Blog posts CRUD router (admin only)
- [x] Community listings router (submit, approve, reject, delete)
- [x] Newsletter subscribe router
- [x] Contact enquiry router
- [x] Email notification on new newsletter signup and contact enquiry (via Resend — RESEND_API_KEY needed)

### Landing Page (Public)
- [x] Premium mobile-first layout with ZUBYR branding
- [x] Logo + tagline hero section
- [x] Module navigation cards/buttons (Shop, Workshop, ScentMate AI, Fragrance Concierge, Ingredient Library, Formulation Marketplace, Perfumery School, Blog, Community, Newsletter)
- [x] Sticky WhatsApp button
- [x] Google Reviews placeholder section (ready to connect API key)
- [x] Social media links (Instagram, TikTok, YouTube, Facebook, LinkedIn)
- [x] Newsletter signup form
- [x] Footer with Contact, Careers, Wholesale, Collaborations

### Admin Backend
- [x] Admin login (role-gated via Manus OAuth)
- [x] Admin dashboard overview with stats
- [x] Products CMS (create, edit, delete, toggle active)
- [x] Workshops CMS (create, edit, delete, Klook link)
- [x] Blog posts CMS (create, edit, delete, publish/unpublish)
- [x] Community listings moderation (approve, reject, delete, filter by status)
- [x] Newsletter subscribers list (view, export CSV)
- [x] Contact enquiries list (view, mark as read)

### Tests
- [x] Auth logout test
- [x] Admin guard test (products router)
- [x] Newsletter email validation test
- [x] Community submit validation test
- [x] Auth.me test

## Phase 2 — Upcoming Modules (Next Steps)
- [ ] Full Shop page with collection filtering
- [ ] ScentMate AI questionnaire (10 questions, AI recommendations)
- [ ] Ingredient Library with SEO pages (/ingredients/oud etc.)
- [ ] Fragrance Concierge database (search by name, brand, notes)
- [ ] Formulation Marketplace (buy & download PDFs)
- [ ] Perfumery School page with application form
- [ ] Blog public pages with category filtering
- [ ] Community public marketplace with listing submission
- [ ] User account / Fragrance Passport
- [ ] HitPay payment integration
- [ ] Google Reviews live integration (needs Places API key)
- [ ] Resend email service setup (needs RESEND_API_KEY)

## Phase 5 — Footer Pages
- [x] DB schema: contact_submissions, job_listings, job_applications, wholesale_inquiries, collab_inquiries, idea_submissions
- [x] tRPC routers for all footer form submissions with email to admin@zubyr.co
- [x] Contact page: name, phone, email, reason — emails admin
- [x] Careers page: job listings with descriptions, apply button, resume + 1min video upload, applicant counter, dropdown of positions
- [x] Wholesale page: name, phone, email, product dropdown, open text — emails admin
- [x] Collabs page: name, email, phone, social handles, open text — emails admin
- [x] Give Us Ideas page: company description, open idea form — emails admin
- [x] Remove sticky WhatsApp from landing page
- [x] Add "Give Us Ideas" button to landing page footer links
- [x] Wire all footer links to correct pages in App.tsx

## Phase 6 — Weekly Newsletter by ZUBYR
- [ ] Rename "The ZUBYR Letter" button on landing page to "Weekly Newsletter by ZUBYR"
- [ ] Build /newsletter page with list of past newsletter issues (card grid)
- [ ] Seed 2 mock newsletter issues: Monday edition + Friday edition
- [ ] Each issue has 2 sections: Inside ZUBYR + Around the World of Fragrance (with 2-3 images)
- [ ] Newsletter issue detail page with full content
- [ ] Subscriber signup form at bottom of newsletter page
- [ ] DB schema: newsletter_issues table (title, edition_type, published_at, section1_content, section2_content, images)

## Phase 7 — Newsletter SEO & Community Marketplace

- [ ] Newsletter: individual issue page at /newsletter/:slug for SEO
- [ ] Newsletter: update App.tsx route to handle /newsletter/:slug
- [ ] Community Marketplace: termsAccepted column in users table
- [ ] Community Marketplace: community_listings table with full Carousell-style fields + slug
- [ ] Community Marketplace: T&C scroll-gate modal (must scroll to bottom before accepting)
- [ ] Community Marketplace: Carousell-style feed page (/community) with search, filter, grid
- [ ] Community Marketplace: individual listing page at /community/:slug for SEO
- [ ] Community Marketplace: ZUBYR product recommendations at bottom of every listing page
- [ ] Community Marketplace: post listing form (auth-gated, after T&C accepted)
- [ ] Community Marketplace: image upload for listings
- [ ] Community Marketplace: admin moderation in admin panel
